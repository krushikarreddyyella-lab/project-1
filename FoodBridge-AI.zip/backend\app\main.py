from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.core.config import settings
from app.db.session import engine, Base
from app.api.v1.router import api_router
from app.services.bedrock_service import bedrock_service

# Initialize database schema
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.VERSION,
    description="FoodBridge AI: AI-Powered Surplus Food Donation Management System pairing deterministic safety checks, Strands Decider 2B, and Amazon Bedrock."
)

# CORS setup
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Permits local development frontend
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(api_router, prefix=settings.API_V1_STR)


@app.get("/")
def root():
    return {
        "system": settings.PROJECT_NAME,
        "version": settings.VERSION,
        "status": "operational",
        "demo_environment": settings.IS_DEMO_ENVIRONMENT,
        "fictional_data_notice": "DEMO NOTICE: All test organizations and donations are fictional.",
        "ai_engine": {
            "decider_model": settings.DECIDER_MODEL_NAME,
            "decider_confidence_threshold": settings.DECIDER_CONFIDENCE_THRESHOLD,
            "bedrock_model_id": settings.BEDROCK_MODEL_ID,
            "is_live_bedrock": bedrock_service.is_live_bedrock
        }
    }


@app.get("/health")
def health():
    return {"status": "healthy"}
