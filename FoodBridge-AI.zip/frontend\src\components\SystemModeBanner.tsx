import React from 'react';
import { Info, Sparkles, ShieldCheck, Activity } from 'lucide-react';

interface Props {
  isLiveBedrock: boolean;
}

export const SystemModeBanner: React.FC<Props> = ({ isLiveBedrock }) => {
  return (
    <div className="bg-slate-900 text-slate-200 border-b border-slate-800 text-xs py-2 px-4">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <span className="flex h-2 w-2 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
          </span>
          <span className="font-semibold text-white">System Active</span>
          <span className="text-slate-400">|</span>
          <div className="flex items-center gap-1 text-slate-300">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Deterministic Safety Guardrails: <strong>ENFORCED</strong></span>
          </div>
          <span className="text-slate-400">|</span>
          <div className="flex items-center gap-1 text-slate-300">
            <Activity className="w-3.5 h-3.5 text-teal-400" />
            <span>Classifier: <strong>Strands Decider 2B</strong></span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-[11px]">
            <Sparkles className="w-3 h-3 text-amber-400" />
            <span>Amazon Bedrock: </span>
            {isLiveBedrock ? (
              <span className="text-emerald-400 font-bold">AWS Live</span>
            ) : (
              <span className="text-sky-300 font-medium">Simulation / Fallback Mode</span>
            )}
          </div>
          <div className="flex items-center gap-1 text-slate-400 text-[11px]">
            <Info className="w-3.5 h-3.5 text-slate-500" />
            <span>Demo Data: Fictional test organizations</span>
          </div>
        </div>
      </div>
    </div>
  );
};
