import React, { useState, useEffect } from 'react';
import { Truck, CheckCircle2, Clock, ShieldCheck, KeyRound, AlertCircle, RefreshCw } from 'lucide-react';
import { Donation } from '../types';
import { api } from '../api/client';
import { StatusBadge } from '../components/StatusBadge';

interface Props {
  initialDonationId?: string;
  onNavigate: (tab: string, contextId?: string) => void;
}

export const PickupTrackerPage: React.FC<Props> = ({ initialDonationId, onNavigate }) => {
  const [donations, setDonations] = useState<Donation[]>([]);
  const [selectedId, setSelectedId] = useState<string>(initialDonationId || '');
  const [verificationInput, setVerificationInput] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(true);
  const [updating, setUpdating] = useState<boolean>(false);
  const [message, setMessage] = useState<{ text: string; isError?: boolean } | null>(null);

  const loadDonations = async () => {
    try {
      setLoading(true);
      const data = await api.listDonations();
      setDonations(data);
      if (!selectedId && data.length > 0) {
        // Prefer one in transit or accepted
        const active = data.find((d) => d.status === 'IN_TRANSIT' || d.status === 'ACCEPTED') || data[0];
        setSelectedId(active.id);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadDonations();
  }, []);

  const currentDonation = donations.find((d) => d.id === selectedId);

  const handleStatusAdvance = async (newStatus: string) => {
    if (!currentDonation) return;
    try {
      setUpdating(true);
      setMessage(null);
      await api.updateDonationStatus(
        currentDonation.id,
        newStatus,
        newStatus === 'COLLECTED' ? verificationInput : undefined
      );
      setMessage({ text: `Successfully transitioned status to ${newStatus}!` });
      setVerificationInput('');
      loadDonations();
    } catch (err: any) {
      setMessage({ text: err.message || 'Status transition failed', isError: true });
    } finally {
      setUpdating(false);
    }
  };

  // Steps definition for visual timeline
  const steps = [
    { key: 'PROPOSED', label: '1. Registered' },
    { key: 'MATCHED', label: '2. AI Evaluated' },
    { key: 'ACCEPTED', label: '3. Offer Accepted' },
    { key: 'IN_TRANSIT', label: '4. Driver In Transit' },
    { key: 'COLLECTED', label: '5. Verified & Collected' },
  ];

  const getStepIndex = (status: string) => {
    switch (status) {
      case 'PROPOSED': return 0;
      case 'MATCHED': return 1;
      case 'ACCEPTED': return 2;
      case 'IN_TRANSIT': return 3;
      case 'COLLECTED': return 4;
      default: return -1;
    }
  };

  const currentStepIdx = currentDonation ? getStepIndex(currentDonation.status) : 0;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-indigo-50 text-indigo-600 rounded-xl">
            <Truck className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900">Donation Acceptance & Pickup Tracker</h1>
            <p className="text-xs text-slate-500 mt-0.5">
              Secure chain of custody from recipient acceptance to OTP-verified collection.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <label className="text-xs font-semibold text-slate-600">Select Donation:</label>
          <select
            value={selectedId}
            onChange={(e) => setSelectedId(e.target.value)}
            className="px-3 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none bg-white font-medium max-w-xs"
          >
            {donations.map((d) => (
              <option key={d.id} value={d.id}>
                {d.food_title} - [{d.status}]
              </option>
            ))}
          </select>
          <button
            onClick={loadDonations}
            className="p-2 text-slate-500 hover:text-slate-800 rounded-lg hover:bg-slate-100 border border-slate-200"
            title="Refresh"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {message && (
        <div className={`p-4 rounded-xl flex items-center gap-2 text-sm font-medium ${
          message.isError
            ? 'bg-rose-50 text-rose-800 border border-rose-200'
            : 'bg-emerald-50 text-emerald-800 border border-emerald-200'
        }`}>
          {message.isError ? <AlertCircle className="w-4 h-4 shrink-0" /> : <CheckCircle2 className="w-4 h-4 shrink-0" />}
          <span>{message.text}</span>
        </div>
      )}

      {currentDonation ? (
        <div className="space-y-6">
          {/* Visual Step Progress Tracker */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-6">
              Custody Progress Pipeline
            </h2>

            <div className="relative">
              {/* Line connector */}
              <div className="absolute top-4 left-6 right-6 h-0.5 bg-slate-200 -z-0" />
              <div
                className="absolute top-4 left-6 h-0.5 bg-emerald-500 transition-all duration-500 -z-0"
                style={{
                  width: `${Math.max(0, Math.min(100, (currentStepIdx / (steps.length - 1)) * 100))}%`,
                }}
              />

              <div className="grid grid-cols-5 relative z-10 text-center">
                {steps.map((step, idx) => {
                  const isCompleted = idx <= currentStepIdx;
                  const isCurrent = idx === currentStepIdx;

                  return (
                    <div key={step.key} className="flex flex-col items-center">
                      <div
                        className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                          isCompleted
                            ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30 ring-4 ring-emerald-50'
                            : 'bg-white border-2 border-slate-300 text-slate-400'
                        }`}
                      >
                        {isCompleted ? <CheckCircle2 className="w-4 h-4" /> : idx + 1}
                      </div>
                      <span className={`text-[11px] font-semibold mt-2 ${
                        isCurrent ? 'text-emerald-700' : isCompleted ? 'text-slate-700' : 'text-slate-400'
                      }`}>
                        {step.label}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Details & Actions Card */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Info details */}
            <div className="md:col-span-2 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <h3 className="font-bold text-slate-900 text-base">{currentDonation.food_title}</h3>
                  <StatusBadge status={currentDonation.status} />
                </div>
                <span className="text-xs font-mono text-slate-400">ID: {currentDonation.id.slice(0, 8)}</span>
              </div>

              <div className="grid grid-cols-2 gap-4 text-xs">
                <div>
                  <span className="text-slate-400 block font-medium">Donor Information</span>
                  <span className="font-semibold text-slate-800 text-sm block mt-0.5">{currentDonation.donor_name}</span>
                  <span className="text-slate-600 block">{currentDonation.donor_address}</span>
                  <span className="text-slate-500 font-mono block mt-1">{currentDonation.donor_contact}</span>
                </div>

                <div>
                  <span className="text-slate-400 block font-medium">Package Particulars</span>
                  <span className="font-semibold text-slate-800 text-sm block mt-0.5">
                    {currentDonation.quantity_value} {currentDonation.quantity_unit} ({currentDonation.food_category})
                  </span>
                  <span className="text-slate-600 block">Storage: {currentDonation.storage_requirement}</span>
                  <span className="text-slate-500 block mt-1">
                    Pickup Deadline: {new Date(currentDonation.pickup_deadline).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })}
                  </span>
                </div>
              </div>

              {currentDonation.handling_instructions && (
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-600">
                  <strong className="text-slate-700">Handling Advice:</strong> {currentDonation.handling_instructions}
                </div>
              )}

              {currentDonation.status === 'COLLECTED' && currentDonation.collected_at && (
                <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-xs text-emerald-800 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>
                    Successfully collected and verified on {new Date(currentDonation.collected_at).toLocaleString()}. Rescued impact has been recorded!
                  </span>
                </div>
              )}
            </div>

            {/* Actions & Verification Box */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4 flex flex-col justify-between">
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
                  Transporter Handoff Actions
                </h3>

                {/* Display Pickup Verification Code if active */}
                {currentDonation.pickup_verification_code && currentDonation.status !== 'COLLECTED' && (
                  <div className="p-4 bg-indigo-50 border border-indigo-200 rounded-xl text-center space-y-1 mb-4">
                    <span className="text-[11px] font-bold uppercase text-indigo-700 tracking-wider block">
                      Donor Pickup Code
                    </span>
                    <span className="text-3xl font-mono font-extrabold text-indigo-900 tracking-widest block">
                      {currentDonation.pickup_verification_code}
                    </span>
                    <span className="text-[10px] text-indigo-600 block">
                      Transporter presents this code to donor upon collection
                    </span>
                  </div>
                )}

                {/* Transition Buttons */}
                <div className="space-y-2">
                  {currentDonation.status === 'ACCEPTED' && (
                    <button
                      onClick={() => handleStatusAdvance('IN_TRANSIT')}
                      disabled={updating}
                      className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-semibold shadow-sm transition-all"
                    >
                      <Truck className="w-4 h-4" />
                      Mark Driver In Transit
                    </button>
                  )}

                  {currentDonation.status === 'IN_TRANSIT' && (
                    <div className="space-y-3 pt-2">
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Enter Donor's 4-Digit Pickup Code:
                        </label>
                        <div className="flex gap-2">
                          <input
                            type="text"
                            maxLength={6}
                            value={verificationInput}
                            onChange={(e) => setVerificationInput(e.target.value)}
                            placeholder="e.g. 8491"
                            className="w-full px-3 py-2 text-sm font-mono tracking-widest text-center border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                          />
                        </div>
                      </div>

                      <button
                        onClick={() => handleStatusAdvance('COLLECTED')}
                        disabled={updating || !verificationInput}
                        className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold shadow-sm transition-all disabled:opacity-50"
                      >
                        <CheckCircle2 className="w-4 h-4" />
                        Verify & Confirm Collection
                      </button>
                    </div>
                  )}

                  {currentDonation.status === 'COLLECTED' && (
                    <button
                      onClick={() => onNavigate('impact')}
                      className="w-full py-2.5 px-4 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-xl text-xs font-semibold hover:bg-emerald-100 transition-colors"
                    >
                      View Rescued Food in Impact Dashboard &rarr;
                    </button>
                  )}
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 text-[11px] text-slate-400">
                Authorized roles: Verified Driver, Donor Coordinator. Unauthorized overrides are prevented.
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-white p-8 rounded-2xl border border-slate-200 text-center text-slate-400 text-sm">
          No donations available to track.
        </div>
      )}
    </div>
  );
};
