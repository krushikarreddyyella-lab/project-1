import pytest
from datetime import datetime, timedelta
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)


def test_api_root_and_health():
    res = client.get("/health")
    assert res.status_code == 200
    assert res.json() == {"status": "healthy"}

    root_res = client.get("/")
    assert root_res.status_code == 200
    data = root_res.json()
    assert "FoodBridge AI" in data["system"]
    assert "fictional_data_notice" in data
    assert "decider_model" in data["ai_engine"]


def test_list_recipients():
    res = client.get("/api/v1/recipients/")
    assert res.status_code == 200
    recipients = res.json()
    assert isinstance(recipients, list)
    assert len(recipients) >= 1


def test_create_donation_and_retrieve():
    now = datetime.utcnow()
    payload = {
        "donor_name": "API Test Cafe",
        "donor_type": "Restaurant",
        "donor_contact": "+1 555-0987",
        "donor_address": "123 Elm Street",
        "latitude": 12.9716,
        "longitude": 77.5946,
        "food_title": "Fresh Fruit & Yogurt Cups",
        "food_category": "Dairy",
        "quantity_value": 15.0,
        "quantity_unit": "kg",
        "storage_requirement": "REFRIGERATED",
        "dietary_type": "VEGETARIAN",
        "preparation_time": (now - timedelta(hours=1)).isoformat(),
        "pickup_deadline": (now + timedelta(hours=4)).isoformat(),
        "handling_instructions": "Chilled containers."
    }
    create_res = client.post("/api/v1/donations/", json=payload)
    assert create_res.status_code == 200
    don_data = create_res.json()
    assert don_data["food_title"] == "Fresh Fruit & Yogurt Cups"
    assert don_data["status"] == "PROPOSED"
    assert don_data["pickup_verification_code"] is not None

    # Retrieve
    get_res = client.get(f"/api/v1/donations/{don_data['id']}")
    assert get_res.status_code == 200
    assert get_res.json()["id"] == don_data["id"]


def test_run_evaluation_benchmark_endpoint():
    res = client.post("/api/v1/evaluation/run-benchmark")
    assert res.status_code == 200
    data = res.json()
    assert "metrics" in data
    assert data["metrics"]["decider_accuracy_percent"] > 80.0
    assert "cases" in data
    assert len(data["cases"]) >= 5
