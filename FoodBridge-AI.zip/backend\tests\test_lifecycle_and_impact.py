import pytest
from datetime import datetime, timedelta
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.db.session import Base
from app.models.donation import Donation
from app.models.recipient import Recipient
from app.services.impact_service import ImpactService


@pytest.fixture
def in_memory_db():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(bind=engine)
    TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
    db = TestingSessionLocal()
    yield db
    db.close()


def test_impact_only_counts_collected_donations(in_memory_db):
    now = datetime.utcnow()

    # 1. Proposed donation (30 kg) - should NOT count toward impact
    don_proposed = Donation(
        id="p1",
        donor_name="D1",
        donor_type="Restaurant",
        donor_contact="111",
        donor_address="A1",
        food_title="Soup",
        food_category="Cooked Meals",
        quantity_value=30.0,
        quantity_unit="kg",
        storage_requirement="ROOM_TEMP",
        preparation_time=now - timedelta(hours=1),
        pickup_deadline=now + timedelta(hours=2),
        status="PROPOSED"
    )

    # 2. Accepted donation (20 kg) - should NOT count toward impact
    don_accepted = Donation(
        id="a1",
        donor_name="D2",
        donor_type="Restaurant",
        donor_contact="222",
        donor_address="A2",
        food_title="Rice",
        food_category="Cooked Meals",
        quantity_value=20.0,
        quantity_unit="kg",
        storage_requirement="ROOM_TEMP",
        preparation_time=now - timedelta(hours=1),
        pickup_deadline=now + timedelta(hours=2),
        status="ACCEPTED"
    )

    # 3. Collected donation (40 kg) - SHOULD count!
    don_collected = Donation(
        id="c1",
        donor_name="D3",
        donor_type="Restaurant",
        donor_contact="333",
        donor_address="A3",
        food_title="Pasta",
        food_category="Cooked Meals",
        quantity_value=40.0,
        quantity_unit="kg",
        storage_requirement="ROOM_TEMP",
        preparation_time=now - timedelta(hours=4),
        pickup_deadline=now - timedelta(hours=1),
        status="COLLECTED",
        collected_at=now - timedelta(hours=1)
    )

    in_memory_db.add_all([don_proposed, don_accepted, don_collected])
    in_memory_db.commit()

    metrics = ImpactService.calculate_metrics(in_memory_db, serving_size_kg=0.40)

    # Total registered is 3
    assert metrics.total_donations == 3
    # Only 1 completed pickup
    assert metrics.completed_pickups == 1
    # Strictly 40 kg rescued (30 and 20 are NOT counted)
    assert metrics.total_kg_rescued == 40.0
    # 40 kg / 0.40 kg/meal = 100 meals
    assert metrics.estimated_meals_served == 100
    assert metrics.pending_offers == 2
