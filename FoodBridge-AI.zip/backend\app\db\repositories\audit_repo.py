from typing import List, Optional
from sqlalchemy.orm import Session
from app.db.repositories.base_repo import BaseRepository
from app.models.audit_log import AuditLog


class AuditRepository(BaseRepository[AuditLog]):
    def __init__(self, db: Session):
        super().__init__(AuditLog, db)

    def get_by_entity(self, entity_type: str, entity_id: str) -> List[AuditLog]:
        return self.db.query(AuditLog).filter(
            AuditLog.entity_type == entity_type,
            AuditLog.entity_id == entity_id
        ).order_by(AuditLog.created_at.desc()).all()

    def get_recent(self, limit: int = 50) -> List[AuditLog]:
        return self.db.query(AuditLog).order_by(AuditLog.created_at.desc()).limit(limit).all()
