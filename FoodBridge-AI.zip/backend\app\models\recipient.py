import uuid
from datetime import datetime
from sqlalchemy import Column, String, Float, Boolean, DateTime, Text
from app.db.session import Base


class Recipient(Base):
    __tablename__ = "recipients"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String(128), nullable=False)
    organization_type = Column(String(64), nullable=False)  # NGO, Community Kitchen, Shelter, Food Bank
    contact_person = Column(String(64), nullable=False)
    contact_phone = Column(String(64), nullable=False)
    contact_email = Column(String(128), nullable=True)
    address = Column(String(255), nullable=False)
    latitude = Column(Float, nullable=False, default=12.9716)
    longitude = Column(Float, nullable=False, default=77.5946)

    is_verified = Column(Boolean, nullable=False, default=True)  # Hard safety rule gate
    daily_capacity_kg = Column(Float, nullable=False, default=100.0)
    current_capacity_used_kg = Column(Float, nullable=False, default=0.0)
    has_cold_storage = Column(Boolean, nullable=False, default=False)
    has_transportation = Column(Boolean, nullable=False, default=True)
    
    accepted_categories = Column(String(255), default="Cooked Meals,Bakery,Produce,Dairy,Packaged")
    operating_hours_start = Column(String(16), default="08:00")
    operating_hours_end = Column(String(16), default="22:00")
    reliability_score = Column(Float, default=0.95)

    created_at = Column(DateTime, default=datetime.utcnow)
