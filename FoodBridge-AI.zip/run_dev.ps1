# FoodBridge AI - Local Development Runner
Write-Host "Starting FoodBridge AI System..." -ForegroundColor Green

$pythonExe = "$env:LOCALAPPDATA\Programs\Python\Python311\python.exe"
$nodeDir = "$env:LOCALAPPDATA\Microsoft\WinGet\Packages\OpenJS.NodeJS.LTS_Microsoft.Winget.Source_8wekyb3d8bbwe\node-v24.20.0-win-x64"
$env:PATH = "$nodeDir;" + $env:PATH

# Start Backend Server
Write-Host "Launching FastAPI Backend on http://127.0.0.1:8000..." -ForegroundColor Cyan
Start-Process -FilePath $pythonExe -ArgumentList "-m uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload" -WorkingDirectory "$PSScriptRoot\backend"

Start-Sleep -Seconds 3

# Start Frontend Dev Server
Write-Host "Launching React Vite Frontend on http://localhost:5173..." -ForegroundColor Cyan
Set-Location -Path "$PSScriptRoot\frontend"
& "$nodeDir\npm.cmd" run dev
