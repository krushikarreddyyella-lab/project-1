import uuid
from datetime import datetime
from sqlalchemy import Column, String, Float, Boolean, DateTime, Text, ForeignKey
from app.db.session import Base


class MatchDecision(Base):
    __tablename__ = "match_decisions"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    donation_id = Column(String(36), ForeignKey("donations.id"), nullable=False)
    recipient_id = Column(String(36), ForeignKey("recipients.id"), nullable=False)

    distance_km = Column(Float, nullable=False)
    capacity_fit = Column(Boolean, nullable=False)
    storage_fit = Column(Boolean, nullable=False)
    
    # Deterministic hard safety check
    safety_check_passed = Column(Boolean, nullable=False)
    safety_check_details = Column(Text, nullable=True)  # JSON formatted checks

    # Strands Decider 2B output
    decider_decision = Column(String(32), nullable=False)  # APPROVE, REJECT, HUMAN_REVIEW
    decider_confidence = Column(Float, nullable=False)
    decider_rationale = Column(Text, nullable=True)
    decider_latency_ms = Column(Float, nullable=False, default=0.0)

    # Amazon Bedrock Generative output
    bedrock_explanation = Column(Text, nullable=True)
    bedrock_notification = Column(Text, nullable=True)
    bedrock_latency_ms = Column(Float, nullable=False, default=0.0)
    is_live_bedrock = Column(Boolean, default=False)

    # Match workflow status
    match_status = Column(String(32), nullable=False, default="PROPOSED")  # PROPOSED, OFFERED, ACCEPTED, DECLINED, ESCALATED, RESOLVED
    human_reviewer_notes = Column(Text, nullable=True)
    human_reviewed_at = Column(DateTime, nullable=True)

    created_at = Column(DateTime, default=datetime.utcnow)
