import React, { useState, useEffect } from 'react';
import { 
  GitMerge, 
  Sparkles, 
  ShieldCheck, 
  ShieldAlert, 
  Building, 
  MapPin, 
  Truck, 
  CheckCircle, 
  ArrowRight,
  Clock,
  Check,
  X,
  AlertTriangle,
  RotateCw
} from 'lucide-react';
import { Donation, MatchCandidate } from '../types';
import { api } from '../api/client';
import { DecisionBadge } from '../components/DecisionBadge';

interface Props {
  initialDonationId?: string;
  onNavigate: (tab: string, contextId?: string) => void;
}

export const MatchingHubPage: React.FC<Props> = ({ initialDonationId, onNavigate }) => {
  const [donations, setDonations] = useState<Donation[]>([]);
  const [selectedDonationId, setSelectedDonationId] = useState<string>(initialDonationId || '');
  const [candidates, setCandidates] = useState<MatchCandidate[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [evaluating, setEvaluating] = useState<boolean>(false);
  const [acceptingId, setAcceptingId] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  useEffect(() => {
    api.listDonations().then((dons) => {
      setDonations(dons);
      if (!selectedDonationId && dons.length > 0) {
        // Default to first proposed or matched donation
        const candidate = dons.find((d) => d.status === 'PROPOSED' || d.status === 'MATCHED') || dons[0];
        setSelectedDonationId(candidate.id);
      }
    });
  }, []);

  const runEvaluation = async (donId: string) => {
    if (!donId) return;
    try {
      setEvaluating(true);
      setSuccessMessage(null);
      const results = await api.evaluateMatches(donId);
      setCandidates(results);
    } catch (err: any) {
      console.error('Failed to evaluate matches:', err);
    } finally {
      setEvaluating(false);
    }
  };

  useEffect(() => {
    if (selectedDonationId) {
      runEvaluation(selectedDonationId);
    }
  }, [selectedDonationId]);

  const handleAccept = async (candidate: MatchCandidate) => {
    try {
      setAcceptingId(candidate.id);
      const res = await api.acceptMatch(candidate.id);
      setSuccessMessage(
        `Offer successfully accepted by ${candidate.recipient.name}! Pickup Verification Code: ${res.pickup_verification_code}`
      );
      // Re-evaluate to refresh status
      runEvaluation(selectedDonationId);
    } catch (err: any) {
      alert(`Error accepting offer: ${err.message}`);
    } finally {
      setAcceptingId(null);
    }
  };

  const currentDonation = donations.find((d) => d.id === selectedDonationId);

  return (
    <div className="space-y-6">
      {/* Header & Donation Selector */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-teal-50 text-teal-600 rounded-xl">
              <GitMerge className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-slate-900">AI Recipient Matching & Decider Hub</h1>
              <p className="text-xs text-slate-500 mt-0.5">
                Deterministic safety gates evaluate suitability before Strands Decider 2B classifies the match.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <label className="text-xs font-semibold text-slate-600 whitespace-nowrap">Target Surplus:</label>
            <select
              value={selectedDonationId}
              onChange={(e) => setSelectedDonationId(e.target.value)}
              className="px-3 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white font-medium max-w-xs"
            >
              {donations.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.food_title} ({d.quantity_value} {d.quantity_unit}) - [{d.status}]
                </option>
              ))}
            </select>

            <button
              onClick={() => runEvaluation(selectedDonationId)}
              disabled={evaluating}
              className="p-2 text-slate-600 hover:text-slate-900 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors"
              title="Re-run AI Matching"
            >
              <RotateCw className={`w-4 h-4 ${evaluating ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>

        {/* Selected Donation Brief Card */}
        {currentDonation && (
          <div className="mt-4 p-4 rounded-xl bg-slate-50 border border-slate-200/80 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div>
              <span className="text-slate-400 block font-medium">Donor</span>
              <span className="font-semibold text-slate-800">{currentDonation.donor_name}</span>
            </div>
            <div>
              <span className="text-slate-400 block font-medium">Category & Storage</span>
              <span className="font-semibold text-slate-800">
                {currentDonation.food_category} • {currentDonation.storage_requirement}
              </span>
            </div>
            <div>
              <span className="text-slate-400 block font-medium">Quantity</span>
              <span className="font-semibold text-slate-800">
                {currentDonation.quantity_value} {currentDonation.quantity_unit}
              </span>
            </div>
            <div>
              <span className="text-slate-400 block font-medium">Pickup Window</span>
              <span className="font-semibold text-slate-800">
                Until {new Date(currentDonation.pickup_deadline).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
          </div>
        )}

        {successMessage && (
          <div className="mt-4 p-4 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between text-emerald-800 text-sm font-medium">
            <div className="flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0" />
              <span>{successMessage}</span>
            </div>
            <button
              onClick={() => onNavigate('pickups', selectedDonationId)}
              className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold"
            >
              Go to Pickup Tracker &rarr;
            </button>
          </div>
        )}
      </div>

      {/* Candidate Matches Section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-slate-900">
            Evaluated Recipient Candidates ({candidates.length})
          </h2>
          <span className="text-xs text-slate-500">
            Ranked by Strands Decider 2B policy confidence & physical proximity
          </span>
        </div>

        {evaluating ? (
          <div className="bg-white p-12 rounded-2xl border border-slate-200 text-center space-y-3">
            <RotateCw className="w-8 h-8 text-emerald-600 animate-spin mx-auto" />
            <p className="text-sm font-semibold text-slate-800">Running Deterministic Guardrails & Strands Decider 2B...</p>
            <p className="text-xs text-slate-500">Synthesizing explanations with Amazon Bedrock</p>
          </div>
        ) : candidates.length === 0 ? (
          <div className="bg-white p-8 rounded-2xl border border-slate-200 text-center text-slate-400 text-sm">
            No matching candidates found for this donation.
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4">
            {candidates.map((c) => {
              const isApproved = c.decider_output.decision === 'APPROVE';
              const isReview = c.decider_output.decision === 'HUMAN_REVIEW';
              const isRejected = c.decider_output.decision === 'REJECT';

              return (
                <div
                  key={c.id}
                  className={`bg-white rounded-2xl border p-5 transition-all shadow-xs ${
                    isApproved
                      ? 'border-emerald-200 hover:border-emerald-300'
                      : isReview
                      ? 'border-amber-200 hover:border-amber-300 bg-amber-50/20'
                      : 'border-slate-200 opacity-80'
                  }`}
                >
                  <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">
                    {/* Organization & Logistics Profile */}
                    <div className="space-y-2 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <h3 className="font-bold text-slate-900 text-base">{c.recipient.name}</h3>
                        <span className="text-xs px-2 py-0.5 rounded font-medium bg-slate-100 text-slate-700">
                          {c.recipient.organization_type}
                        </span>
                        {c.recipient.is_verified ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                            <ShieldCheck className="w-3 h-3" />
                            Verified NGO
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-rose-700 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                            <ShieldAlert className="w-3 h-3" />
                            Unverified
                          </span>
                        )}
                      </div>

                      <p className="text-xs text-slate-600 flex flex-wrap items-center gap-3">
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3.5 h-3.5 text-slate-400" />
                          Distance: <strong>{c.distance_km.toFixed(1)} km</strong>
                        </span>
                        <span>•</span>
                        <span>
                          Available Intake: <strong>{(c.recipient.daily_capacity_kg - c.recipient.current_capacity_used_kg).toFixed(0)} kg</strong>
                        </span>
                        <span>•</span>
                        <span>
                          Cold Storage: <strong>{c.recipient.has_cold_storage ? 'Yes' : 'No'}</strong>
                        </span>
                        <span>•</span>
                        <span>
                          Vehicle Transport: <strong>{c.recipient.has_transportation ? 'Dedicated' : 'None'}</strong>
                        </span>
                      </p>

                      {/* Deterministic Guardrail Checklist */}
                      <div className="pt-2 flex flex-wrap gap-2 text-[11px]">
                        <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded border ${
                          c.safety_result.checks['deadline_valid']
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                            : 'bg-rose-50 text-rose-700 border-rose-200'
                        }`}>
                          {c.safety_result.checks['deadline_valid'] ? <Check className="w-3 h-3" /> : <X className="w-3 h-3" />}
                          Deadline Safe
                        </span>

                        <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded border ${
                          c.safety_result.checks['capacity_available']
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                            : 'bg-rose-50 text-rose-700 border-rose-200'
                        }`}>
                          {c.safety_result.checks['capacity_available'] ? <Check className="w-3 h-3" /> : <X className="w-3 h-3" />}
                          Capacity Fits
                        </span>

                        <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded border ${
                          c.safety_result.checks['storage_compatible']
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                            : 'bg-rose-50 text-rose-700 border-rose-200'
                        }`}>
                          {c.safety_result.checks['storage_compatible'] ? <Check className="w-3 h-3" /> : <X className="w-3 h-3" />}
                          Storage Match
                        </span>

                        <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded border ${
                          c.safety_result.checks['recipient_verified']
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                            : 'bg-rose-50 text-rose-700 border-rose-200'
                        }`}>
                          {c.safety_result.checks['recipient_verified'] ? <Check className="w-3 h-3" /> : <X className="w-3 h-3" />}
                          Verified Org
                        </span>
                      </div>

                      {/* Amazon Bedrock Match Explanation */}
                      {c.bedrock_explanation && (
                        <div className="mt-3 p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-700 space-y-1">
                          <div className="flex items-center justify-between text-[11px] text-slate-500 font-semibold">
                            <span className="flex items-center gap-1 text-slate-800">
                              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                              Bedrock Match Rationale
                            </span>
                            <span className="text-[10px] font-mono text-slate-400">
                              Latency: {c.bedrock_latency_ms}ms
                            </span>
                          </div>
                          <p className="leading-relaxed italic">"{c.bedrock_explanation}"</p>
                        </div>
                      )}
                    </div>

                    {/* Decision Model Outcome & Claim Action */}
                    <div className="flex flex-col items-start lg:items-end justify-between gap-3 shrink-0 lg:w-64 pt-3 lg:pt-0 border-t lg:border-t-0 border-slate-100">
                      <div className="space-y-1 text-right">
                        <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-bold">
                          Strands Decider 2B
                        </span>
                        <DecisionBadge
                          decision={c.decider_output.decision}
                          confidence={c.decider_output.confidence}
                        />
                        <div className="text-[10px] font-mono text-slate-400 mt-1">
                          Latency: {c.decider_output.latency_ms}ms
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="w-full lg:w-auto flex flex-col items-end gap-2">
                        {isApproved && (
                          <button
                            onClick={() => handleAccept(c)}
                            disabled={acceptingId === c.id || c.match_status === 'ACCEPTED'}
                            className="w-full lg:w-auto flex items-center justify-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold shadow-sm transition-all disabled:opacity-50"
                          >
                            <CheckCircle className="w-3.5 h-3.5" />
                            {c.match_status === 'ACCEPTED' ? 'Accepted' : 'Accept Donation Offer'}
                          </button>
                        )}

                        {isReview && (
                          <button
                            onClick={() => onNavigate('reviews')}
                            className="w-full lg:w-auto flex items-center justify-center gap-1 px-3 py-1.5 bg-amber-100 hover:bg-amber-200 text-amber-800 rounded-lg text-xs font-semibold transition-colors"
                          >
                            <AlertTriangle className="w-3.5 h-3.5" />
                            Review in Queue &rarr;
                          </button>
                        )}

                        {isRejected && (
                          <span className="text-xs text-rose-600 font-medium">
                            Excluded by Safety Policy
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
