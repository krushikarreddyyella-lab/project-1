from pydantic import BaseModel, Field
from datetime import datetime
from typing import Optional, List
from app.schemas.decider import DeciderOutput, SafetyCheckResult
from app.schemas.recipient import RecipientResponse


class MatchCandidate(BaseModel):
    id: str
    donation_id: str
    recipient: RecipientResponse
    distance_km: float
    capacity_fit: bool
    storage_fit: bool
    
    safety_result: SafetyCheckResult
    decider_output: DeciderOutput
    
    bedrock_explanation: Optional[str] = None
    bedrock_notification: Optional[str] = None
    bedrock_latency_ms: float = 0.0
    is_live_bedrock: bool = False

    match_status: str  # PROPOSED, OFFERED, ACCEPTED, DECLINED, ESCALATED, RESOLVED
    created_at: datetime


class MatchReviewResolve(BaseModel):
    action: str = Field(..., description="'APPROVE' or 'REJECT'")
    reviewer_notes: str = Field(..., min_length=3)
