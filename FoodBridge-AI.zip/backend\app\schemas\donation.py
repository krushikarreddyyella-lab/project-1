from pydantic import BaseModel, Field, ConfigDict
from datetime import datetime
from typing import Optional


class DonationBase(BaseModel):
    donor_name: str = Field(..., min_length=2, max_length=128)
    donor_type: str = Field("Restaurant", description="Restaurant, Hostel, Wedding/Event, Cafeteria, Supermarket")
    donor_contact: str = Field(..., min_length=5, max_length=64)
    donor_address: str = Field(..., min_length=5, max_length=255)
    latitude: float = Field(12.9716, ge=-90, le=90)
    longitude: float = Field(77.5946, ge=-180, le=180)

    food_title: str = Field(..., min_length=3, max_length=255)
    food_category: str = Field("Cooked Meals", description="Cooked Meals, Bakery, Produce, Dairy, Packaged")
    quantity_value: float = Field(..., gt=0)
    quantity_unit: str = Field("kg", description="kg or servings")
    storage_requirement: str = Field("ROOM_TEMP", description="ROOM_TEMP, REFRIGERATED, FROZEN, HOT_HOLDING")
    dietary_type: str = Field("VEGETARIAN", description="VEGETARIAN, VEGAN, NON_VEG, HALAL")

    preparation_time: datetime
    pickup_deadline: datetime
    handling_instructions: Optional[str] = None


class DonationCreate(DonationBase):
    pass


class DonationStatusUpdate(BaseModel):
    status: str
    verification_code: Optional[str] = None


class DonationResponse(DonationBase):
    id: str
    status: str
    pickup_verification_code: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    collected_at: Optional[datetime] = None

    model_config = ConfigDict(from_attributes=True)
