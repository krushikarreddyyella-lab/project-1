import React from 'react';
import { DeciderDecision } from '../types';
import { CheckCircle2, AlertTriangle, XCircle } from 'lucide-react';

interface Props {
  decision: DeciderDecision | string;
  confidence?: number;
}

export const DecisionBadge: React.FC<Props> = ({ decision, confidence }) => {
  if (decision === 'APPROVE') {
    return (
      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
        APPROVE
        {confidence !== undefined && (
          <span className="ml-1 text-emerald-800 font-mono">({Math.round(confidence * 100)}%)</span>
        )}
      </span>
    );
  }

  if (decision === 'HUMAN_REVIEW') {
    return (
      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-300">
        <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
        HUMAN REVIEW
        {confidence !== undefined && (
          <span className="ml-1 text-amber-800 font-mono">({Math.round(confidence * 100)}%)</span>
        )}
      </span>
    );
  }

  return (
    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-semibold bg-rose-50 text-rose-700 border border-rose-200">
      <XCircle className="w-3.5 h-3.5 text-rose-600" />
      REJECT
      {confidence !== undefined && (
        <span className="ml-1 text-rose-800 font-mono">({Math.round(confidence * 100)}%)</span>
      )}
    </span>
  );
};
