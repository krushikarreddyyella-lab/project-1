import React, { useState, useEffect } from 'react';
import { 
  UtensilsCrossed, 
  CheckCircle, 
  Clock, 
  ArrowRight, 
  Sparkles, 
  RefreshCw,
  AlertCircle,
  Truck,
  Leaf
} from 'lucide-react';
import { Donation, ImpactMetrics, AuditLogItem } from '../types';
import { api } from '../api/client';
import { StatusBadge } from '../components/StatusBadge';

interface Props {
  onNavigate: (tab: string, contextId?: string) => void;
}

export const DashboardPage: React.FC<Props> = ({ onNavigate }) => {
  const [donations, setDonations] = useState<Donation[]>([]);
  const [impact, setImpact] = useState<ImpactMetrics | null>(null);
  const [auditLogs, setAuditLogs] = useState<AuditLogItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [filter, setFilter] = useState<string>('ALL');

  const loadData = async () => {
    try {
      setLoading(true);
      const [dons, imp, logs] = await Promise.all([
        api.listDonations(),
        api.getImpactMetrics(),
        api.getAuditLogs(10),
      ]);
      setDonations(dons);
      setImpact(imp);
      setAuditLogs(logs);
    } catch (err) {
      console.error('Failed to load dashboard data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const filteredDonations = filter === 'ALL'
    ? donations
    : donations.filter((d) => d.status === filter);

  return (
    <div className="space-y-6">
      {/* Top Welcome & Actions Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">FoodBridge Command Center</h1>
          <p className="text-sm text-slate-500 mt-1">
            Real-time surplus food coordination driven by Strands Decider 2B and Amazon Bedrock.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={loadData}
            className="p-2 text-slate-500 hover:text-slate-800 rounded-lg hover:bg-slate-100 border border-slate-200 transition-colors"
            title="Refresh Data"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
          <button
            onClick={() => onNavigate('donate')}
            className="flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-sm font-semibold shadow-sm transition-all"
          >
            <UtensilsCrossed className="w-4 h-4" />
            Register Surplus
          </button>
        </div>
      </div>

      {/* Impact Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Completed Pickups</span>
            <div className="p-2 rounded-lg bg-emerald-50 text-emerald-600">
              <CheckCircle className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold text-slate-900">{impact?.completed_pickups ?? 0}</div>
            <p className="text-xs text-slate-500 mt-1">
              Collection Rate: <strong className="text-emerald-700">{impact?.collection_rate_percent ?? 0}%</strong>
            </p>
          </div>
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-emerald-500" />
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Rescued Surplus</span>
            <div className="p-2 rounded-lg bg-teal-50 text-teal-600">
              <Leaf className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold text-slate-900">{impact?.total_kg_rescued ?? 0} <span className="text-sm font-normal text-slate-500">kg</span></div>
            <p className="text-xs text-slate-500 mt-1">
              Avoided CO2e: <strong className="text-teal-700">{impact?.co2_avoided_kg ?? 0} kg</strong>
            </p>
          </div>
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-teal-500" />
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Est. Meals Served</span>
            <div className="p-2 rounded-lg bg-amber-50 text-amber-600">
              <UtensilsCrossed className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold text-slate-900">{impact?.estimated_meals_served?.toLocaleString() ?? 0}</div>
            <p className="text-[11px] text-slate-500 mt-1">
              Serving assumption: <strong>{impact?.serving_size_assumed_kg ? (impact.serving_size_assumed_kg * 1000) : 400}g / meal</strong>
            </p>
          </div>
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-amber-500" />
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Active Pipeline</span>
            <div className="p-2 rounded-lg bg-blue-50 text-blue-600">
              <Truck className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold text-slate-900">
              {(impact?.pending_offers ?? 0) + (impact?.in_transit ?? 0)}
            </div>
            <p className="text-xs text-slate-500 mt-1">
              In transit: <strong className="text-blue-700">{impact?.in_transit ?? 0}</strong> | Pending: <strong className="text-purple-700">{impact?.pending_offers ?? 0}</strong>
            </p>
          </div>
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-blue-500" />
        </div>
      </div>

      {/* Main Grid: Surplus Feed & Audit Sidebar */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Surplus Feed */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col">
          <div className="p-5 border-b border-slate-100 flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 className="text-base font-bold text-slate-900">Surplus Food Pipeline</h2>
              <p className="text-xs text-slate-500 mt-0.5">Track donation lifecycle from donor submission to pickup verification.</p>
            </div>

            {/* Filter Pills */}
            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg text-xs font-medium">
              {['ALL', 'PROPOSED', 'ACCEPTED', 'IN_TRANSIT', 'COLLECTED'].map((f) => (
                <button
                  key={f}
                  onClick={() => setFilter(f)}
                  className={`px-2.5 py-1 rounded-md transition-all ${
                    filter === f
                      ? 'bg-white text-slate-900 shadow-xs font-semibold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {f.replace('_', ' ')}
                </button>
              ))}
            </div>
          </div>

          <div className="divide-y divide-slate-100 flex-1 overflow-y-auto max-h-[520px]">
            {filteredDonations.length === 0 ? (
              <div className="p-8 text-center text-slate-400 text-sm">
                No surplus food items match the selected filter.
              </div>
            ) : (
              filteredDonations.map((don) => (
                <div key={don.id} className="p-4 hover:bg-slate-50/80 transition-colors flex items-start justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold text-slate-900 text-sm">{don.food_title}</h3>
                      <StatusBadge status={don.status} />
                    </div>
                    <p className="text-xs text-slate-600 flex items-center gap-3">
                      <span>Donor: <strong>{don.donor_name}</strong> ({don.donor_type})</span>
                      <span>•</span>
                      <span>Qty: <strong>{don.quantity_value} {don.quantity_unit}</strong></span>
                      <span>•</span>
                      <span>Type: <strong>{don.food_category}</strong></span>
                    </p>
                    <p className="text-[11px] text-slate-400 flex items-center gap-1.5">
                      <Clock className="w-3 h-3" />
                      <span>Pickup deadline: {new Date(don.pickup_deadline).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                      <span>•</span>
                      <span>{don.donor_address}</span>
                    </p>
                  </div>

                  <div className="flex flex-col items-end gap-1.5 shrink-0">
                    {don.status === 'PROPOSED' && (
                      <button
                        onClick={() => onNavigate('matches', don.id)}
                        className="flex items-center gap-1 px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 rounded-lg text-xs font-semibold transition-colors"
                      >
                        <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                        Match AI
                      </button>
                    )}
                    {don.status === 'ACCEPTED' && (
                      <button
                        onClick={() => onNavigate('pickups', don.id)}
                        className="flex items-center gap-1 px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-lg text-xs font-semibold transition-colors"
                      >
                        <Truck className="w-3.5 h-3.5 text-indigo-600" />
                        Track Pickup
                      </button>
                    )}
                    {don.status === 'IN_TRANSIT' && (
                      <button
                        onClick={() => onNavigate('pickups', don.id)}
                        className="flex items-center gap-1 px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 rounded-lg text-xs font-semibold transition-colors"
                      >
                        <CheckCircle className="w-3.5 h-3.5 text-blue-600" />
                        Verify Code
                      </button>
                    )}
                    {don.pickup_verification_code && don.status !== 'COLLECTED' && (
                      <span className="text-[11px] font-mono text-slate-500 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                        Code: {don.pickup_verification_code}
                      </span>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Right 1 Col: Audit & AI Event Stream */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5 flex flex-col">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Decision & Safety Audit Log</h2>
              <p className="text-[11px] text-slate-500">Immutable trace of AI decisions & overrides</p>
            </div>
            <button
              onClick={() => onNavigate('reviews')}
              className="text-xs text-emerald-600 hover:text-emerald-700 font-semibold flex items-center gap-1"
            >
              Queue <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <div className="space-y-3 mt-4 flex-1 overflow-y-auto max-h-[460px]">
            {auditLogs.length === 0 ? (
              <p className="text-xs text-slate-400 text-center py-4">No recent audit events.</p>
            ) : (
              auditLogs.map((log) => (
                <div key={log.id} className="text-xs p-3 rounded-lg bg-slate-50 border border-slate-100 space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-slate-800 uppercase tracking-tight text-[10px] px-1.5 py-0.5 rounded bg-white border border-slate-200">
                      {log.actor_role}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {new Date(log.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                    </span>
                  </div>
                  <p className="text-slate-600 leading-snug font-medium">{log.details}</p>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
