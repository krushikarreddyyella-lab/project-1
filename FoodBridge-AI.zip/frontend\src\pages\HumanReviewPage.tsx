import React, { useState, useEffect } from 'react';
import { 
  ShieldAlert, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  Sparkles, 
  Clock, 
  UserCheck, 
  RefreshCw,
  History,
  Info
} from 'lucide-react';
import { HumanReviewCase, AuditLogItem } from '../types';
import { api } from '../api/client';
import { DecisionBadge } from '../components/DecisionBadge';

export const HumanReviewPage: React.FC = () => {
  const [cases, setCases] = useState<HumanReviewCase[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLogItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'queue' | 'audit'>('queue');
  const [resolvingId, setResolvingId] = useState<string | null>(null);
  const [reviewerNotes, setReviewerNotes] = useState<Record<string, string>>({});
  const [notification, setNotification] = useState<{ text: string; isError?: boolean } | null>(null);

  const loadData = async () => {
    try {
      setLoading(true);
      const [queueData, logs] = await Promise.all([
        api.getHumanReviewQueue(),
        api.getAuditLogs(50),
      ]);
      setCases(queueData);
      setAuditLogs(logs);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleResolve = async (matchId: string, action: 'APPROVE' | 'REJECT') => {
    const notes = reviewerNotes[matchId] || 'Approved after logistics coordination check.';
    try {
      setResolvingId(matchId);
      setNotification(null);
      const res = await api.resolveHumanReview(matchId, action, notes);
      setNotification({ text: res.message });
      loadData();
    } catch (err: any) {
      setNotification({ text: err.message, isError: true });
    } finally {
      setResolvingId(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-amber-50 text-amber-600 rounded-xl">
            <ShieldAlert className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900">Decision Audit & Human Review Queue</h1>
            <p className="text-xs text-slate-500 mt-0.5">
              Escalated low-confidence or time-critical cases requiring human authorization before dispatch.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center bg-slate-100 p-1 rounded-lg text-xs font-semibold">
            <button
              onClick={() => setActiveTab('queue')}
              className={`px-3 py-1.5 rounded-md transition-all ${
                activeTab === 'queue' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
              }`}
            >
              Review Queue ({cases.length})
            </button>
            <button
              onClick={() => setActiveTab('audit')}
              className={`px-3 py-1.5 rounded-md transition-all ${
                activeTab === 'audit' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
              }`}
            >
              Audit Trail ({auditLogs.length})
            </button>
          </div>

          <button
            onClick={loadData}
            className="p-2 text-slate-500 hover:text-slate-800 rounded-lg hover:bg-slate-100 border border-slate-200"
            title="Refresh"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {notification && (
        <div className={`p-4 rounded-xl flex items-center gap-2 text-sm font-medium ${
          notification.isError
            ? 'bg-rose-50 text-rose-800 border border-rose-200'
            : 'bg-emerald-50 text-emerald-800 border border-emerald-200'
        }`}>
          {notification.isError ? <AlertTriangle className="w-4 h-4 shrink-0" /> : <CheckCircle2 className="w-4 h-4 shrink-0" />}
          <span>{notification.text}</span>
        </div>
      )}

      {/* Tab 1: Human Review Queue */}
      {activeTab === 'queue' && (
        <div className="space-y-4">
          {loading ? (
            <div className="p-12 text-center text-slate-400 text-sm">Loading review queue...</div>
          ) : cases.length === 0 ? (
            <div className="bg-white p-12 rounded-2xl border border-slate-200 text-center space-y-2">
              <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto" />
              <h3 className="font-bold text-slate-800 text-base">Human Review Queue is Clear!</h3>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                All proposed matches satisfied high-confidence Strands Decider 2B thresholds or have already been resolved by coordinators.
              </p>
            </div>
          ) : (
            cases.map((c) => (
              <div key={c.match_id} className="bg-white p-6 rounded-2xl border border-amber-200 shadow-xs space-y-4">
                <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4 pb-3 border-b border-slate-100">
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-bold text-slate-900 text-base">{c.donation_title}</h3>
                      <DecisionBadge decision={c.decider_decision} confidence={c.decider_confidence} />
                    </div>
                    <p className="text-xs text-slate-500 mt-1">
                      Matched with: <strong className="text-slate-800">{c.recipient_name}</strong> ({c.recipient_type}) • Distance: {c.distance_km.toFixed(1)} km
                    </p>
                  </div>

                  <span className="text-[11px] font-mono text-slate-400">
                    Escalated {new Date(c.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                  {/* AI Decision Rationale */}
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                    <span className="font-semibold text-slate-700 block">Strands Decider 2B Rationale Factors:</span>
                    <p className="text-slate-600 leading-relaxed">{c.decider_rationale}</p>
                  </div>

                  {/* Bedrock explanation */}
                  <div className="p-3 bg-amber-50/50 rounded-xl border border-amber-200 space-y-1">
                    <span className="font-semibold text-amber-800 flex items-center gap-1">
                      <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                      Bedrock Coordinator Advisory:
                    </span>
                    <p className="text-amber-900 italic leading-relaxed">"{c.bedrock_explanation}"</p>
                  </div>
                </div>

                {/* Resolution Form */}
                <div className="pt-3 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-3">
                  <div className="w-full sm:w-2/3">
                    <input
                      type="text"
                      placeholder="Add reviewer notes (e.g. Phone confirmed driver available)..."
                      value={reviewerNotes[c.match_id] || ''}
                      onChange={(e) => setReviewerNotes({ ...reviewerNotes, [c.match_id]: e.target.value })}
                      className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-amber-500 focus:outline-none"
                    />
                  </div>

                  <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                    <button
                      onClick={() => handleResolve(c.match_id, 'REJECT')}
                      disabled={resolvingId === c.match_id}
                      className="flex items-center gap-1 px-3 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-lg text-xs font-semibold transition-colors"
                    >
                      <XCircle className="w-3.5 h-3.5" />
                      Reject Match
                    </button>

                    <button
                      onClick={() => handleResolve(c.match_id, 'APPROVE')}
                      disabled={resolvingId === c.match_id}
                      className="flex items-center gap-1 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold shadow-sm transition-all"
                    >
                      <UserCheck className="w-3.5 h-3.5" />
                      Approve & Offer
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Tab 2: Full Audit Trail */}
      {activeTab === 'audit' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="p-4 border-b border-slate-100 flex items-center justify-between">
            <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <History className="w-4 h-4 text-slate-500" />
              Full System Audit Trail
            </h2>
            <span className="text-xs text-slate-400">Total logged entries: {auditLogs.length}</span>
          </div>

          <div className="divide-y divide-slate-100 overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 font-semibold uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="py-3 px-4">Timestamp</th>
                  <th className="py-3 px-4">Actor</th>
                  <th className="py-3 px-4">Event Type</th>
                  <th className="py-3 px-4">Entity</th>
                  <th className="py-3 px-4">Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {auditLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-50/50">
                    <td className="py-2.5 px-4 font-mono text-slate-400 whitespace-nowrap">
                      {new Date(log.created_at).toLocaleString([], { dateStyle: 'short', timeStyle: 'medium' })}
                    </td>
                    <td className="py-2.5 px-4 font-bold text-slate-800">
                      <span className="px-2 py-0.5 rounded bg-slate-100 border border-slate-200 text-[10px]">
                        {log.actor_role}
                      </span>
                    </td>
                    <td className="py-2.5 px-4 font-semibold text-slate-700">{log.event_type}</td>
                    <td className="py-2.5 px-4 text-slate-500 font-mono text-[11px]">{log.entity_type} ({log.entity_id.slice(0, 8)})</td>
                    <td className="py-2.5 px-4 text-slate-600 max-w-md truncate">{log.details}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
