import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { SystemModeBanner } from './components/SystemModeBanner';
import { DashboardPage } from './pages/DashboardPage';
import { DonateFoodPage } from './pages/DonateFoodPage';
import { MatchingHubPage } from './pages/MatchingHubPage';
import { RecipientDirectoryPage } from './pages/RecipientDirectoryPage';
import { PickupTrackerPage } from './pages/PickupTrackerPage';
import { HumanReviewPage } from './pages/HumanReviewPage';
import { ImpactAnalyticsPage } from './pages/ImpactAnalyticsPage';
import { EvaluationPage } from './pages/EvaluationPage';
import { api } from './api/client';

export function App() {
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [contextId, setContextId] = useState<string | undefined>();
  const [reviewCount, setReviewCount] = useState<number>(0);
  const [isLiveBedrock, setIsLiveBedrock] = useState<boolean>(false);

  const fetchStatus = async () => {
    try {
      const [status, queue] = await Promise.all([
        api.getSystemStatus(),
        api.getHumanReviewQueue(),
      ]);
      setIsLiveBedrock(Boolean(status?.ai_engine?.is_live_bedrock));
      setReviewCount(queue.length);
    } catch (err) {
      console.warn('System status check error:', err);
    }
  };

  useEffect(() => {
    fetchStatus();
    const interval = setInterval(fetchStatus, 30000);
    return () => clearInterval(interval);
  }, []);

  const handleNavigate = (tab: string, id?: string) => {
    if (id) setContextId(id);
    setActiveTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 font-sans">
      <SystemModeBanner isLiveBedrock={isLiveBedrock} />
      <Navbar
        activeTab={activeTab}
        setActiveTab={(t) => {
          setActiveTab(t);
          setContextId(undefined);
        }}
        reviewCount={reviewCount}
      />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'dashboard' && <DashboardPage onNavigate={handleNavigate} />}
        {activeTab === 'donate' && (
          <DonateFoodPage
            onSuccess={(newId) => handleNavigate('matches', newId)}
          />
        )}
        {activeTab === 'matches' && (
          <MatchingHubPage
            initialDonationId={contextId}
            onNavigate={handleNavigate}
          />
        )}
        {activeTab === 'recipients' && <RecipientDirectoryPage />}
        {activeTab === 'pickups' && (
          <PickupTrackerPage
            initialDonationId={contextId}
            onNavigate={handleNavigate}
          />
        )}
        {activeTab === 'reviews' && <HumanReviewPage />}
        {activeTab === 'impact' && <ImpactAnalyticsPage />}
        {activeTab === 'eval' && <EvaluationPage />}
      </main>

      <footer className="bg-white border-t border-slate-200 py-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>FoodBridge AI • Surplus Food Donation Management System</span>
          <span className="font-mono text-[11px] text-slate-400">
            Powered by Strands Decider 2B & Amazon Bedrock
          </span>
        </div>
      </footer>
    </div>
  );
}

export default App;
