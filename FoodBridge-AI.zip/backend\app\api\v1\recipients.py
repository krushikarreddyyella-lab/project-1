from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.db.repositories.recipient_repo import RecipientRepository
from app.models.recipient import Recipient
from app.schemas.recipient import RecipientCreate, RecipientResponse

router = APIRouter()


@router.post("/", response_model=RecipientResponse)
def create_recipient(payload: RecipientCreate, db: Session = Depends(get_db)):
    repo = RecipientRepository(db)
    recipient = Recipient(
        name=payload.name,
        organization_type=payload.organization_type,
        contact_person=payload.contact_person,
        contact_phone=payload.contact_phone,
        contact_email=payload.contact_email,
        address=payload.address,
        latitude=payload.latitude,
        longitude=payload.longitude,
        is_verified=payload.is_verified,
        daily_capacity_kg=payload.daily_capacity_kg,
        current_capacity_used_kg=payload.current_capacity_used_kg,
        has_cold_storage=payload.has_cold_storage,
        has_transportation=payload.has_transportation,
        accepted_categories=payload.accepted_categories,
        operating_hours_start=payload.operating_hours_start,
        operating_hours_end=payload.operating_hours_end,
        reliability_score=payload.reliability_score
    )
    return repo.create(recipient)


@router.get("/", response_model=List[RecipientResponse])
def list_recipients(db: Session = Depends(get_db)):
    repo = RecipientRepository(db)
    return repo.get_all(limit=100)


@router.get("/{recipient_id}", response_model=RecipientResponse)
def get_recipient(recipient_id: str, db: Session = Depends(get_db)):
    repo = RecipientRepository(db)
    rec = repo.get(recipient_id)
    if not rec:
        raise HTTPException(status_code=404, detail="Recipient organization not found")
    return rec
