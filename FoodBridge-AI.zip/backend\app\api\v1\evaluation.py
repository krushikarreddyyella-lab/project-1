from fastapi import APIRouter
from app.services.eval_service import EvaluationBenchmarkService

router = APIRouter()


@router.post("/run-benchmark")
def run_evaluation_benchmark():
    return EvaluationBenchmarkService.run_benchmark()


@router.get("/test-cases")
def get_evaluation_test_cases():
    raw_cases = EvaluationBenchmarkService.get_test_dataset()
    return [
        {
            "case_id": c["case_id"],
            "name": c["name"],
            "ground_truth": c["ground_truth"],
            "donation_title": c["donation"].food_title,
            "quantity": f"{c['donation'].quantity_value} {c['donation'].quantity_unit}",
            "food_category": c["donation"].food_category,
            "recipient_name": c["recipient"].name,
            "is_verified": c["recipient"].is_verified
        }
        for c in raw_cases
    ]
