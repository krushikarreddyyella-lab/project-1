import uuid
from datetime import datetime
from sqlalchemy import Column, String, Float, DateTime, Text, Enum
from app.db.session import Base


class Donation(Base):
    __tablename__ = "donations"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    donor_name = Column(String(128), nullable=False)
    donor_type = Column(String(64), nullable=False)  # Restaurant, Hostel, Wedding/Event, Cafeteria
    donor_contact = Column(String(64), nullable=False)
    donor_address = Column(String(255), nullable=False)
    latitude = Column(Float, nullable=False, default=12.9716)
    longitude = Column(Float, nullable=False, default=77.5946)

    food_title = Column(String(255), nullable=False)
    food_category = Column(String(64), nullable=False)  # Cooked Meals, Bakery, Produce, Dairy, Packaged
    quantity_value = Column(Float, nullable=False)
    quantity_unit = Column(String(32), nullable=False, default="kg")  # kg or servings
    storage_requirement = Column(String(32), nullable=False, default="ROOM_TEMP")  # ROOM_TEMP, REFRIGERATED, FROZEN, HOT_HOLDING
    dietary_type = Column(String(32), nullable=False, default="VEGETARIAN")  # VEGETARIAN, VEGAN, NON_VEG, HALAL

    preparation_time = Column(DateTime, nullable=False)
    pickup_deadline = Column(DateTime, nullable=False)
    
    # Lifecycle status: PROPOSED, MATCHED, ACCEPTED, IN_TRANSIT, COLLECTED, REJECTED, EXPIRED, CANCELLED
    status = Column(String(32), nullable=False, default="PROPOSED")
    pickup_verification_code = Column(String(16), nullable=True)
    handling_instructions = Column(Text, nullable=True)

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    collected_at = Column(DateTime, nullable=True)
