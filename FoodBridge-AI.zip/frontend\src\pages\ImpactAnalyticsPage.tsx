import React, { useState, useEffect } from 'react';
import { 
  BarChart3, 
  Leaf, 
  UtensilsCrossed, 
  CheckCircle, 
  Sparkles, 
  TrendingUp, 
  FileText, 
  Settings2,
  RefreshCw,
  PieChart
} from 'lucide-react';
import { ImpactMetrics, BedrockImpactReport } from '../types';
import { api } from '../api/client';

export const ImpactAnalyticsPage: React.FC = () => {
  const [metrics, setMetrics] = useState<ImpactMetrics | null>(null);
  const [report, setReport] = useState<BedrockImpactReport | null>(null);
  const [servingSize, setServingSize] = useState<number>(0.40);
  const [loading, setLoading] = useState(true);
  const [generatingReport, setGeneratingReport] = useState(false);

  const loadMetrics = async (size: number) => {
    try {
      setLoading(true);
      const data = await api.getImpactMetrics(size);
      setMetrics(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadMetrics(servingSize);
  }, [servingSize]);

  const handleGenerateReport = async () => {
    try {
      setGeneratingReport(true);
      const rep = await api.getBedrockImpactReport(servingSize);
      setReport(rep);
    } catch (err) {
      console.error(err);
    } finally {
      setGeneratingReport(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl">
            <BarChart3 className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900">Community Impact & Rescued Surplus Analytics</h1>
            <p className="text-xs text-slate-500 mt-0.5">
              Strict isolation of verified collections. Pending offers and in-transit items are never counted as impact.
            </p>
          </div>
        </div>

        {/* Serving Size Parameter Selector */}
        <div className="flex items-center gap-3 bg-slate-50 p-2 rounded-xl border border-slate-200">
          <Settings2 className="w-4 h-4 text-slate-400" />
          <div className="flex flex-col">
            <label className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
              Serving Assumption:
            </label>
            <div className="flex items-center gap-2">
              <input
                type="range"
                min="0.25"
                max="0.60"
                step="0.05"
                value={servingSize}
                onChange={(e) => setServingSize(parseFloat(e.target.value))}
                className="w-24 accent-emerald-600 cursor-pointer"
              />
              <span className="text-xs font-bold text-slate-800 font-mono">
                {(servingSize * 1000).toFixed(0)}g / meal
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Primary KPI Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-xs font-semibold text-slate-500 uppercase">
            <span>Verified Rescued Food</span>
            <Leaf className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="mt-3 text-3xl font-extrabold text-slate-900">
            {metrics?.total_kg_rescued ?? 0} <span className="text-sm font-normal text-slate-400">kg</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1">Strictly from completed pickups</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-xs font-semibold text-slate-500 uppercase">
            <span>Estimated Meals Served</span>
            <UtensilsCrossed className="w-4 h-4 text-amber-600" />
          </div>
          <div className="mt-3 text-3xl font-extrabold text-slate-900">
            {metrics?.estimated_meals_served?.toLocaleString() ?? 0}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            Calculated as Rescued kg ÷ {servingSize} kg/meal
          </p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-xs font-semibold text-slate-500 uppercase">
            <span>CO2e Landfill Diverted</span>
            <TrendingUp className="w-4 h-4 text-teal-600" />
          </div>
          <div className="mt-3 text-3xl font-extrabold text-slate-900">
            {metrics?.co2_avoided_kg ?? 0} <span className="text-sm font-normal text-slate-400">kg</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1">2.5 kg CO2e saved per kg food</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-xs font-semibold text-slate-500 uppercase">
            <span>Collection Efficiency</span>
            <CheckCircle className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="mt-3 text-3xl font-extrabold text-slate-900">
            {metrics?.collection_rate_percent ?? 0}%
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            {metrics?.completed_pickups ?? 0} collected / {(metrics?.completed_pickups ?? 0) + (metrics?.rejected_or_expired ?? 0)} finalized
          </p>
        </div>
      </div>

      {/* Breakdown Details */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Status Distribution */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h2 className="text-sm font-bold text-slate-900">Donation Lifecycle Isolation</h2>
            <span className="text-xs text-slate-400">Total: {metrics?.total_donations}</span>
          </div>

          <div className="space-y-3">
            {metrics?.status_breakdown &&
              Object.entries(metrics.status_breakdown).map(([status, count]) => {
                const total = metrics.total_donations || 1;
                const pct = Math.round((count / total) * 100);

                return (
                  <div key={status} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-slate-700">{status}</span>
                      <span className="font-mono text-slate-500">
                        {count} ({pct}%)
                      </span>
                    </div>
                    <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full ${
                          status === 'COLLECTED'
                            ? 'bg-emerald-500'
                            : status === 'IN_TRANSIT'
                            ? 'bg-blue-500'
                            : status === 'ACCEPTED'
                            ? 'bg-indigo-500'
                            : status === 'PROPOSED'
                            ? 'bg-purple-500'
                            : 'bg-slate-300'
                        }`}
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>
                );
              })}
          </div>
          <div className="p-3 bg-slate-50 rounded-xl text-[11px] text-slate-500">
            <strong>Methodology Notice:</strong> Estimated meals served is an analytical approximation based on {servingSize * 1000}g portions, not a verified count of unique individuals fed. Pending offers and in-transit items remain excluded until collection handoff is verified.
          </div>
        </div>

        {/* Rescued Categories */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h2 className="text-sm font-bold text-slate-900">Rescued Food By Category (kg)</h2>
            <span className="text-xs text-slate-400">Completed Pickups Only</span>
          </div>

          <div className="space-y-3">
            {metrics?.category_breakdown && Object.keys(metrics.category_breakdown).length > 0 ? (
              Object.entries(metrics.category_breakdown).map(([cat, kg]) => (
                <div key={cat} className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-100 text-xs">
                  <span className="font-semibold text-slate-800">{cat}</span>
                  <div className="flex items-center gap-3">
                    <span className="font-bold text-emerald-700">{kg} kg</span>
                    <span className="text-slate-400 font-mono">
                      ~{Math.round(kg / servingSize)} meals
                    </span>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-xs text-slate-400 py-6 text-center">
                No collected food records available yet. Complete a pickup to record category metrics.
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Amazon Bedrock Impact Narrative Generator */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-4 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-amber-50 text-amber-600">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">Amazon Bedrock Impact Synthesis</h2>
              <p className="text-xs text-slate-500">
                Generates executive summaries, meal narratives, and ESG reporting recommendations.
              </p>
            </div>
          </div>

          <button
            onClick={handleGenerateReport}
            disabled={generatingReport}
            className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white rounded-xl text-xs font-semibold shadow-sm transition-all disabled:opacity-50"
          >
            <Sparkles className="w-4 h-4" />
            {generatingReport ? 'Synthesizing with Bedrock...' : 'Generate Impact Narrative'}
          </button>
        </div>

        {report && (
          <div className="space-y-4 pt-2">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>Generated on: {report.generated_at}</span>
              <span className="px-2 py-0.5 rounded bg-slate-100 font-semibold text-slate-700">
                {report.is_live_bedrock ? 'AWS Bedrock Live' : 'Deterministic Bedrock Fallback'}
              </span>
            </div>

            <div className="p-4 bg-amber-50/40 rounded-xl border border-amber-200/80 space-y-2 text-xs">
              <h3 className="font-bold text-amber-900 text-sm">Executive Impact Summary</h3>
              <p className="text-amber-950 leading-relaxed">{report.executive_summary}</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                <h4 className="font-bold text-slate-800">Operational Highlights</h4>
                <ul className="list-disc list-inside space-y-1 text-slate-600">
                  {report.highlights.map((h, i) => (
                    <li key={i}>{h}</li>
                  ))}
                </ul>
              </div>

              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                <h4 className="font-bold text-slate-800">ESG & Logistics Advice</h4>
                <ul className="list-disc list-inside space-y-1 text-slate-600">
                  {report.esg_recommendations.map((rec, i) => (
                    <li key={i}>{rec}</li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-xs text-emerald-800">
              <strong>Meals Narrative:</strong> {report.meals_served_narrative}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
