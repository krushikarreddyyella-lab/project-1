import json
from datetime import datetime
from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.db.repositories.donation_repo import DonationRepository
from app.db.repositories.recipient_repo import RecipientRepository
from app.db.repositories.match_repo import MatchDecisionRepository
from app.db.repositories.audit_repo import AuditRepository
from app.models.match_decision import MatchDecision
from app.models.audit_log import AuditLog
from app.schemas.match import MatchCandidate
from app.schemas.recipient import RecipientResponse
from app.schemas.decider import DeciderOutput, SafetyCheckResult
from app.services.safety_engine import SafetyEngine, haversine_distance_km
from app.services.decider_service import StrandsDecider2BService
from app.services.bedrock_service import BedrockService

router = APIRouter()
decider_service = StrandsDecider2BService()
bedrock_service = BedrockService()


@router.post("/evaluate/{donation_id}", response_model=List[MatchCandidate])
def evaluate_donation_matches(donation_id: str, db: Session = Depends(get_db)):
    don_repo = DonationRepository(db)
    rec_repo = RecipientRepository(db)
    match_repo = MatchDecisionRepository(db)
    audit_repo = AuditRepository(db)

    donation = don_repo.get(donation_id)
    if not donation:
        raise HTTPException(status_code=404, detail="Donation not found")

    recipients = rec_repo.get_all(limit=50)
    if not recipients:
        return []

    results = []
    now = datetime.utcnow()
    hours_left = max(0.0, (donation.pickup_deadline - now).total_seconds() / 3600.0)

    for recipient in recipients:
        # 1. Deterministic Hard Safety Guardrails
        safety_result = SafetyEngine.evaluate_safety(donation, recipient, now=now)
        
        # 2. State representation & Decider 2B classification
        state = decider_service.build_state_vector(donation, recipient, safety_result, now=now)
        decider_output = decider_service.classify_policy(state)

        # 3. Amazon Bedrock Generative Explanation & Notification
        explanation, notification, b_latency, is_live = bedrock_service.generate_match_explanation(
            donation_title=donation.food_title,
            food_category=donation.food_category,
            quantity_str=f"{donation.quantity_value} {donation.quantity_unit}",
            recipient_name=recipient.name,
            distance_km=state.distance_km,
            deadline_hours=hours_left,
            decider_decision=decider_output.decision.value,
            decider_confidence=decider_output.confidence,
            policy_factors=decider_output.primary_factors
        )

        # Determine workflow match status
        if not safety_result.passed or decider_output.decision.value == "REJECT":
            match_status = "EXCLUDED"
        elif decider_output.decision.value == "HUMAN_REVIEW":
            match_status = "ESCALATED"
        else:
            match_status = "OFFERED"

        # Record or update in database
        match_record = MatchDecision(
            donation_id=donation.id,
            recipient_id=recipient.id,
            distance_km=state.distance_km,
            capacity_fit=safety_result.checks.get("capacity_available", False),
            storage_fit=safety_result.checks.get("storage_compatible", False),
            safety_check_passed=safety_result.passed,
            safety_check_details=json.dumps(safety_result.checks),
            decider_decision=decider_output.decision.value,
            decider_confidence=decider_output.confidence,
            decider_rationale="; ".join(decider_output.primary_factors),
            decider_latency_ms=decider_output.latency_ms,
            bedrock_explanation=explanation,
            bedrock_notification=notification,
            bedrock_latency_ms=b_latency,
            is_live_bedrock=is_live,
            match_status=match_status
        )
        saved = match_repo.create(match_record)

        audit_repo.create(AuditLog(
            event_type="MATCH_EVALUATED",
            entity_type="match",
            entity_id=saved.id,
            actor_role="DECIDER_2B",
            details=f"Decision: {decider_output.decision.value} ({decider_output.confidence:.0%}) for recipient {recipient.name}"
        ))

        results.append(MatchCandidate(
            id=saved.id,
            donation_id=donation.id,
            recipient=RecipientResponse.from_orm(recipient),
            distance_km=state.distance_km,
            capacity_fit=match_record.capacity_fit,
            storage_fit=match_record.storage_fit,
            safety_result=safety_result,
            decider_output=decider_output,
            bedrock_explanation=explanation,
            bedrock_notification=notification,
            bedrock_latency_ms=b_latency,
            is_live_bedrock=is_live,
            match_status=match_status,
            created_at=saved.created_at
        ))

    # If any approved offer was generated, update donation status to MATCHED
    if any(r.decider_output.decision.value == "APPROVE" for r in results):
        if donation.status == "PROPOSED":
            donation.status = "MATCHED"
            don_repo.update(donation)

    # Sort results: APPROVE first (descending confidence), then HUMAN_REVIEW, then REJECT
    decision_priority = {"APPROVE": 0, "HUMAN_REVIEW": 1, "REJECT": 2}
    results.sort(key=lambda x: (decision_priority.get(x.decider_output.decision.value, 3), -x.decider_output.confidence, x.distance_km))

    return results


@router.post("/{match_id}/accept")
def accept_match(match_id: str, db: Session = Depends(get_db)):
    match_repo = MatchDecisionRepository(db)
    don_repo = DonationRepository(db)
    rec_repo = RecipientRepository(db)
    audit_repo = AuditRepository(db)

    match = match_repo.get(match_id)
    if not match:
        raise HTTPException(status_code=404, detail="Match not found")

    donation = don_repo.get(match.donation_id)
    recipient = rec_repo.get(match.recipient_id)

    # Hard safety check confirmation
    if not match.safety_check_passed:
        raise HTTPException(status_code=400, detail="Cannot accept a match that failed deterministic safety guardrails.")

    match.match_status = "ACCEPTED"
    match_repo.update(match)

    if donation:
        donation.status = "ACCEPTED"
        don_repo.update(donation)

    # Update recipient's utilized capacity
    if recipient and donation:
        qty_kg = donation.quantity_value if donation.quantity_unit == "kg" else (donation.quantity_value * 0.40)
        recipient.current_capacity_used_kg = min(recipient.daily_capacity_kg, recipient.current_capacity_used_kg + qty_kg)
        rec_repo.update(recipient)

    audit_repo.create(AuditLog(
        event_type="MATCH_ACCEPTED",
        entity_type="match",
        entity_id=match.id,
        actor_role="RECIPIENT",
        details=f"Recipient {recipient.name if recipient else 'Unknown'} accepted donation."
    ))

    return {
        "success": True,
        "message": f"Match accepted! Pickup verification code is {donation.pickup_verification_code}.",
        "donation_id": donation.id if donation else None,
        "pickup_verification_code": donation.pickup_verification_code if donation else None,
        "status": donation.status if donation else "ACCEPTED"
    }
