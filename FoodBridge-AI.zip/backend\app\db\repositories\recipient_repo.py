from typing import List, Optional
from sqlalchemy.orm import Session
from app.db.repositories.base_repo import BaseRepository
from app.models.recipient import Recipient


class RecipientRepository(BaseRepository[Recipient]):
    def __init__(self, db: Session):
        super().__init__(Recipient, db)

    def get_verified(self) -> List[Recipient]:
        return self.db.query(Recipient).filter(Recipient.is_verified == True).all()

    def get_with_available_capacity(self, required_kg: float) -> List[Recipient]:
        return self.db.query(Recipient).filter(
            Recipient.is_verified == True,
            (Recipient.daily_capacity_kg - Recipient.current_capacity_used_kg) >= required_kg
        ).all()
