"""
FoodBridge AI - Realistic Seed Data
DEMO NOTICE: All donor names, recipient organizations, addresses, and contacts are fictional.
"""

from datetime import datetime, timedelta
from app.db.session import SessionLocal, Base, engine
from app.models.recipient import Recipient
from app.models.donation import Donation
from app.models.audit_log import AuditLog


def seed_database():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()

    # Clear existing if needed
    if db.query(Recipient).count() > 0:
        print("[Seed] Database already seeded. Skipping.")
        db.close()
        return

    now = datetime.utcnow()

    # Seed Recipient Organizations (Fictional)
    recipients = [
        Recipient(
            id="rec-001",
            name="Hope Community Kitchen (Fictional NGO)",
            organization_type="Community Kitchen",
            contact_person="Anita Sharma",
            contact_phone="+91 98450 11001",
            contact_email="contact@hopekitchen-demo.org",
            address="14 Central Avenue, Richmond Town",
            latitude=12.9667,
            longitude=77.6000,
            is_verified=True,
            daily_capacity_kg=200.0,
            current_capacity_used_kg=40.0,
            has_cold_storage=True,
            has_transportation=True,
            accepted_categories="Cooked Meals,Bakery,Produce,Dairy,Packaged",
            operating_hours_start="07:00",
            operating_hours_end="22:00",
            reliability_score=0.98
        ),
        Recipient(
            id="rec-002",
            name="Sunshine Youth Shelter (Fictional NGO)",
            organization_type="Shelter",
            contact_person="Ravi Kumar",
            contact_phone="+91 98450 22002",
            contact_email="care@sunshineshelter-demo.org",
            address="88 Koramangala 4th Block",
            latitude=12.9340,
            longitude=77.6250,
            is_verified=True,
            daily_capacity_kg=80.0,
            current_capacity_used_kg=15.0,
            has_cold_storage=False,
            has_transportation=True,
            accepted_categories="Cooked Meals,Bakery,Packaged",
            operating_hours_start="08:00",
            operating_hours_end="21:00",
            reliability_score=0.92
        ),
        Recipient(
            id="rec-003",
            name="Mercy Food Bank & Cold Store (Fictional NGO)",
            organization_type="Food Bank",
            contact_person="Sister Theresa",
            contact_phone="+91 98450 33003",
            contact_email="info@mercyfoodbank-demo.org",
            address="102 Indiranagar 100ft Road",
            latitude=12.9780,
            longitude=77.6400,
            is_verified=True,
            daily_capacity_kg=350.0,
            current_capacity_used_kg=120.0,
            has_cold_storage=True,
            has_transportation=True,
            accepted_categories="Cooked Meals,Bakery,Produce,Dairy,Packaged",
            operating_hours_start="06:00",
            operating_hours_end="23:00",
            reliability_score=0.99
        ),
        Recipient(
            id="rec-004",
            name="City Harvest Kitchen (Fictional NGO)",
            organization_type="Community Kitchen",
            contact_person="Pooja Verma",
            contact_phone="+91 98450 44004",
            contact_email="harvest@citykitchen-demo.org",
            address="45 Malleshwaram 8th Cross",
            latitude=13.0030,
            longitude=77.5700,
            is_verified=True,
            daily_capacity_kg=120.0,
            current_capacity_used_kg=25.0,
            has_cold_storage=True,
            has_transportation=False,
            accepted_categories="Cooked Meals,Produce,Packaged",
            operating_hours_start="08:30",
            operating_hours_end="20:00",
            reliability_score=0.90
        ),
        Recipient(
            id="rec-005",
            name="Unverified Neighborhood Pantry (Demo Safety Case)",
            organization_type="Shelter",
            contact_person="Arun",
            contact_phone="+91 98450 55005",
            contact_email="arun@unverified-demo.org",
            address="12 Old Airport Lane",
            latitude=12.9550,
            longitude=77.6600,
            is_verified=False,  # Intentionally unverified for safety testing
            daily_capacity_kg=50.0,
            current_capacity_used_kg=0.0,
            has_cold_storage=False,
            has_transportation=False,
            reliability_score=0.65
        )
    ]
    for r in recipients:
        db.add(r)

    # Seed Donations (Fictional)
    donations = [
        # 1. Collected donation (contributes to impact)
        Donation(
            id="don-001",
            donor_name="The Royal Palace Banquet (Fictional)",
            donor_type="Wedding/Event",
            donor_contact="+91 99000 11111",
            donor_address="Palace Grounds Gate 4, Bellary Road",
            latitude=12.9980,
            longitude=77.5920,
            food_title="North Indian Wedding Banquet Surplus (Paneer Butter Masala, Pulao, Dal Makhani)",
            food_category="Cooked Meals",
            quantity_value=65.0,
            quantity_unit="kg",
            storage_requirement="HOT_HOLDING",
            dietary_type="VEGETARIAN",
            preparation_time=now - timedelta(hours=6),
            pickup_deadline=now - timedelta(hours=2),
            status="COLLECTED",
            pickup_verification_code="4821",
            handling_instructions="Insulated food-grade stainless steel containers. Handled under warm temperature control.",
            collected_at=now - timedelta(hours=3)
        ),
        # 2. Collected donation (contributes to impact)
        Donation(
            id="don-002",
            donor_name="TechCorp Executive Cafeteria (Fictional)",
            donor_type="Cafeteria",
            donor_contact="+91 99000 22222",
            donor_address="Ecospace Business Park, Bellandur",
            latitude=12.9260,
            longitude=77.6760,
            food_title="Fresh Salad Bowls & Artisan Sandwiches",
            food_category="Cooked Meals",
            quantity_value=30.0,
            quantity_unit="kg",
            storage_requirement="REFRIGERATED",
            dietary_type="VEGETARIAN",
            preparation_time=now - timedelta(hours=8),
            pickup_deadline=now - timedelta(hours=4),
            status="COLLECTED",
            pickup_verification_code="7392",
            handling_instructions="Pre-packed in compostable containers. Kept refrigerated at 4 degrees C.",
            collected_at=now - timedelta(hours=4, minutes=30)
        ),
        # 3. In-Transit donation
        Donation(
            id="don-003",
            donor_name="Grand Heritage Bistro (Fictional)",
            donor_type="Restaurant",
            donor_contact="+91 99000 33333",
            donor_address="Lavelle Road, Shanthala Nagar",
            latitude=12.9700,
            longitude=77.5960,
            food_title="Freshly Baked Baguettes, Croissants & Breads",
            food_category="Bakery",
            quantity_value=22.0,
            quantity_unit="kg",
            storage_requirement="ROOM_TEMP",
            dietary_type="VEGETARIAN",
            preparation_time=now - timedelta(hours=2),
            pickup_deadline=now + timedelta(hours=4),
            status="IN_TRANSIT",
            pickup_verification_code="5109",
            handling_instructions="Packed in clean dry paper cartons."
        ),
        # 4. Proposed fresh surplus (ready for AI matching)
        Donation(
            id="don-004",
            donor_name="Starlight University Hostel Mess (Fictional)",
            donor_type="Hostel",
            donor_contact="+91 99000 44444",
            donor_address="Hostel Block C, University Campus",
            latitude=12.9750,
            longitude=77.6050,
            food_title="Nutritious Dinner Surplus (Rice, Sambar, Mix Veg, Chapati)",
            food_category="Cooked Meals",
            quantity_value=45.0,
            quantity_unit="kg",
            storage_requirement="ROOM_TEMP",
            dietary_type="VEGETARIAN",
            preparation_time=now - timedelta(hours=1),
            pickup_deadline=now + timedelta(hours=3, minutes=30),
            status="PROPOSED",
            pickup_verification_code="8491",
            handling_instructions="Freshly prepared evening batch. Steam vessels ready for immediate pickup."
        ),
        # 5. Tight-deadline surplus (great for human-review demonstration)
        Donation(
            id="don-005",
            donor_name="Downtown Convention Hub (Fictional)",
            donor_type="Wedding/Event",
            donor_contact="+91 99000 55555",
            donor_address="Near Metro Station, MG Road",
            latitude=12.9740,
            longitude=77.6100,
            food_title="Desserts & Pastry Platters",
            food_category="Dairy",
            quantity_value=18.0,
            quantity_unit="kg",
            storage_requirement="REFRIGERATED",
            dietary_type="VEGETARIAN",
            preparation_time=now - timedelta(hours=3),
            pickup_deadline=now + timedelta(minutes=50),  # Tight 50 mins deadline!
            status="PROPOSED",
            pickup_verification_code="6234",
            handling_instructions="Chilled pastries. Urgent collection needed within the hour."
        )
    ]
    for d in donations:
        db.add(d)

    db.commit()

    # Log initial seed event
    db.add(AuditLog(
        event_type="SYSTEM_INITIALIZED",
        entity_type="system",
        entity_id="init-001",
        actor_role="SYSTEM",
        details="Initial demo seed data populated successfully."
    ))
    db.commit()
    db.close()
    print("[Seed] Successfully seeded 5 recipients and 5 donations into SQLite database.")


if __name__ == "__main__":
    seed_database()
