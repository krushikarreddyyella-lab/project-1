import {
  Donation,
  Recipient,
  MatchCandidate,
  ImpactMetrics,
  BedrockImpactReport,
  HumanReviewCase,
  AuditLogItem,
  BenchmarkResults,
  BenchmarkCase,
  SafetyCheckResult,
  DeciderOutput,
  DeciderDecision,
  DonationStatus,
} from '../types';

const now = new Date();
const hoursAgo = (h: number) => new Date(now.getTime() - h * 3600 * 1000).toISOString();
const hoursFromNow = (h: number) => new Date(now.getTime() + h * 3600 * 1000).toISOString();
const minutesFromNow = (m: number) => new Date(now.getTime() + m * 60 * 1000).toISOString();

// Haversine distance calculation in km
export function haversineDistanceKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371.0;
  const dLat = (lat2 - lat1) * (Math.PI / 180);
  const dLon = (lon2 - lon1) * (Math.PI / 180);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * (Math.PI / 180)) *
      Math.cos(lat2 * (Math.PI / 180)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c * 10) / 10;
}

// Simulated network delay (30-80ms)
const simulateDelay = (min = 30, max = 80) =>
  new Promise<void>((resolve) =>
    setTimeout(resolve, Math.floor(Math.random() * (max - min + 1)) + min)
  );

// 1. Mock Recipient Organizations (Fictional NGO Seed Data)
export const mockRecipients: Recipient[] = [
  {
    id: 'rec-001',
    name: 'Hope Community Kitchen (Fictional NGO)',
    organization_type: 'Community Kitchen',
    contact_person: 'Anita Sharma',
    contact_phone: '+91 98450 11001',
    contact_email: 'contact@hopekitchen-demo.org',
    address: '14 Central Avenue, Richmond Town',
    latitude: 12.9667,
    longitude: 77.6,
    is_verified: true,
    daily_capacity_kg: 200.0,
    current_capacity_used_kg: 40.0,
    has_cold_storage: true,
    has_transportation: true,
    accepted_categories: 'Cooked Meals,Bakery,Produce,Dairy,Packaged',
    operating_hours_start: '07:00',
    operating_hours_end: '22:00',
    reliability_score: 0.98,
    created_at: hoursAgo(72),
  },
  {
    id: 'rec-002',
    name: 'Sunshine Youth Shelter (Fictional NGO)',
    organization_type: 'Shelter',
    contact_person: 'Ravi Kumar',
    contact_phone: '+91 98450 22002',
    contact_email: 'care@sunshineshelter-demo.org',
    address: '88 Koramangala 4th Block',
    latitude: 12.934,
    longitude: 77.625,
    is_verified: true,
    daily_capacity_kg: 80.0,
    current_capacity_used_kg: 15.0,
    has_cold_storage: false,
    has_transportation: true,
    accepted_categories: 'Cooked Meals,Bakery,Packaged',
    operating_hours_start: '08:00',
    operating_hours_end: '21:00',
    reliability_score: 0.92,
    created_at: hoursAgo(72),
  },
  {
    id: 'rec-003',
    name: 'Mercy Food Bank & Cold Store (Fictional NGO)',
    organization_type: 'Food Bank',
    contact_person: 'Sister Theresa',
    contact_phone: '+91 98450 33003',
    contact_email: 'info@mercyfoodbank-demo.org',
    address: '102 Indiranagar 100ft Road',
    latitude: 12.978,
    longitude: 77.64,
    is_verified: true,
    daily_capacity_kg: 350.0,
    current_capacity_used_kg: 120.0,
    has_cold_storage: true,
    has_transportation: true,
    accepted_categories: 'Cooked Meals,Bakery,Produce,Dairy,Packaged',
    operating_hours_start: '06:00',
    operating_hours_end: '23:00',
    reliability_score: 0.99,
    created_at: hoursAgo(72),
  },
  {
    id: 'rec-004',
    name: 'City Harvest Kitchen (Fictional NGO)',
    organization_type: 'Community Kitchen',
    contact_person: 'Pooja Verma',
    contact_phone: '+91 98450 44004',
    contact_email: 'harvest@citykitchen-demo.org',
    address: '45 Malleshwaram 8th Cross',
    latitude: 13.003,
    longitude: 77.57,
    is_verified: true,
    daily_capacity_kg: 120.0,
    current_capacity_used_kg: 25.0,
    has_cold_storage: true,
    has_transportation: false,
    accepted_categories: 'Cooked Meals,Produce,Packaged',
    operating_hours_start: '08:30',
    operating_hours_end: '20:00',
    reliability_score: 0.9,
    created_at: hoursAgo(72),
  },
  {
    id: 'rec-005',
    name: 'Unverified Neighborhood Pantry (Demo Safety Case)',
    organization_type: 'Shelter',
    contact_person: 'Arun',
    contact_phone: '+91 98450 55005',
    contact_email: 'arun@unverified-demo.org',
    address: '12 Old Airport Lane',
    latitude: 12.955,
    longitude: 77.66,
    is_verified: false, // Intentionally unverified for deterministic safety guardrail testing
    daily_capacity_kg: 50.0,
    current_capacity_used_kg: 0.0,
    has_cold_storage: false,
    has_transportation: false,
    accepted_categories: 'Cooked Meals,Packaged',
    operating_hours_start: '09:00',
    operating_hours_end: '18:00',
    reliability_score: 0.65,
    created_at: hoursAgo(72),
  },
];

// 2. Mock Donations Seed Data (Matching seed_data.py)
export const mockDonations: Donation[] = [
  {
    id: 'don-001',
    donor_name: 'The Royal Palace Banquet (Fictional)',
    donor_type: 'Wedding/Event',
    donor_contact: '+91 99000 11111',
    donor_address: 'Palace Grounds Gate 4, Bellary Road',
    latitude: 12.998,
    longitude: 77.592,
    food_title: 'North Indian Wedding Banquet Surplus (Paneer Butter Masala, Pulao, Dal Makhani)',
    food_category: 'Cooked Meals',
    quantity_value: 65.0,
    quantity_unit: 'kg',
    storage_requirement: 'HOT_HOLDING',
    dietary_type: 'VEGETARIAN',
    preparation_time: hoursAgo(6),
    pickup_deadline: hoursAgo(2),
    status: 'COLLECTED',
    pickup_verification_code: '4821',
    handling_instructions: 'Insulated food-grade stainless steel containers. Handled under warm temperature control.',
    collected_at: hoursAgo(3),
    created_at: hoursAgo(7),
    updated_at: hoursAgo(3),
  },
  {
    id: 'don-002',
    donor_name: 'TechCorp Executive Cafeteria (Fictional)',
    donor_type: 'Cafeteria',
    donor_contact: '+91 99000 22222',
    donor_address: 'Ecospace Business Park, Bellandur',
    latitude: 12.926,
    longitude: 77.676,
    food_title: 'Fresh Salad Bowls & Artisan Sandwiches',
    food_category: 'Cooked Meals',
    quantity_value: 30.0,
    quantity_unit: 'kg',
    storage_requirement: 'REFRIGERATED',
    dietary_type: 'VEGETARIAN',
    preparation_time: hoursAgo(8),
    pickup_deadline: hoursAgo(4),
    status: 'COLLECTED',
    pickup_verification_code: '7392',
    handling_instructions: 'Pre-packed in compostable containers. Kept refrigerated at 4 degrees C.',
    collected_at: hoursAgo(4.5),
    created_at: hoursAgo(9),
    updated_at: hoursAgo(4.5),
  },
  {
    id: 'don-003',
    donor_name: 'Grand Heritage Bistro (Fictional)',
    donor_type: 'Restaurant',
    donor_contact: '+91 99000 33333',
    donor_address: 'Lavelle Road, Shanthala Nagar',
    latitude: 12.97,
    longitude: 77.596,
    food_title: 'Freshly Baked Baguettes, Croissants & Breads',
    food_category: 'Bakery',
    quantity_value: 22.0,
    quantity_unit: 'kg',
    storage_requirement: 'ROOM_TEMP',
    dietary_type: 'VEGETARIAN',
    preparation_time: hoursAgo(2),
    pickup_deadline: hoursFromNow(4),
    status: 'IN_TRANSIT',
    pickup_verification_code: '5109',
    handling_instructions: 'Packed in clean dry paper cartons.',
    created_at: hoursAgo(2),
    updated_at: hoursAgo(0.5),
  },
  {
    id: 'don-004',
    donor_name: 'Starlight University Hostel Mess (Fictional)',
    donor_type: 'Hostel',
    donor_contact: '+91 99000 44444',
    donor_address: 'Hostel Block C, University Campus',
    latitude: 12.975,
    longitude: 77.605,
    food_title: 'Nutritious Dinner Surplus (Rice, Sambar, Mix Veg, Chapati)',
    food_category: 'Cooked Meals',
    quantity_value: 45.0,
    quantity_unit: 'kg',
    storage_requirement: 'ROOM_TEMP',
    dietary_type: 'VEGETARIAN',
    preparation_time: hoursAgo(1),
    pickup_deadline: hoursFromNow(3.5),
    status: 'PROPOSED',
    pickup_verification_code: '8491',
    handling_instructions: 'Freshly prepared evening batch. Steam vessels ready for immediate pickup.',
    created_at: hoursAgo(1),
    updated_at: hoursAgo(1),
  },
  {
    id: 'don-005',
    donor_name: 'Downtown Convention Hub (Fictional)',
    donor_type: 'Wedding/Event',
    donor_contact: '+91 99000 55555',
    donor_address: 'Near Metro Station, MG Road',
    latitude: 12.974,
    longitude: 77.61,
    food_title: 'Desserts & Pastry Platters',
    food_category: 'Dairy',
    quantity_value: 18.0,
    quantity_unit: 'kg',
    storage_requirement: 'REFRIGERATED',
    dietary_type: 'VEGETARIAN',
    preparation_time: hoursAgo(3),
    pickup_deadline: minutesFromNow(50), // Tight 50 mins deadline! Escalates to HUMAN_REVIEW
    status: 'PROPOSED',
    pickup_verification_code: '6234',
    handling_instructions: 'Chilled pastries. Urgent collection needed within the hour.',
    created_at: hoursAgo(3),
    updated_at: hoursAgo(3),
  },
];

// 3. Mock Audit Logs Seed Data
export const mockAuditLogs: AuditLogItem[] = [
  {
    id: 'log-001',
    event_type: 'SYSTEM_INITIALIZED',
    entity_type: 'system',
    entity_id: 'init-001',
    actor_role: 'SYSTEM',
    details: 'Initial demo seed data and deterministic safety guardrails populated successfully.',
    created_at: hoursAgo(12),
  },
  {
    id: 'log-002',
    event_type: 'DONATION_REGISTERED',
    entity_type: 'donation',
    entity_id: 'don-001',
    actor_role: 'DONOR',
    details: 'The Royal Palace Banquet registered 65 kg of North Indian Wedding Banquet Surplus.',
    created_at: hoursAgo(7),
  },
  {
    id: 'log-003',
    event_type: 'MATCH_EVALUATED',
    entity_type: 'match',
    entity_id: 'match-001',
    actor_role: 'DECIDER_2B',
    details: 'Decision: APPROVE (96%) for recipient Hope Community Kitchen (Fictional NGO).',
    created_at: hoursAgo(6.8),
  },
  {
    id: 'log-004',
    event_type: 'MATCH_ACCEPTED',
    entity_type: 'match',
    entity_id: 'match-001',
    actor_role: 'RECIPIENT',
    details: 'Recipient Hope Community Kitchen accepted donation offer. Verification code 4821 issued.',
    created_at: hoursAgo(5.5),
  },
  {
    id: 'log-005',
    event_type: 'DONATION_COLLECTED',
    entity_type: 'donation',
    entity_id: 'don-001',
    actor_role: 'DRIVER',
    details: 'Verified pickup code 4821. 65 kg rescued and delivered to Hope Community Kitchen.',
    created_at: hoursAgo(3),
  },
  {
    id: 'log-006',
    event_type: 'DONATION_COLLECTED',
    entity_type: 'donation',
    entity_id: 'don-002',
    actor_role: 'DRIVER',
    details: 'Verified pickup code 7392. 30 kg rescued and delivered to Mercy Food Bank & Cold Store.',
    created_at: hoursAgo(4.5),
  },
  {
    id: 'log-007',
    event_type: 'DRIVER_DISPATCHED',
    entity_type: 'donation',
    entity_id: 'don-003',
    actor_role: 'DRIVER',
    details: 'Driver en route to Grand Heritage Bistro for 22 kg artisan bakery goods.',
    created_at: hoursAgo(0.5),
  },
];

// Benchmark dataset test cases (7 test cases from eval_service.py)
const benchmarkTestCases: BenchmarkCase[] = [
  {
    case_id: 'TC-01',
    name: 'Eligible high-volume lunch buffet to nearby shelter',
    ground_truth: 'APPROVE',
    safety_passed: true,
    decider_decision: 'APPROVE',
    decider_confidence: 0.94,
    decider_latency_ms: 3.8,
    bedrock_latency_ms: 45.2,
    is_correct: true,
    baseline_decision: 'APPROVE',
    explanation_preview: 'Downtown Care Kitchen selected for 40.0 kg Assorted Rice and Curry. Optimal proximity (1.2 km) and ample absorption capacity.',
  },
  {
    case_id: 'TC-02',
    name: 'Expired donation (past pickup deadline)',
    ground_truth: 'REJECT',
    safety_passed: false,
    decider_decision: 'REJECT',
    decider_confidence: 0.99,
    decider_latency_ms: 2.1,
    bedrock_latency_ms: 41.0,
    is_correct: true,
    baseline_decision: 'REJECT',
    explanation_preview: 'Hard Safety Failure: Pickup deadline has passed or is too close. Donation excluded by deterministic time safety guardrail.',
  },
  {
    case_id: 'TC-03',
    name: 'Unverified recipient organization',
    ground_truth: 'REJECT',
    safety_passed: false,
    decider_decision: 'REJECT',
    decider_confidence: 0.99,
    decider_latency_ms: 1.9,
    bedrock_latency_ms: 39.8,
    is_correct: true,
    baseline_decision: 'REJECT',
    explanation_preview: 'Hard Safety Failure: Recipient organization is unverified. Food surplus may only dispatch to verified recipient NGOs.',
  },
  {
    case_id: 'TC-04',
    name: 'Insufficient recipient absorption capacity',
    ground_truth: 'REJECT',
    safety_passed: false,
    decider_decision: 'REJECT',
    decider_confidence: 0.99,
    decider_latency_ms: 2.3,
    bedrock_latency_ms: 42.5,
    is_correct: true,
    baseline_decision: 'REJECT',
    explanation_preview: 'Hard Safety Failure: Donation quantity (120.0 kg) exceeds recipient remaining capacity (15.0 kg). Excluded to prevent spoilage.',
  },
  {
    case_id: 'TC-05',
    name: 'Approaching tight deadline (under 1.5 hours)',
    ground_truth: 'HUMAN_REVIEW',
    safety_passed: true,
    decider_decision: 'HUMAN_REVIEW',
    decider_confidence: 0.68,
    decider_latency_ms: 4.5,
    bedrock_latency_ms: 54.1,
    is_correct: true,
    baseline_decision: 'APPROVE', // Heuristic baseline errantly approves tight deadlines!
    explanation_preview: 'Match flagged for coordinator review. While physically proximate (1.1 km), the approaching 55-minute deadline requires vehicle dispatch confirmation.',
  },
  {
    case_id: 'TC-06',
    name: 'Storage mismatch (requires frozen, recipient lacks freezer)',
    ground_truth: 'REJECT',
    safety_passed: false,
    decider_decision: 'REJECT',
    decider_confidence: 0.99,
    decider_latency_ms: 2.2,
    bedrock_latency_ms: 43.0,
    is_correct: true,
    baseline_decision: 'REJECT',
    explanation_preview: 'Hard Safety Failure: Donation requires FROZEN storage, but recipient lacks refrigeration/freezer facilities.',
  },
  {
    case_id: 'TC-07',
    name: 'Borderline distance with moderate reliability',
    ground_truth: 'HUMAN_REVIEW',
    safety_passed: true,
    decider_decision: 'HUMAN_REVIEW',
    decider_confidence: 0.64,
    decider_latency_ms: 4.1,
    bedrock_latency_ms: 51.4,
    is_correct: true,
    baseline_decision: 'APPROVE', // Heuristic baseline errantly approves long transit without checking reliability
    explanation_preview: 'Match flagged for human review. Distance (13.5 km) is near the safe limit for hot food holding and recipient reliability score is moderate.',
  },
];

// 4. MockApiService implementation
export class MockApiService {
  private donations: Donation[];
  private recipients: Recipient[];
  private matchCandidatesMap: Map<string, MatchCandidate[]>;
  private auditLogs: AuditLogItem[];

  constructor() {
    this.donations = JSON.parse(JSON.stringify(mockDonations));
    this.recipients = JSON.parse(JSON.stringify(mockRecipients));
    this.auditLogs = JSON.parse(JSON.stringify(mockAuditLogs));
    this.matchCandidatesMap = new Map();

    // Initialize initial match evaluations for don-004 and don-005
    this.seedInitialMatches();
  }

  private seedInitialMatches() {
    // Pre-evaluate don-005 to ensure human review queue has an active item out-of-the-box
    const don005 = this.donations.find((d) => d.id === 'don-005');
    if (don005) {
      this.evaluateMatchesInternal(don005);
    }
    const don004 = this.donations.find((d) => d.id === 'don-004');
    if (don004) {
      this.evaluateMatchesInternal(don004);
    }
  }

  // System metadata
  async getSystemStatus() {
    await simulateDelay(20, 40);
    return {
      system: 'FoodBridge AI',
      version: '1.0.0',
      status: 'operational',
      demo_environment: true,
      fictional_data_notice: 'DEMO NOTICE: All test organizations and donations are fictional.',
      ai_engine: {
        decider_model: 'Strands-Decider-2B',
        decider_confidence_threshold: 0.72,
        bedrock_model_id: 'anthropic.claude-3-haiku-20240307-v1:0',
        is_live_bedrock: false,
      },
    };
  }

  // Donations API
  async listDonations(status?: string): Promise<Donation[]> {
    await simulateDelay();
    if (status && status !== 'ALL') {
      return this.donations.filter((d) => d.status === status);
    }
    return [...this.donations];
  }

  async getDonation(id: string): Promise<Donation> {
    await simulateDelay();
    const donation = this.donations.find((d) => d.id === id);
    if (!donation) {
      throw new Error(`Donation with ID ${id} not found`);
    }
    return { ...donation };
  }

  async createDonation(data: Partial<Donation>): Promise<Donation> {
    await simulateDelay(50, 100);
    const id = `don-${Math.floor(100 + Math.random() * 900)}`;
    const pickupVerificationCode = Math.floor(1000 + Math.random() * 9000).toString();
    const timestamp = new Date().toISOString();

    const newDonation: Donation = {
      id,
      donor_name: data.donor_name || 'Anonymous Donor',
      donor_type: data.donor_type || 'Restaurant',
      donor_contact: data.donor_contact || '+91 99000 00000',
      donor_address: data.donor_address || 'Central City, Bangalore',
      latitude: data.latitude || 12.9716,
      longitude: data.longitude || 77.5946,
      food_title: data.food_title || 'Assorted Food Surplus',
      food_category: data.food_category || 'Cooked Meals',
      quantity_value: Number(data.quantity_value) || 10,
      quantity_unit: data.quantity_unit || 'kg',
      storage_requirement: data.storage_requirement || 'ROOM_TEMP',
      dietary_type: data.dietary_type || 'VEGETARIAN',
      preparation_time: data.preparation_time || new Date().toISOString(),
      pickup_deadline: data.pickup_deadline || hoursFromNow(3),
      status: 'PROPOSED',
      pickup_verification_code: pickupVerificationCode,
      handling_instructions: data.handling_instructions || '',
      created_at: timestamp,
      updated_at: timestamp,
    };

    this.donations.unshift(newDonation);

    this.auditLogs.unshift({
      id: `log-${Date.now()}`,
      event_type: 'DONATION_REGISTERED',
      entity_type: 'donation',
      entity_id: id,
      actor_role: 'DONOR',
      details: `${newDonation.donor_name} registered ${newDonation.quantity_value} ${newDonation.quantity_unit} of ${newDonation.food_title}.`,
      created_at: timestamp,
    });

    return { ...newDonation };
  }

  async updateDonationStatus(
    id: string,
    status: string,
    verificationCode?: string
  ): Promise<Donation> {
    await simulateDelay(40, 90);
    const index = this.donations.findIndex((d) => d.id === id);
    if (index === -1) {
      throw new Error(`Donation ${id} not found`);
    }

    const donation = this.donations[index];

    // Verification code validation for COLLECTED status
    if (status === 'COLLECTED') {
      if (!verificationCode || verificationCode.trim() !== donation.pickup_verification_code) {
        throw new Error(
          `Invalid pickup verification code. Expected "${donation.pickup_verification_code}".`
        );
      }
      donation.collected_at = new Date().toISOString();
    }

    donation.status = status as DonationStatus;
    donation.updated_at = new Date().toISOString();

    this.auditLogs.unshift({
      id: `log-${Date.now()}`,
      event_type: `DONATION_${status}`,
      entity_type: 'donation',
      entity_id: donation.id,
      actor_role: status === 'COLLECTED' ? 'DRIVER' : 'COORDINATOR',
      details: `Donation "${donation.food_title}" status updated to ${status}.`,
      created_at: new Date().toISOString(),
    });

    return { ...donation };
  }

  // Recipients API
  async listRecipients(): Promise<Recipient[]> {
    await simulateDelay();
    return [...this.recipients];
  }

  async getRecipient(id: string): Promise<Recipient> {
    await simulateDelay();
    const rec = this.recipients.find((r) => r.id === id);
    if (!rec) {
      throw new Error(`Recipient with ID ${id} not found`);
    }
    return { ...rec };
  }

  async createRecipient(data: Partial<Recipient>): Promise<Recipient> {
    await simulateDelay(50, 90);
    const id = `rec-${Math.floor(100 + Math.random() * 900)}`;
    const newRecipient: Recipient = {
      id,
      name: data.name || 'New Community Partner',
      organization_type: data.organization_type || 'Community Kitchen',
      contact_person: data.contact_person || 'Coordinator',
      contact_phone: data.contact_phone || '+91 98450 00000',
      contact_email: data.contact_email || 'partner@foodbridge-demo.org',
      address: data.address || 'Central District',
      latitude: data.latitude || 12.9716,
      longitude: data.longitude || 77.5946,
      is_verified: data.is_verified ?? true,
      daily_capacity_kg: Number(data.daily_capacity_kg) || 100,
      current_capacity_used_kg: 0,
      has_cold_storage: Boolean(data.has_cold_storage),
      has_transportation: Boolean(data.has_transportation),
      accepted_categories: data.accepted_categories || 'Cooked Meals,Produce,Packaged',
      operating_hours_start: data.operating_hours_start || '08:00',
      operating_hours_end: data.operating_hours_end || '21:00',
      reliability_score: data.reliability_score || 0.95,
      created_at: new Date().toISOString(),
    };

    this.recipients.unshift(newRecipient);

    this.auditLogs.unshift({
      id: `log-${Date.now()}`,
      event_type: 'RECIPIENT_REGISTERED',
      entity_type: 'recipient',
      entity_id: id,
      actor_role: 'ADMIN',
      details: `New recipient organization registered: ${newRecipient.name} (${newRecipient.organization_type}).`,
      created_at: new Date().toISOString(),
    });

    return { ...newRecipient };
  }

  // Deterministic Safety Engine & Strands Decider 2B Simulation
  private evaluateMatchesInternal(donation: Donation): MatchCandidate[] {
    const candidates: MatchCandidate[] = [];
    const currentTime = new Date();
    const deadlineTime = new Date(donation.pickup_deadline);
    const prepTime = new Date(donation.preparation_time);

    const hoursToDeadline = (deadlineTime.getTime() - currentTime.getTime()) / (3600 * 1000);
    const hoursSincePrep = (currentTime.getTime() - prepTime.getTime()) / (3600 * 1000);

    for (const rec of this.recipients) {
      const distance = haversineDistanceKm(
        donation.latitude,
        donation.longitude,
        rec.latitude,
        rec.longitude
      );

      const reasons: string[] = [];
      const checks: Record<string, boolean> = {};

      // Guardrail 1: Deadline & Expiration (Min 30 mins)
      if (hoursToDeadline <= 0.5) {
        checks['deadline_valid'] = false;
        reasons.push(
          `Pickup deadline is too close or has passed (${hoursToDeadline.toFixed(1)} hrs remaining; min 0.5 hrs required).`
        );
      } else {
        checks['deadline_valid'] = true;
      }

      // Guardrail 2: Food Preparation & Holding limit
      if (
        donation.food_category === 'Cooked Meals' &&
        donation.storage_requirement === 'ROOM_TEMP' &&
        hoursSincePrep > 4.5
      ) {
        checks['prep_time_valid'] = false;
        reasons.push(
          `Cooked food held at room temperature exceeds safety threshold (${hoursSincePrep.toFixed(1)} hrs elapsed; max safe is 4.5 hrs).`
        );
      } else {
        checks['prep_time_valid'] = true;
      }

      // Guardrail 3: Recipient Verification Guardrail
      if (!rec.is_verified) {
        checks['recipient_verified'] = false;
        reasons.push(
          'Recipient organization is unverified. Donations can only be allocated to verified NGOs.'
        );
      } else {
        checks['recipient_verified'] = true;
      }

      // Guardrail 4: Intake Capacity
      const availableCapacity = Math.max(0, rec.daily_capacity_kg - rec.current_capacity_used_kg);
      const donationKg =
        donation.quantity_unit === 'kg' ? donation.quantity_value : donation.quantity_value * 0.4;
      if (donationKg > availableCapacity) {
        checks['capacity_available'] = false;
        reasons.push(
          `Donation quantity (${donationKg.toFixed(1)} kg) exceeds available capacity (${availableCapacity.toFixed(1)} kg).`
        );
      } else {
        checks['capacity_available'] = true;
      }

      // Guardrail 5: Storage Compatibility
      const storageReq = (donation.storage_requirement || 'ROOM_TEMP').toUpperCase();
      if ((storageReq === 'REFRIGERATED' || storageReq === 'FROZEN') && !rec.has_cold_storage) {
        checks['storage_compatible'] = false;
        reasons.push(
          `Donation requires ${storageReq} storage, but recipient does not have cold storage equipment.`
        );
      } else {
        checks['storage_compatible'] = true;
      }

      // Guardrail 6: Distance & Transit limit
      const maxDist = storageReq === 'HOT_HOLDING' ? 12.0 : 30.0;
      if (distance > maxDist) {
        checks['distance_safe'] = false;
        reasons.push(`Distance (${distance.toFixed(1)} km) exceeds safe transit margin (${maxDist} km).`);
      } else {
        checks['distance_safe'] = true;
      }

      // Guardrail 7: Transportation Readiness
      if (distance > 3.0 && !rec.has_transportation) {
        checks['transport_available'] = false;
        reasons.push(
          `Distance (${distance.toFixed(1)} km) requires vehicle dispatch, but recipient lacks fleet transport.`
        );
      } else {
        checks['transport_available'] = true;
      }

      const safetyPassed = Object.values(checks).every(Boolean);
      const safetyResult: SafetyCheckResult = {
        passed: safetyPassed,
        reasons,
        checks,
      };

      // Strands Decider 2B Classification Logic
      let decision: DeciderDecision = 'REJECT';
      let confidence = 0.99;
      const primaryFactors: string[] = [];

      if (!safetyPassed) {
        decision = 'REJECT';
        confidence = 0.99;
        primaryFactors.push(...reasons.map((r) => `Hard Safety Failure: ${r}`));
      } else {
        // Multi-axis policy score
        let proximityScore = distance <= 5.0 ? 1.0 : distance <= 15.0 ? 0.8 : 0.4;
        primaryFactors.push(`Proximity: ${distance.toFixed(1)} km`);

        const capRatio = donationKg / Math.max(1, availableCapacity);
        const capacityScore = capRatio <= 0.8 ? 1.0 : 0.65;
        primaryFactors.push(
          `Capacity absorption: ${donationKg.toFixed(0)} kg / ${availableCapacity.toFixed(0)} kg free`
        );

        let isTightDeadline = false;
        let urgencyScore = 0.9;
        if (hoursToDeadline < 1.5) {
          urgencyScore = 0.45;
          isTightDeadline = true;
          primaryFactors.push(
            `Approaching deadline (${hoursToDeadline.toFixed(1)} hrs remaining)`
          );
        } else {
          primaryFactors.push(`Adequate pickup window (${hoursToDeadline.toFixed(1)} hrs)`);
        }

        let logisticsScore = rec.reliability_score;
        if (rec.has_transportation) {
          logisticsScore = Math.min(1.0, logisticsScore + 0.05);
          primaryFactors.push('Recipient has verified dedicated transportation');
        }

        confidence = Math.round(
          ((proximityScore + capacityScore + urgencyScore + logisticsScore) / 4) * 100
        ) / 100;

        if (isTightDeadline) {
          decision = 'HUMAN_REVIEW';
          primaryFactors.push(
            'Flagged for human review: rapid dispatch coordination needed due to tight deadline'
          );
        } else if (confidence >= 0.72) {
          decision = 'APPROVE';
        } else if (confidence >= 0.5) {
          decision = 'HUMAN_REVIEW';
          primaryFactors.push('Borderline policy score requires coordinator verification');
        } else {
          decision = 'REJECT';
          primaryFactors.push('Overall policy match score insufficient for donation dispatch');
        }
      }

      // Bedrock-style narrative synthesis
      let explanation = '';
      let notification = '';
      if (decision === 'APPROVE') {
        explanation = `${rec.name} is selected for ${donation.quantity_value} ${donation.quantity_unit} of ${donation.food_title} due to optimal proximity (${distance.toFixed(1)} km), adequate intake capacity, and an actionable ${Math.max(0.1, hoursToDeadline).toFixed(1)}-hour collection window. Verified logistics ensure food safety standards are fully preserved.`;
        notification = `[Dispatch Alert] New donation match confirmed: ${donation.quantity_value} ${donation.quantity_unit} of ${donation.food_title} from donor. Destination: ${rec.name} (${distance.toFixed(1)} km away).`;
      } else if (decision === 'HUMAN_REVIEW') {
        explanation = `Match with ${rec.name} flagged for coordinator review. While within physical reach (${distance.toFixed(1)} km), the urgent ${Math.max(0.1, hoursToDeadline).toFixed(1)}h deadline requires manual verification of driver availability before dispatch confirmation.`;
        notification = `[Coordinator Review Needed] Match between donor and ${rec.name} is pending review due to time constraints for ${donation.food_title}.`;
      } else {
        explanation = `Candidate ${rec.name} was excluded from dispatch. Policy factors indicated distance (${distance.toFixed(1)} km) or storage constraints do not satisfy strict food safety preservation rules.`;
        notification = `Candidate not eligible for donation '${donation.food_title}'.`;
      }

      let matchStatus = 'OFFERED';
      if (!safetyPassed || decision === 'REJECT') {
        matchStatus = 'EXCLUDED';
      } else if (decision === 'HUMAN_REVIEW') {
        matchStatus = 'ESCALATED';
      }

      const matchId = `match-${donation.id}-${rec.id}`;
      const deciderOutput: DeciderOutput = {
        decision,
        confidence,
        primary_factors: primaryFactors,
        rule_overrides_applied: !safetyPassed,
        model_name: 'Strands-Decider-2B',
        latency_ms: Math.round((Math.random() * 4 + 3) * 10) / 10,
      };

      candidates.push({
        id: matchId,
        donation_id: donation.id,
        recipient: { ...rec },
        distance_km: distance,
        capacity_fit: checks['capacity_available'] ?? false,
        storage_fit: checks['storage_compatible'] ?? false,
        safety_result: safetyResult,
        decider_output: deciderOutput,
        bedrock_explanation: explanation,
        bedrock_notification: notification,
        bedrock_latency_ms: Math.round((Math.random() * 20 + 40) * 10) / 10,
        is_live_bedrock: false,
        match_status: matchStatus,
        created_at: new Date().toISOString(),
      });
    }

    // Sort: APPROVE first (descending confidence), then HUMAN_REVIEW, then REJECT
    const priority = { APPROVE: 0, HUMAN_REVIEW: 1, REJECT: 2 };
    candidates.sort((a, b) => {
      const pDiff =
        priority[a.decider_output.decision] - priority[b.decider_output.decision];
      if (pDiff !== 0) return pDiff;
      if (b.decider_output.confidence !== a.decider_output.confidence) {
        return b.decider_output.confidence - a.decider_output.confidence;
      }
      return a.distance_km - b.distance_km;
    });

    this.matchCandidatesMap.set(donation.id, candidates);
    return candidates;
  }

  // Matches API
  async evaluateMatches(donationId: string): Promise<MatchCandidate[]> {
    await simulateDelay(60, 110);
    const donation = this.donations.find((d) => d.id === donationId);
    if (!donation) {
      throw new Error(`Donation with ID ${donationId} not found`);
    }

    const results = this.evaluateMatchesInternal(donation);

    // If an approved match exists, advance donation from PROPOSED to MATCHED
    if (results.some((r) => r.decider_output.decision === 'APPROVE')) {
      if (donation.status === 'PROPOSED') {
        donation.status = 'MATCHED';
        donation.updated_at = new Date().toISOString();
      }
    }

    this.auditLogs.unshift({
      id: `log-${Date.now()}`,
      event_type: 'MATCHES_EVALUATED',
      entity_type: 'donation',
      entity_id: donation.id,
      actor_role: 'DECIDER_2B',
      details: `Evaluated ${results.length} recipient candidates for "${donation.food_title}". Best candidate: ${results[0]?.recipient.name} (${results[0]?.decider_output.decision}).`,
      created_at: new Date().toISOString(),
    });

    return JSON.parse(JSON.stringify(results));
  }

  async acceptMatch(
    matchId: string
  ): Promise<{
    success: boolean;
    message: string;
    pickup_verification_code?: string;
    status: string;
    donation_id?: string;
  }> {
    await simulateDelay(50, 90);

    let foundCandidate: MatchCandidate | undefined;
    let targetDonation: Donation | undefined;

    for (const [donId, candidates] of this.matchCandidatesMap.entries()) {
      const c = candidates.find((cand) => cand.id === matchId);
      if (c) {
        foundCandidate = c;
        targetDonation = this.donations.find((d) => d.id === donId);
        break;
      }
    }

    if (!foundCandidate || !targetDonation) {
      throw new Error(`Match candidate ${matchId} not found`);
    }

    if (!foundCandidate.safety_result.passed) {
      throw new Error(
        'Deterministic Safety Guardrail: Cannot accept an offer that failed safety checks.'
      );
    }

    foundCandidate.match_status = 'ACCEPTED';
    targetDonation.status = 'ACCEPTED';
    targetDonation.updated_at = new Date().toISOString();

    // Deduct available capacity from recipient
    const recipient = this.recipients.find((r) => r.id === foundCandidate!.recipient.id);
    if (recipient) {
      recipient.current_capacity_used_kg = Math.min(
        recipient.daily_capacity_kg,
        recipient.current_capacity_used_kg + targetDonation.quantity_value
      );
    }

    this.auditLogs.unshift({
      id: `log-${Date.now()}`,
      event_type: 'MATCH_ACCEPTED',
      entity_type: 'match',
      entity_id: matchId,
      actor_role: 'RECIPIENT',
      details: `Recipient ${foundCandidate.recipient.name} accepted donation offer. Pickup code: ${targetDonation.pickup_verification_code}.`,
      created_at: new Date().toISOString(),
    });

    return {
      success: true,
      message: `Match accepted! Pickup verification code is ${targetDonation.pickup_verification_code}.`,
      pickup_verification_code: targetDonation.pickup_verification_code,
      status: targetDonation.status,
      donation_id: targetDonation.id,
    };
  }

  // Human Review & Audit API
  async getHumanReviewQueue(): Promise<HumanReviewCase[]> {
    await simulateDelay();
    const cases: HumanReviewCase[] = [];

    for (const [donId, candidates] of this.matchCandidatesMap.entries()) {
      const donation = this.donations.find((d) => d.id === donId);
      if (!donation) continue;

      for (const c of candidates) {
        if (c.decider_output.decision === 'HUMAN_REVIEW' && c.match_status === 'ESCALATED') {
          cases.push({
            match_id: c.id,
            donation_id: donation.id,
            recipient_id: c.recipient.id,
            donation_title: donation.food_title,
            quantity: `${donation.quantity_value} ${donation.quantity_unit}`,
            food_category: donation.food_category,
            recipient_name: c.recipient.name,
            recipient_type: c.recipient.organization_type,
            distance_km: c.distance_km,
            decider_decision: c.decider_output.decision,
            decider_confidence: c.decider_output.confidence,
            decider_rationale: c.decider_output.primary_factors.join('; '),
            bedrock_explanation: c.bedrock_explanation,
            safety_check_passed: c.safety_result.passed,
            created_at: c.created_at,
            match_status: c.match_status,
          });
        }
      }
    }

    return cases;
  }

  async resolveHumanReview(
    matchId: string,
    action: 'APPROVE' | 'REJECT',
    reviewerNotes: string
  ): Promise<{ success: boolean; message: string; match_id: string; new_decision: string }> {
    await simulateDelay(50, 90);

    let foundCandidate: MatchCandidate | undefined;
    let targetDonation: Donation | undefined;

    for (const [donId, candidates] of this.matchCandidatesMap.entries()) {
      const c = candidates.find((cand) => cand.id === matchId);
      if (c) {
        foundCandidate = c;
        targetDonation = this.donations.find((d) => d.id === donId);
        break;
      }
    }

    if (!foundCandidate) {
      throw new Error(`Review case ${matchId} not found`);
    }

    if (action === 'APPROVE' && !foundCandidate.safety_result.passed) {
      throw new Error(
        'Hard Safety Override Blocked: Cannot approve a candidate that failed deterministic safety guardrails.'
      );
    }

    foundCandidate.decider_output.decision = action;
    foundCandidate.match_status = action === 'APPROVE' ? 'RESOLVED' : 'EXCLUDED';

    if (action === 'APPROVE' && targetDonation && targetDonation.status === 'PROPOSED') {
      targetDonation.status = 'MATCHED';
      targetDonation.updated_at = new Date().toISOString();
    }

    this.auditLogs.unshift({
      id: `log-${Date.now()}`,
      event_type: 'HUMAN_REVIEW_RESOLVED',
      entity_type: 'match',
      entity_id: matchId,
      actor_role: 'COORDINATOR',
      details: `Coordinator resolved review to ${action}. Notes: ${reviewerNotes}`,
      created_at: new Date().toISOString(),
    });

    return {
      success: true,
      message: `Case resolved as ${action}.`,
      match_id: matchId,
      new_decision: action,
    };
  }

  async getAuditLogs(limit = 40): Promise<AuditLogItem[]> {
    await simulateDelay();
    return this.auditLogs.slice(0, limit);
  }

  // Impact Calculations (Strict Section 9 Isolation Rule)
  async getImpactMetrics(servingSizeKg = 0.4): Promise<ImpactMetrics> {
    await simulateDelay();
    const safeServingSize = servingSizeKg > 0 ? servingSizeKg : 0.4;

    const statusCounts: Record<string, number> = {
      PROPOSED: 0,
      MATCHED: 0,
      ACCEPTED: 0,
      IN_TRANSIT: 0,
      COLLECTED: 0,
      REJECTED: 0,
      EXPIRED: 0,
      CANCELLED: 0,
    };

    const categoryRescuedKg: Record<string, number> = {};
    let totalKgRescued = 0.0;
    let completedPickups = 0;

    for (const d of this.donations) {
      const status = d.status || 'PROPOSED';
      statusCounts[status] = (statusCounts[status] || 0) + 1;

      // CRITICAL RULE:
      // ONLY donations with status 'COLLECTED' contribute to rescued impact metrics.
      // Proposed, matched, accepted, in_transit, rejected or expired do NOT count!
      if (status === 'COLLECTED') {
        completedPickups += 1;
        const qtyKg =
          d.quantity_unit === 'kg' ? d.quantity_value : d.quantity_value * safeServingSize;
        totalKgRescued += qtyKg;
        const cat = d.food_category || 'Other';
        categoryRescuedKg[cat] = (categoryRescuedKg[cat] || 0) + qtyKg;
      }
    }

    const pendingOffers =
      (statusCounts['PROPOSED'] || 0) +
      (statusCounts['MATCHED'] || 0) +
      (statusCounts['ACCEPTED'] || 0);
    const inTransit = statusCounts['IN_TRANSIT'] || 0;
    const rejectedOrExpired =
      (statusCounts['REJECTED'] || 0) +
      (statusCounts['EXPIRED'] || 0) +
      (statusCounts['CANCELLED'] || 0);

    const estimatedMeals = Math.floor(totalKgRescued / safeServingSize);
    const co2AvoidedKg = Math.round(totalKgRescued * 2.5 * 10) / 10;
    const finalizedCount = completedPickups + rejectedOrExpired;
    const collectionRate =
      finalizedCount > 0
        ? Math.round((completedPickups / finalizedCount) * 100 * 10) / 10
        : 100.0;

    return {
      total_donations: this.donations.length,
      completed_pickups: completedPickups,
      pending_offers: pendingOffers,
      in_transit: inTransit,
      rejected_or_expired: rejectedOrExpired,
      total_kg_rescued: Math.round(totalKgRescued * 10) / 10,
      estimated_meals_served: estimatedMeals,
      serving_size_assumed_kg: safeServingSize,
      co2_avoided_kg: co2AvoidedKg,
      collection_rate_percent: collectionRate,
      status_breakdown: statusCounts,
      category_breakdown: Object.fromEntries(
        Object.entries(categoryRescuedKg).map(([k, v]) => [k, Math.round(v * 10) / 10])
      ),
    };
  }

  async getBedrockImpactReport(servingSizeKg = 0.4): Promise<BedrockImpactReport> {
    await simulateDelay(60, 120);
    const metrics = await this.getImpactMetrics(servingSizeKg);

    return {
      executive_summary: `FoodBridge AI has successfully coordinated the rescue of ${metrics.total_kg_rescued.toFixed(1)} kg of surplus food across ${metrics.completed_pickups} verified pickup operations. By pairing deterministic safety gates with Strands Decider 2B policy filtering, the platform eliminated edible food waste while supporting nearby community kitchens.`,
      highlights: [
        `${metrics.estimated_meals_served.toLocaleString()} wholesome meals delivered to underserved communities`,
        `${metrics.co2_avoided_kg.toFixed(1)} kg greenhouse gas emissions avoided from landfills`,
        '100% adherence to cold-chain and safe transit time constraints',
        `Zero food-safety incident escalations across ${metrics.completed_pickups} fulfilled pickups`,
      ],
      meals_served_narrative: `Based on a standard food assistance portion size of ${(servingSizeKg * 1000).toFixed(0)}g (${servingSizeKg.toFixed(2)} kg) per meal, the ${metrics.total_kg_rescued.toFixed(1)} kg of rescued surplus translated into approximately ${metrics.estimated_meals_served.toLocaleString()} balanced meal equivalents.`,
      esg_recommendations: [
        'Expand off-peak scheduled pickups for banquet halls to capture late-evening surpluses.',
        'Equip high-volume partner kitchens with temperature dataloggers for continuous cold-chain auditability.',
        'Incentivize commercial donors with verifiable ESG Scope 3 avoidance reporting certificates.',
      ],
      generated_at: new Date().toISOString().replace('T', ' ').substring(0, 19) + ' UTC',
      is_live_bedrock: false,
    };
  }

  // Benchmark Evaluation API
  async runBenchmark(): Promise<BenchmarkResults> {
    await simulateDelay(80, 150);

    const count = benchmarkTestCases.length;
    const correctCount = benchmarkTestCases.filter((c) => c.is_correct).length;
    const baselineCorrectCount = benchmarkTestCases.filter(
      (c) => c.baseline_decision === c.ground_truth
    ).length;

    const deciderAccuracy = Math.round((correctCount / count) * 100 * 10) / 10;
    const baselineAccuracy = Math.round((baselineCorrectCount / count) * 100 * 10) / 10;

    return {
      test_conditions: {
        total_cases: count,
        model_tested: 'Strands-Decider-2B',
        confidence_threshold: 0.72,
        timestamp: new Date().toISOString(),
      },
      metrics: {
        decider_accuracy_percent: deciderAccuracy,
        baseline_accuracy_percent: baselineAccuracy,
        accuracy_improvement_percent: Math.round((deciderAccuracy - baselineAccuracy) * 10) / 10,
        avg_decider_latency_ms: 3.0,
        avg_bedrock_latency_ms: 45.3,
        total_cases_evaluated: count,
      },
      cases: JSON.parse(JSON.stringify(benchmarkTestCases)),
      observations: `Strands Decider 2B achieved ${deciderAccuracy}% accuracy against ground truth, outperforming the simple heuristic baseline (${baselineAccuracy}%) by correctly escalating time-sensitive and edge-distance donations to HUMAN_REVIEW rather than risky automatic approvals. Average Decider inference latency: 3.0ms vs Bedrock generation: 45.3ms.`,
    };
  }

  async getBenchmarkTestCases(): Promise<any[]> {
    await simulateDelay();
    return benchmarkTestCases.map((c) => ({
      case_id: c.case_id,
      name: c.name,
      ground_truth: c.ground_truth,
      donation_title: c.name,
      quantity: '25 kg',
      food_category: 'Cooked Meals',
      recipient_name: 'Evaluation Recipient',
      is_verified: c.safety_passed,
    }));
  }
}

export const mockApi = new MockApiService();
