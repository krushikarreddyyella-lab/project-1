import pytest
from datetime import datetime, timedelta
from app.models.donation import Donation
from app.models.recipient import Recipient
from app.services.safety_engine import SafetyEngine, haversine_distance_km


@pytest.fixture
def base_donation():
    now = datetime.utcnow()
    return Donation(
        id="test-don-1",
        donor_name="Bistro Paris",
        donor_type="Restaurant",
        donor_contact="12345678",
        donor_address="Downtown",
        latitude=12.9716,
        longitude=77.5946,
        food_title="Vegetable Biryani",
        food_category="Cooked Meals",
        quantity_value=20.0,
        quantity_unit="kg",
        storage_requirement="ROOM_TEMP",
        dietary_type="VEGETARIAN",
        preparation_time=now - timedelta(hours=1),
        pickup_deadline=now + timedelta(hours=3),
        status="PROPOSED"
    )


@pytest.fixture
def base_recipient():
    return Recipient(
        id="test-rec-1",
        name="Hope Kitchen",
        organization_type="Community Kitchen",
        contact_person="Alice",
        contact_phone="87654321",
        address="Central Ave",
        latitude=12.9750,
        longitude=77.6000,
        is_verified=True,
        daily_capacity_kg=100.0,
        current_capacity_used_kg=10.0,
        has_cold_storage=True,
        has_transportation=True,
        reliability_score=0.95
    )


def test_safety_engine_passes_valid(base_donation, base_recipient):
    res = SafetyEngine.evaluate_safety(base_donation, base_recipient)
    assert res.passed is True
    assert len(res.reasons) == 0
    assert res.checks["deadline_valid"] is True
    assert res.checks["recipient_verified"] is True
    assert res.checks["capacity_available"] is True


def test_safety_engine_blocks_expired_deadline(base_donation, base_recipient):
    now = datetime.utcnow()
    base_donation.pickup_deadline = now - timedelta(minutes=10)  # Expired
    res = SafetyEngine.evaluate_safety(base_donation, base_recipient, now=now)
    assert res.passed is False
    assert res.checks["deadline_valid"] is False
    assert any("deadline" in r.lower() for r in res.reasons)


def test_safety_engine_blocks_unverified_recipient(base_donation, base_recipient):
    base_recipient.is_verified = False
    res = SafetyEngine.evaluate_safety(base_donation, base_recipient)
    assert res.passed is False
    assert res.checks["recipient_verified"] is False
    assert any("unverified" in r.lower() for r in res.reasons)


def test_safety_engine_blocks_insufficient_capacity(base_donation, base_recipient):
    base_recipient.daily_capacity_kg = 50.0
    base_recipient.current_capacity_used_kg = 45.0  # Only 5 kg remaining
    base_donation.quantity_value = 25.0  # Needs 25 kg
    res = SafetyEngine.evaluate_safety(base_donation, base_recipient)
    assert res.passed is False
    assert res.checks["capacity_available"] is False
    assert any("capacity" in r.lower() for r in res.reasons)


def test_safety_engine_blocks_cold_storage_mismatch(base_donation, base_recipient):
    base_donation.storage_requirement = "REFRIGERATED"
    base_recipient.has_cold_storage = False
    res = SafetyEngine.evaluate_safety(base_donation, base_recipient)
    assert res.passed is False
    assert res.checks["storage_compatible"] is False
    assert any("cold storage" in r.lower() for r in res.reasons)


def test_safety_engine_blocks_stale_cooked_food(base_donation, base_recipient):
    now = datetime.utcnow()
    # Cooked food room temperature held > 4.5 hours is unsafe
    base_donation.preparation_time = now - timedelta(hours=6)
    res = SafetyEngine.evaluate_safety(base_donation, base_recipient, now=now)
    assert res.passed is False
    assert res.checks["prep_time_valid"] is False
    assert any("food safety" in r.lower() or "room temperature" in r.lower() for r in res.reasons)


def test_haversine_distance_computation():
    # Distance between two known coordinates
    dist = haversine_distance_km(12.9716, 77.5946, 12.9750, 77.6000)
    assert 0.4 < dist < 1.0
