from pydantic import BaseModel, Field, ConfigDict
from datetime import datetime
from typing import Optional


class RecipientBase(BaseModel):
    name: str = Field(..., min_length=2, max_length=128)
    organization_type: str = Field("NGO", description="NGO, Community Kitchen, Shelter, Food Bank")
    contact_person: str = Field(..., min_length=2, max_length=64)
    contact_phone: str = Field(..., min_length=5, max_length=64)
    contact_email: Optional[str] = None
    address: str = Field(..., min_length=5, max_length=255)
    latitude: float = Field(12.9716, ge=-90, le=90)
    longitude: float = Field(77.5946, ge=-180, le=180)

    is_verified: bool = True
    daily_capacity_kg: float = Field(100.0, gt=0)
    current_capacity_used_kg: float = Field(0.0, ge=0)
    has_cold_storage: bool = False
    has_transportation: bool = True
    accepted_categories: str = "Cooked Meals,Bakery,Produce,Dairy,Packaged"
    operating_hours_start: str = "08:00"
    operating_hours_end: str = "22:00"
    reliability_score: float = Field(0.95, ge=0.0, le=1.0)


class RecipientCreate(RecipientBase):
    pass


class RecipientResponse(RecipientBase):
    id: str
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)
