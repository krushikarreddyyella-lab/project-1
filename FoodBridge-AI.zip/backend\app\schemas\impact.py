from pydantic import BaseModel, Field
from typing import Dict, Any


class ImpactMetrics(BaseModel):
    total_donations: int
    completed_pickups: int
    pending_offers: int
    in_transit: int
    rejected_or_expired: int
    
    total_kg_rescued: float = Field(..., description="Rescued food quantity strictly from COLLECTED donations")
    estimated_meals_served: int = Field(..., description="Calculated using serving_size_assumed_kg")
    serving_size_assumed_kg: float = Field(0.40, description="Configured serving size assumption (400g / meal)")
    co2_avoided_kg: float = Field(..., description="Estimated CO2 equivalent emissions avoided")
    collection_rate_percent: float = Field(..., ge=0.0, le=100.0)

    status_breakdown: Dict[str, int]
    category_breakdown: Dict[str, float]


class BedrockImpactReport(BaseModel):
    executive_summary: str
    highlights: list[str]
    meals_served_narrative: str
    esg_recommendations: list[str]
    generated_at: str
    is_live_bedrock: bool
