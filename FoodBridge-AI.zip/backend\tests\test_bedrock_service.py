import pytest
from app.services.bedrock_service import BedrockService


@pytest.fixture
def bedrock():
    return BedrockService()


def test_bedrock_match_explanation_generation(bedrock):
    expl, notif, lat, is_live = bedrock.generate_match_explanation(
        donation_title="Veg Pulao",
        food_category="Cooked Meals",
        quantity_str="30 kg",
        recipient_name="Sunshine Shelter",
        distance_km=2.4,
        deadline_hours=2.5,
        decider_decision="APPROVE",
        decider_confidence=0.88,
        policy_factors=["Optimal proximity", "Capacity match"]
    )
    assert len(expl) > 20
    assert "Sunshine Shelter" in expl
    assert len(notif) > 10
    assert lat >= 0.0
    assert isinstance(is_live, bool)


def test_bedrock_impact_narrative_generation(bedrock):
    report = bedrock.generate_impact_narrative(
        total_kg=95.0,
        meals_count=237,
        co2_saved_kg=237.5,
        completed_pickups=2,
        serving_size_kg=0.40
    )
    assert "executive_summary" in report
    assert "highlights" in report
    assert len(report["highlights"]) >= 3
    assert "meals_served_narrative" in report
    assert "esg_recommendations" in report
    assert report["generated_at"] is not None
