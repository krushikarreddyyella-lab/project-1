import React, { useState } from 'react';
import { Utensils, Clock, MapPin, ShieldAlert, Sparkles, CheckCircle2 } from 'lucide-react';
import { api } from '../api/client';

interface Props {
  onSuccess: (donationId: string) => void;
}

export const DonateFoodPage: React.FC<Props> = ({ onSuccess }) => {
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Form State
  const now = new Date();
  const defaultPrep = new Date(now.getTime() - 60 * 60 * 1000).toISOString().slice(0, 16);
  const defaultDeadline = new Date(now.getTime() + 3.5 * 60 * 60 * 1000).toISOString().slice(0, 16);

  const [formData, setFormData] = useState({
    donor_name: 'The Orchid Grand Hotel',
    donor_type: 'Restaurant',
    donor_contact: '+91 98450 99881',
    donor_address: '22 Residency Road, Ashok Nagar',
    latitude: 12.9716,
    longitude: 77.5946,
    food_title: 'Surplus Banquet Rice, Dal Tadka & Mix Veg Curries',
    food_category: 'Cooked Meals',
    quantity_value: 35.0,
    quantity_unit: 'kg',
    storage_requirement: 'ROOM_TEMP',
    dietary_type: 'VEGETARIAN',
    preparation_time: defaultPrep,
    pickup_deadline: defaultDeadline,
    handling_instructions: 'Kept warm in food-grade insulated catering containers. Ready for immediate pickup.',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);

    try {
      // Validate deadline in future
      const prepDate = new Date(formData.preparation_time);
      const deadlineDate = new Date(formData.pickup_deadline);

      if (deadlineDate <= new Date()) {
        throw new Error('Pickup deadline must be in the future.');
      }
      if (deadlineDate <= prepDate) {
        throw new Error('Pickup deadline must be after preparation time.');
      }

      const created = await api.createDonation({
        ...formData,
        quantity_value: Number(formData.quantity_value),
        preparation_time: new Date(formData.preparation_time).toISOString(),
        pickup_deadline: new Date(formData.pickup_deadline).toISOString(),
      });

      onSuccess(created.id);
    } catch (err: any) {
      setError(err.message || 'Failed to register donation.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <div className="flex items-center gap-3 pb-4 border-b border-slate-100">
          <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl">
            <Utensils className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900">Register Surplus Food Donation</h1>
            <p className="text-xs text-slate-500 mt-0.5">
              Input validated surplus quantities. Strands Decider 2B will evaluate recipient compatibility.
            </p>
          </div>
        </div>

        {error && (
          <div className="mt-4 p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-center gap-2 text-rose-700 text-sm">
            <ShieldAlert className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-6 space-y-6">
          {/* Section 1: Donor Profile */}
          <div className="space-y-4">
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-400">Donor Information</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Donor Entity / Facility Name</label>
                <input
                  type="text"
                  required
                  value={formData.donor_name}
                  onChange={(e) => setFormData({ ...formData, donor_name: e.target.value })}
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  placeholder="e.g. Grand Palace Hotel"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Donor Type</label>
                <select
                  value={formData.donor_type}
                  onChange={(e) => setFormData({ ...formData, donor_type: e.target.value })}
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white"
                >
                  <option value="Restaurant">Restaurant / Bistro</option>
                  <option value="Hostel">College / University Hostel</option>
                  <option value="Wedding/Event">Wedding / Banquet Event</option>
                  <option value="Cafeteria">Corporate Cafeteria</option>
                  <option value="Supermarket">Supermarket / Grocery</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Contact Phone</label>
                <input
                  type="text"
                  required
                  value={formData.donor_contact}
                  onChange={(e) => setFormData({ ...formData, donor_contact: e.target.value })}
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Address / Dispatch Area</label>
                <input
                  type="text"
                  required
                  value={formData.donor_address}
                  onChange={(e) => setFormData({ ...formData, donor_address: e.target.value })}
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Surplus Food Details */}
          <div className="space-y-4 pt-4 border-t border-slate-100">
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-400">Food Particulars</h2>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Food Item Description</label>
              <input
                type="text"
                required
                value={formData.food_title}
                onChange={(e) => setFormData({ ...formData, food_title: e.target.value })}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                placeholder="e.g. Steamed Rice, Sambar, Vegetable Curry"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Food Category</label>
                <select
                  value={formData.food_category}
                  onChange={(e) => setFormData({ ...formData, food_category: e.target.value })}
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white"
                >
                  <option value="Cooked Meals">Cooked Meals</option>
                  <option value="Bakery">Bakery & Breads</option>
                  <option value="Produce">Fresh Produce</option>
                  <option value="Dairy">Dairy & Desserts</option>
                  <option value="Packaged">Packaged / Dry Goods</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Quantity</label>
                <div className="flex gap-2">
                  <input
                    type="number"
                    step="0.5"
                    min="1"
                    required
                    value={formData.quantity_value}
                    onChange={(e) => setFormData({ ...formData, quantity_value: Number(e.target.value) })}
                    className="w-2/3 px-3 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                  <select
                    value={formData.quantity_unit}
                    onChange={(e) => setFormData({ ...formData, quantity_unit: e.target.value })}
                    className="w-1/3 px-2 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white"
                  >
                    <option value="kg">kg</option>
                    <option value="servings">servings</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Storage Requirement</label>
                <select
                  value={formData.storage_requirement}
                  onChange={(e) => setFormData({ ...formData, storage_requirement: e.target.value })}
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white"
                >
                  <option value="ROOM_TEMP">Room Temperature</option>
                  <option value="REFRIGERATED">Refrigerated (2°C - 5°C)</option>
                  <option value="FROZEN">Frozen (-18°C)</option>
                  <option value="HOT_HOLDING">Hot Holding (&gt;60°C)</option>
                </select>
              </div>
            </div>
          </div>

          {/* Section 3: Time Critical Windows */}
          <div className="space-y-4 pt-4 border-t border-slate-100">
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-400">Food Safety Timelines</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Preparation Timestamp (When Cooked)
                </label>
                <input
                  type="datetime-local"
                  required
                  value={formData.preparation_time}
                  onChange={(e) => setFormData({ ...formData, preparation_time: e.target.value })}
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Pickup Deadline (Safe Expiration Cutoff)
                </label>
                <input
                  type="datetime-local"
                  required
                  value={formData.pickup_deadline}
                  onChange={(e) => setFormData({ ...formData, pickup_deadline: e.target.value })}
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Special Handling Instructions</label>
              <textarea
                rows={2}
                value={formData.handling_instructions}
                onChange={(e) => setFormData({ ...formData, handling_instructions: e.target.value })}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                placeholder="Packaging details, loading dock notes, temperature advice..."
              />
            </div>
          </div>

          {/* Submit Action */}
          <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
            <button
              type="submit"
              disabled={submitting}
              className="flex items-center gap-2 px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-sm font-semibold shadow-md shadow-emerald-600/20 disabled:opacity-50 transition-all cursor-pointer"
            >
              {submitting ? (
                <>Registering & Analyzing...</>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  Submit & Match with AI
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
