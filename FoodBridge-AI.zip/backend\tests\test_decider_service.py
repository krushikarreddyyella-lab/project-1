import pytest
from datetime import datetime, timedelta
from app.models.donation import Donation
from app.models.recipient import Recipient
from app.services.safety_engine import SafetyEngine
from app.services.decider_service import StrandsDecider2BService
from app.schemas.decider import DeciderDecisionEnum


@pytest.fixture
def service():
    return StrandsDecider2BService()


def test_decider_approves_ideal_match(service):
    now = datetime.utcnow()
    donation = Donation(
        id="d1",
        donor_name="Hotel Grand",
        donor_type="Restaurant",
        donor_contact="123",
        donor_address="Road 1",
        latitude=12.9716,
        longitude=77.5946,
        food_title="Rice & Dal",
        food_category="Cooked Meals",
        quantity_value=25.0,
        quantity_unit="kg",
        storage_requirement="ROOM_TEMP",
        dietary_type="VEGETARIAN",
        preparation_time=now - timedelta(hours=1),
        pickup_deadline=now + timedelta(hours=3),
        status="PROPOSED"
    )
    recipient = Recipient(
        id="r1",
        name="Shelter 1",
        organization_type="Shelter",
        contact_person="Sam",
        contact_phone="456",
        address="Road 2",
        latitude=12.9750,
        longitude=77.5980,  # ~0.5 km away
        is_verified=True,
        daily_capacity_kg=100.0,
        current_capacity_used_kg=10.0,
        has_cold_storage=True,
        has_transportation=True,
        reliability_score=0.98
    )

    safety = SafetyEngine.evaluate_safety(donation, recipient, now=now)
    state = service.build_state_vector(donation, recipient, safety, now=now)
    output = service.classify_policy(state)

    assert output.decision == DeciderDecisionEnum.APPROVE
    assert output.confidence >= 0.70
    assert output.latency_ms >= 0.0
    assert len(output.primary_factors) > 0


def test_decider_rejects_on_safety_override(service):
    now = datetime.utcnow()
    donation = Donation(
        id="d2",
        donor_name="Hostel",
        donor_type="Hostel",
        donor_contact="123",
        donor_address="Road 1",
        latitude=12.9716,
        longitude=77.5946,
        food_title="Expired Curry",
        food_category="Cooked Meals",
        quantity_value=15.0,
        quantity_unit="kg",
        storage_requirement="ROOM_TEMP",
        dietary_type="VEGETARIAN",
        preparation_time=now - timedelta(hours=2),
        pickup_deadline=now - timedelta(minutes=5),  # EXPIRED
        status="EXPIRED"
    )
    recipient = Recipient(
        id="r2",
        name="Shelter 2",
        organization_type="Shelter",
        contact_person="Sam",
        contact_phone="456",
        address="Road 2",
        latitude=12.9750,
        longitude=77.5980,
        is_verified=True,
        daily_capacity_kg=100.0,
        current_capacity_used_kg=10.0,
        has_cold_storage=True,
        has_transportation=True,
        reliability_score=0.98
    )

    safety = SafetyEngine.evaluate_safety(donation, recipient, now=now)
    state = service.build_state_vector(donation, recipient, safety, now=now)
    output = service.classify_policy(state)

    # An approval from the model can never override a failed safety check
    assert output.decision == DeciderDecisionEnum.REJECT
    assert output.rule_overrides_applied is True


def test_decider_flags_human_review_for_tight_deadline(service):
    now = datetime.utcnow()
    donation = Donation(
        id="d3",
        donor_name="Bistro",
        donor_type="Restaurant",
        donor_contact="123",
        donor_address="Road 1",
        latitude=12.9716,
        longitude=77.5946,
        food_title="Fresh Pastries",
        food_category="Bakery",
        quantity_value=10.0,
        quantity_unit="kg",
        storage_requirement="ROOM_TEMP",
        dietary_type="VEGETARIAN",
        preparation_time=now - timedelta(hours=1),
        pickup_deadline=now + timedelta(minutes=55),  # 55 mins left (< 1.5 hours)
        status="PROPOSED"
    )
    recipient = Recipient(
        id="r3",
        name="Shelter 3",
        organization_type="Shelter",
        contact_person="Sam",
        contact_phone="456",
        address="Road 2",
        latitude=12.9750,
        longitude=77.5980,
        is_verified=True,
        daily_capacity_kg=100.0,
        current_capacity_used_kg=10.0,
        has_cold_storage=True,
        has_transportation=True,
        reliability_score=0.95
    )

    safety = SafetyEngine.evaluate_safety(donation, recipient, now=now)
    state = service.build_state_vector(donation, recipient, safety, now=now)
    output = service.classify_policy(state)

    assert output.decision == DeciderDecisionEnum.HUMAN_REVIEW
    assert any("deadline" in f.lower() for f in output.primary_factors)
