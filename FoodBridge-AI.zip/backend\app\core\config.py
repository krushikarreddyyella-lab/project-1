import os
from pydantic_settings import BaseSettings, SettingsConfigDict
from typing import Optional


class Settings(BaseSettings):
    PROJECT_NAME: str = "FoodBridge AI"
    VERSION: str = "1.0.0"
    API_V1_STR: str = "/api/v1"
    
    # Database
    DATABASE_URL: str = "sqlite:///./foodbridge.db"
    
    # Impact calculations
    DEFAULT_SERVING_SIZE_KG: float = 0.40  # Standard food bank serving size: 400g / meal
    CO2_SAVED_PER_KG_FOOD: float = 2.50    # Estimated 2.5 kg CO2e saved per kg food rescued
    
    # AI Decider 2B Settings
    DECIDER_MODEL_NAME: str = "Strands-Decider-2B"
    DECIDER_CONFIDENCE_THRESHOLD: float = 0.72
    DECIDER_MAX_SAFE_DISTANCE_KM: float = 25.0
    DECIDER_MIN_HOURS_TO_EXPIRY: float = 1.5
    
    # AWS Bedrock Settings
    AWS_REGION: str = os.getenv("AWS_DEFAULT_REGION", "us-east-1")
    AWS_ACCESS_KEY_ID: Optional[str] = os.getenv("AWS_ACCESS_KEY_ID", None)
    AWS_SECRET_ACCESS_KEY: Optional[str] = os.getenv("AWS_SECRET_ACCESS_KEY", None)
    BEDROCK_MODEL_ID: str = "anthropic.claude-3-haiku-20240307-v1:0"
    
    # Demo and mode flags
    IS_DEMO_ENVIRONMENT: bool = True
    ALLOW_CORS_ORIGINS: list[str] = ["http://localhost:5173", "http://127.0.0.1:5173", "http://localhost:3000"]

    model_config = SettingsConfigDict(env_file=".env", case_sensitive=True)


settings = Settings()
