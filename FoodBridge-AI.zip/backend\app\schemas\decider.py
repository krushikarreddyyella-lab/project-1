from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from enum import Enum


class DeciderDecisionEnum(str, Enum):
    APPROVE = "APPROVE"
    REJECT = "REJECT"
    HUMAN_REVIEW = "HUMAN_REVIEW"


class SafetyCheckResult(BaseModel):
    passed: bool
    reasons: List[str] = []
    checks: Dict[str, bool] = Field(default_factory=dict)


class DeciderInputState(BaseModel):
    donation_id: str
    recipient_id: str
    food_category: str
    quantity_kg: float
    storage_requirement: str
    hours_to_deadline: float
    hours_since_prep: float
    distance_km: float
    recipient_capacity_available_kg: float
    recipient_has_cold_storage: bool
    recipient_has_transport: bool
    recipient_is_verified: bool
    recipient_reliability_score: float
    deterministic_safety_passed: bool
    hard_safety_failure_reasons: List[str] = []


class DeciderOutput(BaseModel):
    decision: DeciderDecisionEnum
    confidence: float = Field(..., ge=0.0, le=1.0)
    primary_factors: List[str]
    rule_overrides_applied: bool = False
    model_name: str = "Strands-Decider-2B"
    latency_ms: float
