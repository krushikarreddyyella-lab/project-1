import time
from datetime import datetime, timedelta
from typing import List, Dict, Any
from app.models.donation import Donation
from app.models.recipient import Recipient
from app.schemas.decider import DeciderOutput, SafetyCheckResult
from app.services.safety_engine import SafetyEngine
from app.services.decider_service import StrandsDecider2BService
from app.services.bedrock_service import BedrockService


class EvaluationBenchmarkService:
    """
    Evaluation Suite for FoodBridge AI.
    Tests model accuracy, safety guardrail enforcement, latency breakdowns,
    and baseline comparisons against curated ground-truth scenarios.
    """

    @classmethod
    def get_test_dataset(cls) -> List[Dict[str, Any]]:
        now = datetime.utcnow()
        return [
            {
                "case_id": "TC-01",
                "name": "Eligible high-volume lunch buffet to nearby shelter",
                "ground_truth": "APPROVE",
                "donation": Donation(
                    id="eval-don-1",
                    donor_name="Grand Hotel",
                    donor_type="Restaurant",
                    donor_contact="555-0101",
                    donor_address="Central Square",
                    latitude=12.9716,
                    longitude=77.5946,
                    food_title="Assorted Rice and Curry",
                    food_category="Cooked Meals",
                    quantity_value=40.0,
                    quantity_unit="kg",
                    storage_requirement="ROOM_TEMP",
                    preparation_time=now - timedelta(hours=1),
                    pickup_deadline=now + timedelta(hours=3),
                    status="PROPOSED"
                ),
                "recipient": Recipient(
                    id="eval-rec-1",
                    name="Downtown Care Kitchen",
                    organization_type="Community Kitchen",
                    contact_person="Alice",
                    contact_phone="555-1001",
                    address="2nd Cross Road",
                    latitude=12.9810,
                    longitude=77.5990,  # ~1.2 km away
                    is_verified=True,
                    daily_capacity_kg=150.0,
                    current_capacity_used_kg=20.0,
                    has_cold_storage=True,
                    has_transportation=True,
                    reliability_score=0.98
                )
            },
            {
                "case_id": "TC-02",
                "name": "Expired donation (past pickup deadline)",
                "ground_truth": "REJECT",
                "donation": Donation(
                    id="eval-don-2",
                    donor_name="Campus Cafeteria",
                    donor_type="Cafeteria",
                    donor_contact="555-0102",
                    donor_address="Tech Campus",
                    latitude=12.9716,
                    longitude=77.5946,
                    food_title="Breakfast Sandwiches",
                    food_category="Cooked Meals",
                    quantity_value=25.0,
                    quantity_unit="kg",
                    storage_requirement="ROOM_TEMP",
                    preparation_time=now - timedelta(hours=6),
                    pickup_deadline=now - timedelta(minutes=15),  # EXPIRED
                    status="EXPIRED"
                ),
                "recipient": Recipient(
                    id="eval-rec-2",
                    name="East Youth Shelter",
                    organization_type="Shelter",
                    contact_person="Bob",
                    contact_phone="555-1002",
                    address="East Road",
                    latitude=12.9750,
                    longitude=77.6000,
                    is_verified=True,
                    daily_capacity_kg=80.0,
                    current_capacity_used_kg=10.0,
                    has_cold_storage=True,
                    has_transportation=True,
                    reliability_score=0.95
                )
            },
            {
                "case_id": "TC-03",
                "name": "Unverified recipient organization",
                "ground_truth": "REJECT",
                "donation": Donation(
                    id="eval-don-3",
                    donor_name="Bakery Delight",
                    donor_type="Restaurant",
                    donor_contact="555-0103",
                    donor_address="Main Market",
                    latitude=12.9716,
                    longitude=77.5946,
                    food_title="Artisan Breads & Rolls",
                    food_category="Bakery",
                    quantity_value=15.0,
                    quantity_unit="kg",
                    storage_requirement="ROOM_TEMP",
                    preparation_time=now - timedelta(hours=2),
                    pickup_deadline=now + timedelta(hours=8),
                    status="PROPOSED"
                ),
                "recipient": Recipient(
                    id="eval-rec-3",
                    name="Unverified Informal Hub",
                    organization_type="NGO",
                    contact_person="Charlie",
                    contact_phone="555-1003",
                    address="West Lane",
                    latitude=12.9730,
                    longitude=77.5920,
                    is_verified=False,  # HARD SAFETY FAIL
                    daily_capacity_kg=50.0,
                    current_capacity_used_kg=0.0,
                    has_cold_storage=False,
                    has_transportation=False,
                    reliability_score=0.60
                )
            },
            {
                "case_id": "TC-04",
                "name": "Insufficient recipient absorption capacity",
                "ground_truth": "REJECT",
                "donation": Donation(
                    id="eval-don-4",
                    donor_name="Convention Center",
                    donor_type="Wedding/Event",
                    donor_contact="555-0104",
                    donor_address="Exhibition Ground",
                    latitude=12.9716,
                    longitude=77.5946,
                    food_title="Buffet Entrees & Rice",
                    food_category="Cooked Meals",
                    quantity_value=120.0,  # 120 kg
                    quantity_unit="kg",
                    storage_requirement="ROOM_TEMP",
                    preparation_time=now - timedelta(hours=1),
                    pickup_deadline=now + timedelta(hours=4),
                    status="PROPOSED"
                ),
                "recipient": Recipient(
                    id="eval-rec-4",
                    name="Small Orphanage Home",
                    organization_type="Shelter",
                    contact_person="David",
                    contact_phone="555-1004",
                    address="South Street",
                    latitude=12.9780,
                    longitude=77.5900,
                    is_verified=True,
                    daily_capacity_kg=30.0,  # Only 30 kg capacity
                    current_capacity_used_kg=15.0,
                    has_cold_storage=False,
                    has_transportation=True,
                    reliability_score=0.92
                )
            },
            {
                "case_id": "TC-05",
                "name": "Approaching tight deadline (under 1.5 hours)",
                "ground_truth": "HUMAN_REVIEW",
                "donation": Donation(
                    id="eval-don-5",
                    donor_name="Airport Lounge",
                    donor_type="Cafeteria",
                    donor_contact="555-0105",
                    donor_address="Terminal 2",
                    latitude=12.9716,
                    longitude=77.5946,
                    food_title="Warm Pastries & Snacks",
                    food_category="Bakery",
                    quantity_value=18.0,
                    quantity_unit="kg",
                    storage_requirement="ROOM_TEMP",
                    preparation_time=now - timedelta(hours=3),
                    pickup_deadline=now + timedelta(minutes=55),  # Tight 55 mins!
                    status="PROPOSED"
                ),
                "recipient": Recipient(
                    id="eval-rec-5",
                    name="Metro Shelter Aid",
                    organization_type="NGO",
                    contact_person="Elena",
                    contact_phone="555-1005",
                    address="Airport Road",
                    latitude=12.9800,
                    longitude=77.6100,
                    is_verified=True,
                    daily_capacity_kg=100.0,
                    current_capacity_used_kg=20.0,
                    has_cold_storage=False,
                    has_transportation=True,
                    reliability_score=0.96
                )
            },
            {
                "case_id": "TC-06",
                "name": "Storage mismatch (requires frozen, recipient lacks freezer)",
                "ground_truth": "REJECT",
                "donation": Donation(
                    id="eval-don-6",
                    donor_name="Dairy Cooperative",
                    donor_type="Supermarket",
                    donor_contact="555-0106",
                    donor_address="Cold Depot",
                    latitude=12.9716,
                    longitude=77.5946,
                    food_title="Frozen Desserts & Ice Cream",
                    food_category="Dairy",
                    quantity_value=35.0,
                    quantity_unit="kg",
                    storage_requirement="FROZEN",
                    preparation_time=now - timedelta(hours=12),
                    pickup_deadline=now + timedelta(hours=10),
                    status="PROPOSED"
                ),
                "recipient": Recipient(
                    id="eval-rec-6",
                    name="Community Soup Pantry",
                    organization_type="Community Kitchen",
                    contact_person="Frank",
                    contact_phone="555-1006",
                    address="North Boulevard",
                    latitude=12.9650,
                    longitude=77.5850,
                    is_verified=True,
                    daily_capacity_kg=80.0,
                    current_capacity_used_kg=10.0,
                    has_cold_storage=False,  # NO COLD STORAGE
                    has_transportation=True,
                    reliability_score=0.90
                )
            },
            {
                "case_id": "TC-07",
                "name": "Borderline distance with moderate reliability",
                "ground_truth": "HUMAN_REVIEW",
                "donation": Donation(
                    id="eval-don-7",
                    donor_name="Wedding Palace",
                    donor_type="Wedding/Event",
                    donor_contact="555-0107",
                    donor_address="Outer Ring",
                    latitude=12.9716,
                    longitude=77.5946,
                    food_title="Cooked Rice & Vegetables",
                    food_category="Cooked Meals",
                    quantity_value=50.0,
                    quantity_unit="kg",
                    storage_requirement="ROOM_TEMP",
                    preparation_time=now - timedelta(hours=2),
                    pickup_deadline=now + timedelta(hours=2, minutes=15),
                    status="PROPOSED"
                ),
                "recipient": Recipient(
                    id="eval-rec-7",
                    name="Suburban Community Kitchen",
                    organization_type="Community Kitchen",
                    contact_person="Grace",
                    contact_phone="555-1007",
                    address="Suburban Zone",
                    latitude=13.0800,
                    longitude=77.6500,  # ~13.5 km away, hot food near distance margin
                    is_verified=True,
                    daily_capacity_kg=120.0,
                    current_capacity_used_kg=40.0,
                    has_cold_storage=False,
                    has_transportation=True,
                    reliability_score=0.82
                )
            }
        ]

    @classmethod
    def run_benchmark(cls) -> Dict[str, Any]:
        cases = cls.get_test_dataset()
        decider = StrandsDecider2BService()
        bedrock = BedrockService()
        
        results = []
        total_decider_latency = 0.0
        total_bedrock_latency = 0.0
        correct_matches = 0

        # Baseline evaluation (simple static distance/capacity rule)
        baseline_correct = 0

        for case in cases:
            don = case["donation"]
            rec = case["recipient"]
            ground_truth = case["ground_truth"]

            # 1. Deterministic safety guardrails
            safety_res = SafetyEngine.evaluate_safety(don, rec)

            # 2. Strands Decider 2B inference
            state = decider.build_state_vector(don, rec, safety_res)
            decider_out = decider.classify_policy(state)
            total_decider_latency += decider_out.latency_ms

            # 3. Bedrock Generative Agent
            hours_left = max(0.0, (don.pickup_deadline - datetime.utcnow()).total_seconds() / 3600.0)
            expl, notif, b_lat, is_live = bedrock.generate_match_explanation(
                donation_title=don.food_title,
                food_category=don.food_category,
                quantity_str=f"{don.quantity_value} {don.quantity_unit}",
                recipient_name=rec.name,
                distance_km=state.distance_km,
                deadline_hours=hours_left,
                decider_decision=decider_out.decision.value,
                decider_confidence=decider_out.confidence,
                policy_factors=decider_out.primary_factors
            )
            total_bedrock_latency += b_lat

            # Accuracy check
            is_correct = (decider_out.decision.value == ground_truth)
            if is_correct:
                correct_matches += 1

            # Baseline logic: approves if safety passed and distance < 15km; ignores urgency and tight deadlines
            baseline_decision = "APPROVE" if (safety_res.passed and state.distance_km < 15.0) else "REJECT"
            if baseline_decision == ground_truth:
                baseline_correct += 1

            results.append({
                "case_id": case["case_id"],
                "name": case["name"],
                "ground_truth": ground_truth,
                "safety_passed": safety_res.passed,
                "decider_decision": decider_out.decision.value,
                "decider_confidence": decider_out.confidence,
                "decider_latency_ms": decider_out.latency_ms,
                "bedrock_latency_ms": b_lat,
                "is_correct": is_correct,
                "baseline_decision": baseline_decision,
                "explanation_preview": expl[:120] + "..." if len(expl) > 120 else expl
            })

        count = len(cases)
        decider_accuracy = round(correct_matches / count * 100.0, 1)
        baseline_accuracy = round(baseline_correct / count * 100.0, 1)
        avg_decider_lat = round(total_decider_latency / count, 2)
        avg_bedrock_lat = round(total_bedrock_latency / count, 2)

        return {
            "test_conditions": {
                "total_cases": count,
                "model_tested": decider.model_name,
                "confidence_threshold": decider.confidence_threshold,
                "timestamp": datetime.utcnow().isoformat() + "Z"
            },
            "metrics": {
                "decider_accuracy_percent": decider_accuracy,
                "baseline_accuracy_percent": baseline_accuracy,
                "accuracy_improvement_percent": round(decider_accuracy - baseline_accuracy, 1),
                "avg_decider_latency_ms": avg_decider_lat,
                "avg_bedrock_latency_ms": avg_bedrock_lat,
                "total_cases_evaluated": count
            },
            "cases": results,
            "observations": (
                f"Strands Decider 2B achieved {decider_accuracy}% accuracy against ground truth, "
                f"outperforming the simple heuristic baseline ({baseline_accuracy}%) by correctly escalating "
                f"time-sensitive and edge-distance donations to HUMAN_REVIEW rather than risky automatic approvals. "
                f"Average Decider inference latency: {avg_decider_lat}ms vs Bedrock generation: {avg_bedrock_lat}ms."
            )
        }
