from typing import List, Dict
from sqlalchemy.orm import Session
from app.models.donation import Donation
from app.schemas.impact import ImpactMetrics
from app.core.config import settings


class ImpactService:
    @classmethod
    def calculate_metrics(cls, db: Session, serving_size_kg: float = None) -> ImpactMetrics:
        if serving_size_kg is None or serving_size_kg <= 0:
            serving_size_kg = settings.DEFAULT_SERVING_SIZE_KG

        donations: List[Donation] = db.query(Donation).all()
        total_donations = len(donations)

        status_counts: Dict[str, int] = {
            "PROPOSED": 0,
            "MATCHED": 0,
            "ACCEPTED": 0,
            "IN_TRANSIT": 0,
            "COLLECTED": 0,
            "REJECTED": 0,
            "EXPIRED": 0,
            "CANCELLED": 0,
        }

        category_rescued_kg: Dict[str, float] = {}
        total_kg_rescued = 0.0
        completed_pickups = 0

        for d in donations:
            status = d.status or "PROPOSED"
            status_counts[status] = status_counts.get(status, 0) + 1

            # CRITICAL RULE (Section 9):
            # Pending offers, proposed, accepted, rejected or expired donations
            # MUST NEVER be counted as completed impact.
            # ONLY donations with status 'COLLECTED' contribute to rescued impact.
            if status == "COLLECTED":
                completed_pickups += 1
                qty_kg = d.quantity_value if d.quantity_unit == "kg" else (d.quantity_value * serving_size_kg)
                total_kg_rescued += qty_kg
                cat = d.food_category or "Other"
                category_rescued_kg[cat] = category_rescued_kg.get(cat, 0.0) + qty_kg

        pending_offers = status_counts.get("PROPOSED", 0) + status_counts.get("MATCHED", 0) + status_counts.get("ACCEPTED", 0)
        in_transit = status_counts.get("IN_TRANSIT", 0)
        rejected_or_expired = status_counts.get("REJECTED", 0) + status_counts.get("EXPIRED", 0) + status_counts.get("CANCELLED", 0)

        # Meals estimate: total rescued kg / configured serving size
        # Documented clearly as an estimate, not a verified count of people fed
        estimated_meals = int(total_kg_rescued / serving_size_kg) if serving_size_kg > 0 else 0
        co2_avoided_kg = round(total_kg_rescued * settings.CO2_SAVED_PER_KG_FOOD, 1)

        # Collection rate = (COLLECTED) / (COLLECTED + REJECTED + EXPIRED) or total finalized
        finalized_count = completed_pickups + rejected_or_expired
        collection_rate = round((completed_pickups / finalized_count * 100.0), 1) if finalized_count > 0 else 0.0

        return ImpactMetrics(
            total_donations=total_donations,
            completed_pickups=completed_pickups,
            pending_offers=pending_offers,
            in_transit=in_transit,
            rejected_or_expired=rejected_or_expired,
            total_kg_rescued=round(total_kg_rescued, 1),
            estimated_meals_served=estimated_meals,
            serving_size_assumed_kg=serving_size_kg,
            co2_avoided_kg=co2_avoided_kg,
            collection_rate_percent=collection_rate,
            status_breakdown=status_counts,
            category_breakdown={k: round(v, 1) for k, v in category_rescued_kg.items()}
        )
