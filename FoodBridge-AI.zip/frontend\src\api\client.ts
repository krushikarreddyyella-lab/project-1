import {
  Donation,
  Recipient,
  MatchCandidate,
  ImpactMetrics,
  BedrockImpactReport,
  HumanReviewCase,
  AuditLogItem,
  BenchmarkResults,
} from '../types';
import { mockApi } from './mockData';

// 1. Check for backend environment variable
const RAW_BACKEND_URL = import.meta.env.VITE_API_URL;
const BACKEND_BASE = RAW_BACKEND_URL
  ? String(RAW_BACKEND_URL).trim().replace(/\/+$/, '')
  : '';

// If VITE_API_URL is not set (e.g. standalone Vercel preview/production), use mock layer
let useMock = !BACKEND_BASE;

console.info(
  `[FoodBridge AI API] Initialized in ${
    useMock ? 'EMBEDDED MOCK (Standalone Vercel)' : `REMOTE BACKEND (${BACKEND_BASE})`
  } mode.`
);

// Graceful backend probe
let backendChecked = false;
async function verifyBackendReachability(): Promise<boolean> {
  if (useMock || backendChecked) return !useMock;
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 2500);
    const res = await fetch(`${BACKEND_BASE}/health`, {
      method: 'GET',
      mode: 'cors',
      signal: controller.signal,
    });
    clearTimeout(timeout);
    backendChecked = true;
    if (!res.ok) {
      console.warn('[FoodBridge AI] Remote backend returned unhealthy status. Falling back to mock.');
      useMock = true;
      return false;
    }
    return true;
  } catch (err) {
    console.warn('[FoodBridge AI] Remote backend unreachable. Falling back to embedded mock layer:', err);
    useMock = true;
    backendChecked = true;
    return false;
  }
}

// Low-level HTTP requester with CORS handling
async function request<T>(endpoint: string, options?: RequestInit): Promise<T> {
  const isHealthy = await verifyBackendReachability();
  if (!isHealthy) {
    throw new Error('BACKEND_FALLBACK_TRIGGERED');
  }

  const res = await fetch(`${BACKEND_BASE}/api/v1${endpoint}`, {
    mode: 'cors',
    credentials: 'omit',
    headers: {
      'Content-Type': 'application/json',
      ...options?.headers,
    },
    ...options,
  });

  if (!res.ok) {
    let errorDetail = 'API Request Failed';
    try {
      const errJson = await res.json();
      errorDetail = errJson.detail || errorDetail;
    } catch {
      errorDetail = `HTTP ${res.status}: ${res.statusText}`;
    }
    throw new Error(errorDetail);
  }

  return res.json();
}

// Fallback execution wrapper
async function executeWithFallback<T>(
  remoteFn: () => Promise<T>,
  mockFn: () => Promise<T>
): Promise<T> {
  if (useMock) {
    return mockFn();
  }

  try {
    return await remoteFn();
  } catch (err: any) {
    // If it's a network error or fallback trigger, switch to mock and retry seamlessly
    if (
      err.message === 'BACKEND_FALLBACK_TRIGGERED' ||
      err.name === 'TypeError' ||
      err.name === 'AbortError' ||
      (err.message && err.message.toLowerCase().includes('failed to fetch'))
    ) {
      console.warn('[FoodBridge AI] Switching permanently to mock layer for current session due to network failure.');
      useMock = true;
      return mockFn();
    }
    // Re-throw genuine backend validation errors (e.g. 400 Bad Request, verification code mismatch)
    throw err;
  }
}

export const api = {
  // System metadata
  getSystemStatus: () =>
    executeWithFallback(
      () => fetch(`${BACKEND_BASE}/`, { mode: 'cors' }).then((r) => r.json()),
      () => mockApi.getSystemStatus()
    ),

  // Donations
  listDonations: (status?: string) =>
    executeWithFallback(
      () => request<Donation[]>(`/donations${status && status !== 'ALL' ? `?status=${status}` : ''}`),
      () => mockApi.listDonations(status)
    ),

  getDonation: (id: string) =>
    executeWithFallback(
      () => request<Donation>(`/donations/${id}`),
      () => mockApi.getDonation(id)
    ),

  createDonation: (data: Partial<Donation>) =>
    executeWithFallback(
      () =>
        request<Donation>('/donations/', {
          method: 'POST',
          body: JSON.stringify(data),
        }),
      () => mockApi.createDonation(data)
    ),

  updateDonationStatus: (id: string, status: string, verificationCode?: string) =>
    executeWithFallback(
      () =>
        request<Donation>(`/donations/${id}/status`, {
          method: 'PATCH',
          body: JSON.stringify({ status, verification_code: verificationCode }),
        }),
      () => mockApi.updateDonationStatus(id, status, verificationCode)
    ),

  // Recipients
  listRecipients: () =>
    executeWithFallback(
      () => request<Recipient[]>('/recipients/'),
      () => mockApi.listRecipients()
    ),

  getRecipient: (id: string) =>
    executeWithFallback(
      () => request<Recipient>(`/recipients/${id}`),
      () => mockApi.getRecipient(id)
    ),

  createRecipient: (data: Partial<Recipient>) =>
    executeWithFallback(
      () =>
        request<Recipient>('/recipients/', {
          method: 'POST',
          body: JSON.stringify(data),
        }),
      () => mockApi.createRecipient(data)
    ),

  // Matches & Decider 2B
  evaluateMatches: (donationId: string) =>
    executeWithFallback(
      () =>
        request<MatchCandidate[]>(`/matches/evaluate/${donationId}`, {
          method: 'POST',
        }),
      () => mockApi.evaluateMatches(donationId)
    ),

  acceptMatch: (matchId: string) =>
    executeWithFallback(
      () =>
        request<{
          success: boolean;
          message: string;
          pickup_verification_code?: string;
          status: string;
        }>(`/matches/${matchId}/accept`, {
          method: 'POST',
        }),
      () => mockApi.acceptMatch(matchId)
    ),

  // Human Review & Audit
  getHumanReviewQueue: () =>
    executeWithFallback(
      () => request<HumanReviewCase[]>('/review-queue/'),
      () => mockApi.getHumanReviewQueue()
    ),

  resolveHumanReview: (matchId: string, action: 'APPROVE' | 'REJECT', reviewerNotes: string) =>
    executeWithFallback(
      () =>
        request<{ success: boolean; message: string }>(`/review-queue/${matchId}/resolve`, {
          method: 'POST',
          body: JSON.stringify({ action, reviewer_notes: reviewerNotes }),
        }),
      () => mockApi.resolveHumanReview(matchId, action, reviewerNotes)
    ),

  getAuditLogs: (limit = 40) =>
    executeWithFallback(
      () => request<AuditLogItem[]>(`/review-queue/audit-logs?limit=${limit}`),
      () => mockApi.getAuditLogs(limit)
    ),

  // Impact
  getImpactMetrics: (servingSizeKg = 0.4) =>
    executeWithFallback(
      () => request<ImpactMetrics>(`/impact/metrics?serving_size_kg=${servingSizeKg}`),
      () => mockApi.getImpactMetrics(servingSizeKg)
    ),

  getBedrockImpactReport: (servingSizeKg = 0.4) =>
    executeWithFallback(
      () => request<BedrockImpactReport>(`/impact/bedrock-report?serving_size_kg=${servingSizeKg}`),
      () => mockApi.getBedrockImpactReport(servingSizeKg)
    ),

  // Evaluation
  runBenchmark: () =>
    executeWithFallback(
      () => request<BenchmarkResults>('/evaluation/run-benchmark', { method: 'POST' }),
      () => mockApi.runBenchmark()
    ),

  getBenchmarkTestCases: () =>
    executeWithFallback(
      () => request<any[]>('/evaluation/test-cases'),
      () => mockApi.getBenchmarkTestCases()
    ),
};
