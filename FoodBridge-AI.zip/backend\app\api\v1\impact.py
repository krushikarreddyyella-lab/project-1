from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.schemas.impact import ImpactMetrics, BedrockImpactReport
from app.services.impact_service import ImpactService
from app.services.bedrock_service import bedrock_service
from app.core.config import settings

router = APIRouter()


@router.get("/metrics", response_model=ImpactMetrics)
def get_impact_metrics(
    serving_size_kg: float = Query(settings.DEFAULT_SERVING_SIZE_KG, ge=0.1, le=2.0),
    db: Session = Depends(get_db)
):
    return ImpactService.calculate_metrics(db, serving_size_kg=serving_size_kg)


@router.get("/bedrock-report", response_model=BedrockImpactReport)
def get_bedrock_impact_report(
    serving_size_kg: float = Query(settings.DEFAULT_SERVING_SIZE_KG, ge=0.1, le=2.0),
    db: Session = Depends(get_db)
):
    metrics = ImpactService.calculate_metrics(db, serving_size_kg=serving_size_kg)
    data = bedrock_service.generate_impact_narrative(
        total_kg=metrics.total_kg_rescued,
        meals_count=metrics.estimated_meals_served,
        co2_saved_kg=metrics.co2_avoided_kg,
        completed_pickups=metrics.completed_pickups,
        serving_size_kg=serving_size_kg
    )
    return BedrockImpactReport(**data)
