import time
from typing import Dict, Any, List, Tuple
from datetime import datetime
from app.models.donation import Donation
from app.models.recipient import Recipient
from app.schemas.decider import DeciderInputState, DeciderOutput, DeciderDecisionEnum, SafetyCheckResult
from app.services.safety_engine import SafetyEngine, haversine_distance_km
from app.core.config import settings


class StrandsDecider2BService:
    """
    Strands Decider 2B Policy Classification Service.
    
    Evaluates proposed donation-recipient candidate matches across 6 core policy axes:
    1. Deadline Proximity & Urgency
    2. Capacity Utilization & Absorption
    3. Spatial Proximity & Transit Efficiency
    4. Storage & Temperature Compatibility
    5. Historical Recipient Reliability
    6. Hard Safety Override Check

    Outputs:
    - APPROVE: Passes safety and policy checks with high confidence.
    - REJECT: Hard safety violation or critical policy mismatch.
    - HUMAN_REVIEW: Ambiguous, borderline confidence, or non-critical risk factors.
    """

    def __init__(self, model_name: str = None, confidence_threshold: float = None):
        self.model_name = model_name or settings.DECIDER_MODEL_NAME
        self.confidence_threshold = confidence_threshold or settings.DECIDER_CONFIDENCE_THRESHOLD

    def build_state_vector(
        self,
        donation: Donation,
        recipient: Recipient,
        safety_result: SafetyCheckResult,
        now: datetime = None
    ) -> DeciderInputState:
        if now is None:
            now = datetime.utcnow()

        hours_to_deadline = max(0.0, (donation.pickup_deadline - now).total_seconds() / 3600.0)
        hours_since_prep = max(0.0, (now - donation.preparation_time).total_seconds() / 3600.0)
        dist = haversine_distance_km(donation.latitude, donation.longitude, recipient.latitude, recipient.longitude)
        
        donation_kg = donation.quantity_value if donation.quantity_unit == "kg" else (donation.quantity_value * settings.DEFAULT_SERVING_SIZE_KG)
        available_cap = max(0.0, recipient.daily_capacity_kg - recipient.current_capacity_used_kg)

        return DeciderInputState(
            donation_id=donation.id,
            recipient_id=recipient.id,
            food_category=donation.food_category,
            quantity_kg=donation_kg,
            storage_requirement=donation.storage_requirement,
            hours_to_deadline=round(hours_to_deadline, 2),
            hours_since_prep=round(hours_since_prep, 2),
            distance_km=round(dist, 2),
            recipient_capacity_available_kg=round(available_cap, 2),
            recipient_has_cold_storage=recipient.has_cold_storage,
            recipient_has_transport=recipient.has_transportation,
            recipient_is_verified=recipient.is_verified,
            recipient_reliability_score=recipient.reliability_score or 0.9,
            deterministic_safety_passed=safety_result.passed,
            hard_safety_failure_reasons=safety_result.reasons
        )

    def classify_policy(
        self,
        state: DeciderInputState
    ) -> DeciderOutput:
        start_time = time.perf_counter()
        factors: List[str] = []

        # HARD SAFETY OVERRIDE:
        # Per Section 6 of specification:
        # "An approval from the decision model cannot override an expired deadline,
        # missing required data, an unverified recipient or a failed safety check."
        if not state.deterministic_safety_passed:
            elapsed = (time.perf_counter() - start_time) * 1000.0
            return DeciderOutput(
                decision=DeciderDecisionEnum.REJECT,
                confidence=0.99,
                primary_factors=[f"Hard Safety Failure: {r}" for r in state.hard_safety_failure_reasons],
                rule_overrides_applied=True,
                model_name=self.model_name,
                latency_ms=round(elapsed, 2)
            )

        # Policy Scoring Engine
        score_components = []
        
        # 1. Proximity score (0 to 1)
        # Ideal: < 5km -> 1.0; 5-15km -> 0.7; 15-25km -> 0.4; > 25km -> 0.1
        if state.distance_km <= 5.0:
            proximity_score = 1.0
            factors.append(f"Optimal proximity ({state.distance_km:.1f} km)")
        elif state.distance_km <= 15.0:
            proximity_score = 0.8
            factors.append(f"Moderate distance ({state.distance_km:.1f} km)")
        else:
            proximity_score = 0.4
            factors.append(f"Extended travel distance ({state.distance_km:.1f} km)")
        score_components.append(proximity_score * 0.25)

        # 2. Capacity Absorption score (0 to 1)
        # Optimal: donation fits comfortably (15% to 75% of available capacity)
        if state.recipient_capacity_available_kg > 0:
            cap_ratio = state.quantity_kg / state.recipient_capacity_available_kg
            if 0.10 <= cap_ratio <= 0.80:
                capacity_score = 1.0
                factors.append(f"Ideal capacity match ({state.quantity_kg:.0f} kg / {state.recipient_capacity_available_kg:.0f} kg available)")
            elif cap_ratio < 0.10:
                capacity_score = 0.85  # Small batch, still good
                factors.append("Small batch relative to recipient capacity")
            else:
                capacity_score = 0.60  # Near capacity ceiling
                factors.append("Batch utilizes >80% of available capacity")
        else:
            capacity_score = 0.0
        score_components.append(capacity_score * 0.25)

        # 3. Urgency and Deadline score (0 to 1)
        # Less than 2 hours: risky, requires immediate human awareness or fast dispatch
        # 2 to 6 hours: good urgency alignment
        # > 6 hours: plenty of time
        is_tight_deadline = False
        if state.hours_to_deadline < 1.5:
            urgency_score = 0.45
            is_tight_deadline = True
            factors.append(f"Approaching deadline ({state.hours_to_deadline:.1f} hrs remaining)")
        elif state.hours_to_deadline <= 5.0:
            urgency_score = 0.95
            factors.append(f"High urgency match within safe transit window ({state.hours_to_deadline:.1f} hrs)")
        else:
            urgency_score = 0.90
            factors.append(f"Comfortable pickup window ({state.hours_to_deadline:.1f} hrs)")
        score_components.append(urgency_score * 0.25)

        # 4. Reliability & Logistics score (0 to 1)
        logistics_score = state.recipient_reliability_score
        if state.recipient_has_transport:
            logistics_score = min(1.0, logistics_score + 0.05)
            factors.append("Recipient has verified dedicated transportation")
        score_components.append(logistics_score * 0.25)

        # Aggregate confidence
        confidence = sum(score_components)
        elapsed = (time.perf_counter() - start_time) * 1000.0

        # Decision Threshold Logic
        # If deadline is very tight (< 1.5h) or confidence is borderline -> HUMAN_REVIEW
        if is_tight_deadline:
            decision = DeciderDecisionEnum.HUMAN_REVIEW
            factors.append("Flagged for human review: rapid dispatch coordination needed due to approaching deadline")
        elif confidence >= self.confidence_threshold:
            decision = DeciderDecisionEnum.APPROVE
        elif confidence >= 0.50:
            decision = DeciderDecisionEnum.HUMAN_REVIEW
            factors.append(f"Confidence score ({confidence:.2f}) below automatic approval threshold ({self.confidence_threshold:.2f})")
        else:
            decision = DeciderDecisionEnum.REJECT
            factors.append("Overall policy match score insufficient for donation dispatch")

        return DeciderOutput(
            decision=decision,
            confidence=round(confidence, 3),
            primary_factors=factors,
            rule_overrides_applied=False,
            model_name=self.model_name,
            latency_ms=round(elapsed, 2)
        )
