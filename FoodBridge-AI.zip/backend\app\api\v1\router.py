from fastapi import APIRouter
from app.api.v1.donations import router as donations_router
from app.api.v1.recipients import router as recipients_router
from app.api.v1.matches import router as matches_router
from app.api.v1.review_queue import router as review_queue_router
from app.api.v1.impact import router as impact_router
from app.api.v1.evaluation import router as eval_router

api_router = APIRouter()
api_router.include_router(donations_router, prefix="/donations", tags=["Donations"])
api_router.include_router(recipients_router, prefix="/recipients", tags=["Recipients"])
api_router.include_router(matches_router, prefix="/matches", tags=["Matches"])
api_router.include_router(review_queue_router, prefix="/review-queue", tags=["Human Review"])
api_router.include_router(impact_router, prefix="/impact", tags=["Impact"])
api_router.include_router(eval_router, prefix="/evaluation", tags=["Evaluation"])
