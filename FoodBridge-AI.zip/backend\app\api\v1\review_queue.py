from typing import List, Dict, Any
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.db.repositories.match_repo import MatchDecisionRepository
from app.db.repositories.donation_repo import DonationRepository
from app.db.repositories.recipient_repo import RecipientRepository
from app.db.repositories.audit_repo import AuditRepository
from app.models.audit_log import AuditLog
from app.schemas.match import MatchReviewResolve

router = APIRouter()


@router.get("/")
def get_human_review_queue(db: Session = Depends(get_db)):
    match_repo = MatchDecisionRepository(db)
    don_repo = DonationRepository(db)
    rec_repo = RecipientRepository(db)

    pending_matches = match_repo.get_pending_human_review()
    items = []

    for m in pending_matches:
        donation = don_repo.get(m.donation_id)
        recipient = rec_repo.get(m.recipient_id)
        items.append({
            "match_id": m.id,
            "donation_id": m.donation_id,
            "recipient_id": m.recipient_id,
            "donation_title": donation.food_title if donation else "Unknown",
            "quantity": f"{donation.quantity_value} {donation.quantity_unit}" if donation else "",
            "food_category": donation.food_category if donation else "",
            "recipient_name": recipient.name if recipient else "Unknown",
            "recipient_type": recipient.organization_type if recipient else "",
            "distance_km": m.distance_km,
            "decider_decision": m.decider_decision,
            "decider_confidence": m.decider_confidence,
            "decider_rationale": m.decider_rationale,
            "bedrock_explanation": m.bedrock_explanation,
            "safety_check_passed": m.safety_check_passed,
            "created_at": m.created_at,
            "match_status": m.match_status
        })

    return items


@router.post("/{match_id}/resolve")
def resolve_human_review(
    match_id: str,
    payload: MatchReviewResolve,
    db: Session = Depends(get_db)
):
    match_repo = MatchDecisionRepository(db)
    don_repo = DonationRepository(db)
    audit_repo = AuditRepository(db)

    match = match_repo.get(match_id)
    if not match:
        raise HTTPException(status_code=404, detail="Match decision not found")

    action = payload.action.upper()
    if action not in ["APPROVE", "REJECT"]:
        raise HTTPException(status_code=400, detail="Action must be 'APPROVE' or 'REJECT'")

    # Critical specification rule:
    # A human reviewer cannot approve if hard safety check failed!
    if action == "APPROVE" and not match.safety_check_passed:
        raise HTTPException(
            status_code=400,
            detail="Hard Safety Override Blocked: Cannot approve a candidate that failed deterministic safety guardrails."
        )

    match.decider_decision = action
    match.match_status = "RESOLVED" if action == "APPROVE" else "EXCLUDED"
    match.human_reviewer_notes = payload.reviewer_notes
    match.human_reviewed_at = datetime.utcnow()
    match_repo.update(match)

    donation = don_repo.get(match.donation_id)
    if action == "APPROVE" and donation and donation.status == "PROPOSED":
        donation.status = "MATCHED"
        don_repo.update(donation)

    audit_repo.create(AuditLog(
        event_type="HUMAN_REVIEW_RESOLVED",
        entity_type="match",
        entity_id=match.id,
        actor_role="COORDINATOR",
        details=f"Coordinator resolved review to {action}. Notes: {payload.reviewer_notes}"
    ))

    return {
        "success": True,
        "message": f"Case resolved as {action}.",
        "match_id": match.id,
        "new_decision": match.decider_decision
    }


@router.get("/audit-logs")
def get_audit_logs(limit: int = 50, db: Session = Depends(get_db)):
    audit_repo = AuditRepository(db)
    logs = audit_repo.get_recent(limit=limit)
    return logs
