import React from 'react';
import { DonationStatus } from '../types';

interface Props {
  status: DonationStatus | string;
}

export const StatusBadge: React.FC<Props> = ({ status }) => {
  const getStyle = () => {
    switch (status) {
      case 'COLLECTED':
        return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'IN_TRANSIT':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'ACCEPTED':
        return 'bg-indigo-100 text-indigo-800 border-indigo-200';
      case 'MATCHED':
        return 'bg-teal-100 text-teal-800 border-teal-200';
      case 'PROPOSED':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'EXPIRED':
        return 'bg-slate-100 text-slate-700 border-slate-300';
      case 'REJECTED':
      case 'CANCELLED':
        return 'bg-rose-100 text-rose-800 border-rose-200';
      default:
        return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold border ${getStyle()}`}>
      <span className="w-1.5 h-1.5 rounded-full bg-current mr-1.5"></span>
      {status.replace('_', ' ')}
    </span>
  );
};
