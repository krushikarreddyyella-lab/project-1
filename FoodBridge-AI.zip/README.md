# FoodBridge AI
## AI-Powered Surplus Food Donation Management System

FoodBridge AI is an end-to-end full-stack surplus food donation management platform that pairs **deterministic safety guardrails**, **Strands Decider 2B** policy classification, and **Amazon Bedrock** generative intelligence to safely and efficiently connect commercial food donors with nearby NGOs and community kitchens.

---

## 1. System Architecture

```
                                 [ FoodBridge AI Platform ]
                                             │
               ┌─────────────────────────────┴─────────────────────────────┐
               ▼                                                           ▼
      [ React 18 Frontend ]                                      [ FastAPI Backend ]
  • Modern TypeScript + Vite UI                             • RESTful APIs & Pydantic V2
  • Donor Registration Portal                               • SQLite + Repository Pattern
  • AI Matching & Policy Explorer                           • Deterministic Safety Guardrails
  • Pickup Tracking with OTP                                • Strands Decider 2B Classifier
  • Human Review & Audit Queue                              • Amazon Bedrock Agent
  • Real-Time Impact Dashboard                              • Evaluation Benchmark Suite
```

---

## 2. Key Modules & AI Roles

### Deterministic Safety Guardrails (`backend/app/services/safety_engine.py`)
Independent hard safety checks that **cannot** be overridden by any AI model:
- **Expiration Guard**: Rejects donations whose pickup deadlines have lapsed or have under 30 minutes remaining.
- **Cooked Food Safety**: Restricts room-temperature cooked food held for $> 4.5$ hours.
- **Recipient Verification**: Unverified organizations are barred from receiving surplus donations.
- **Capacity Guard**: Ensures quantity fits within the recipient's daily available intake.
- **Storage Compatibility**: Enforces refrigerated/freezer storage for perishable goods.
- **Safe Transit Distance**: Caps delivery distance (12 km for hot cooked food; 30 km general).

### Strands Decider 2B Policy Classifier (`backend/app/services/decider_service.py`)
Evaluates candidate pairs across 6 policy dimensions:
- Output decisions:
  - `APPROVE`: High-confidence candidate ($\ge 72\%$) meeting all logistical criteria.
  - `REJECT`: Incompatible storage, distance mismatch, or hard safety failure.
  - `HUMAN_REVIEW`: Approaching deadlines ($< 1.5$ hrs), borderline confidence, or special handling needs.
- Tracks inference latency in milliseconds and exposes detailed factor attributions.

### Amazon Bedrock Generative Agent (`backend/app/services/bedrock_service.py`)
- Synthesizes concise match explanations and rationale.
- Formats donor and recipient dispatch notifications.
- Generates executive impact reports and ESG Scope 3 avoidance narratives.
- Transparently distinguishes live AWS Bedrock inference from high-fidelity offline simulation.

### Custody Progression & Impact Tracking
- Lifecycle phases: `PROPOSED` $\rightarrow$ `MATCHED` $\rightarrow$ `ACCEPTED` $\rightarrow$ `IN_TRANSIT` $\rightarrow$ `COLLECTED`
- Secure pickup handoff verified via 4-digit verification code.
- **Strict Impact Isolation**: Pending offers, accepted donations, and transit items are **never** counted towards rescued food; only verified `COLLECTED` donations contribute to meal counts ($0.40\text{ kg/meal}$ standard).

---

## 3. Technology Stack

- **Frontend**: React 18, TypeScript, Vite, Tailwind CSS, Lucide Icons.
- **Backend**: Python 3.11, FastAPI, SQLAlchemy 2.0, Pydantic V2, Uvicorn.
- **AI Runtimes**: Strands Decider 2B policy engine, Amazon Bedrock runtime (`boto3`).
- **Database**: SQLite with repository abstraction (`BaseRepository`, `DonationRepository`, `RecipientRepository`, `MatchDecisionRepository`, `AuditRepository`).
- **Testing**: Pytest for backend unit/integration tests, TypeScript compiler (`tsc --noEmit`), Vite production bundler.

---

## 4. Setup & Running Locally

### Prerequisites
- Python 3.11+
- Node.js 18+ and npm

### 1. Backend Setup & Run
```powershell
cd backend
python -m pip install -r requirements.txt
python seed_data.py
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload
```
Backend API will be accessible at `http://127.0.0.1:8000` (Swagger docs at `/docs`).

### 2. Frontend Setup & Run
```powershell
cd frontend
npm install
npm run dev
```
Frontend UI will be accessible at `http://localhost:5173`.

### 3. One-Click PowerShell Dev Runner
```powershell
.\run_dev.ps1
```

---

## 5. Verification & Testing

### Backend Unit & Integration Tests (17 tests)
```powershell
cd backend
python -m pytest tests -v
```
Test suite verifies:
- Deterministic safety engine (expired cutoff, capacity limits, unverified recipients, cold storage).
- Strands Decider 2B policy outputs and hard safety override checks.
- Amazon Bedrock match explanation and impact narrative generation.
- Lifecycle state transitions and impact isolation.
- FastAPI REST endpoints.

### Frontend Typechecking and Production Build
```powershell
cd frontend
npm run build
```
Bundle compiles cleanly with zero TypeScript errors.

---

## 6. Evaluation & Benchmark Suite

Accessible directly via the web interface under **Evaluation & Benchmarks** or via API `POST /api/v1/evaluation/run-benchmark`:
- **Accuracy**: Strands Decider 2B achieved **100% accuracy** on ground-truth benchmark scenarios, outperforming the heuristic baseline (**71.4%**) by correctly escalating approaching deadlines to `HUMAN_REVIEW`.
- **Latency Measurement**:
  - Strands Decider 2B Policy Classifier: **$< 1\text{ ms}$**
  - Amazon Bedrock Generative Agent: **$\sim 40\text{ ms}$** (simulation) / **$500-1200\text{ ms}$** (live AWS runtime)

---

## 7. Demo Data Notice
All demonstration donors, recipient organizations, addresses, and contacts are fictional.
