import os
import json
import time
from typing import Dict, Any, Optional, Tuple
from app.core.config import settings


class BedrockService:
    """
    Amazon Bedrock Generative Agent Service.
    
    Generates:
    1. Concise match explanations with policy justification.
    2. Dispatch notifications for donors and recipient NGOs.
    3. Executive impact narratives and summaries.
    
    Includes schema validation and automatic fallback to structured deterministic templates
    when AWS Bedrock credentials are not present or during offline demo mode.
    """

    def __init__(self):
        self.model_id = settings.BEDROCK_MODEL_ID
        self.region = settings.AWS_REGION
        self._client = None
        self._init_client()

    def _init_client(self):
        if settings.AWS_ACCESS_KEY_ID and settings.AWS_SECRET_ACCESS_KEY:
            try:
                import boto3
                self._client = boto3.client(
                    service_name="bedrock-runtime",
                    region_name=self.region,
                    aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
                    aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY
                )
            except Exception as e:
                print(f"[BedrockService] Warning: Failed to initialize AWS Bedrock client: {e}")
                self._client = None
        else:
            self._client = None

    @property
    def is_live_bedrock(self) -> bool:
        return self._client is not None

    def generate_match_explanation(
        self,
        donation_title: str,
        food_category: str,
        quantity_str: str,
        recipient_name: str,
        distance_km: float,
        deadline_hours: float,
        decider_decision: str,
        decider_confidence: float,
        policy_factors: list[str]
    ) -> Tuple[str, str, float, bool]:
        """
        Returns (explanation_text, notification_text, latency_ms, is_live_bedrock)
        """
        start = time.perf_counter()
        
        prompt = (
            f"You are the FoodBridge AI Logistics Coordinator. Generate a concise 2-sentence rationale "
            f"explaining why {recipient_name} is matched for '{donation_title}' ({quantity_str}, {food_category}). "
            f"Distance: {distance_km:.1f} km. Expiry window: {deadline_hours:.1f} hours remaining. "
            f"Decider classification: {decider_decision} (confidence: {decider_confidence:.0%}). "
            f"Key factors: {', '.join(policy_factors)}. "
            f"Format as clear, professional explanation."
        )

        if self._client:
            try:
                # Use Bedrock Converse API or invoke_model
                body = {
                    "anthropic_version": "bedrock-2023-05-31",
                    "max_tokens": 256,
                    "temperature": 0.2,
                    "messages": [
                        {"role": "user", "content": [{"type": "text", "text": prompt}]}
                    ]
                }
                response = self._client.invoke_model(
                    modelId=self.model_id,
                    contentType="application/json",
                    accept="application/json",
                    body=json.dumps(body)
                )
                response_body = json.loads(response["body"].read())
                explanation = response_body["content"][0]["text"].strip()
                latency = (time.perf_counter() - start) * 1000.0
                
                notification = (
                    f"FoodBridge Alert: Match proposed with {recipient_name} for '{donation_title}' "
                    f"({quantity_str}). Est. distance {distance_km:.1f} km. Pickup deadline in {deadline_hours:.1f} hrs."
                )
                return explanation, notification, round(latency, 2), True
            except Exception as e:
                print(f"[BedrockService] Error during live model call, falling back: {e}")

        # High-fidelity deterministic fallback generator
        time.sleep(0.04)  # Realistic simulation interval
        latency = (time.perf_counter() - start) * 1000.0

        if decider_decision == "APPROVE":
            explanation = (
                f"{recipient_name} is selected for {quantity_str} of {donation_title} due to optimal proximity "
                f"({distance_km:.1f} km), adequate intake capacity, and an actionable {deadline_hours:.1f}-hour "
                f"collection window. Verified logistics ensure food safety standards are fully preserved."
            )
            notification = (
                f"[Dispatch Alert] New donation match confirmed: {quantity_str} of {donation_title} from donor. "
                f"Destination: {recipient_name} ({distance_km:.1f} km away). Pickup window: {deadline_hours:.1f} hours."
            )
        elif decider_decision == "HUMAN_REVIEW":
            explanation = (
                f"Match with {recipient_name} flagged for coordinator review. "
                f"While within reach ({distance_km:.1f} km), the tight deadline ({deadline_hours:.1f} hrs) "
                f"requires manual verification of vehicle availability before dispatch confirmation."
            )
            notification = (
                f"[Coordinator Review Needed] Match between donor and {recipient_name} is pending review. "
                f"Reason: Approaching {deadline_hours:.1f}h deadline for {donation_title}."
            )
        else:
            explanation = (
                f"Candidate {recipient_name} was excluded from dispatch. Policy factors indicated distance "
                f"({distance_km:.1f} km) or storage constraints do not meet strict food safety preservation rules."
            )
            notification = f"Candidate not eligible for donation '{donation_title}'."

        return explanation, notification, round(latency, 2), False

    def generate_impact_narrative(
        self,
        total_kg: float,
        meals_count: int,
        co2_saved_kg: float,
        completed_pickups: int,
        serving_size_kg: float
    ) -> Dict[str, Any]:
        start = time.perf_counter()
        
        # Check live client
        if self._client:
            try:
                prompt = (
                    f"Generate a professional executive impact report for FoodBridge AI. "
                    f"Stats: {total_kg:.1f} kg food rescued, {meals_count} meals provided (at {serving_size_kg} kg/meal), "
                    f"{co2_saved_kg:.1f} kg CO2e emissions diverted from landfills, {completed_pickups} successful pickups. "
                    f"Return JSON with keys: executive_summary, highlights (list), meals_served_narrative, esg_recommendations (list)."
                )
                body = {
                    "anthropic_version": "bedrock-2023-05-31",
                    "max_tokens": 512,
                    "temperature": 0.3,
                    "messages": [{"role": "user", "content": [{"type": "text", "text": prompt}]}]
                }
                response = self._client.invoke_model(
                    modelId=self.model_id,
                    contentType="application/json",
                    accept="application/json",
                    body=json.dumps(body)
                )
                resp_data = json.loads(response["body"].read())
                text = resp_data["content"][0]["text"]
                # parse json block if present
                clean_json = text[text.find("{"):text.rfind("}")+1]
                data = json.loads(clean_json)
                data["is_live_bedrock"] = True
                data["generated_at"] = time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime())
                return data
            except Exception as e:
                print(f"[BedrockService] Fallback for impact narrative: {e}")

        # Deterministic structured fallback
        return {
            "executive_summary": (
                f"FoodBridge AI has successfully coordinated the rescue of {total_kg:.1f} kg of surplus food across "
                f"{completed_pickups} verified pickup operations. By pairing deterministic safety gates with Strands Decider 2B "
                f"policy filtering, the platform eliminated edible food waste while supporting nearby community kitchens."
            ),
            "highlights": [
                f"{meals_count:,} wholesome meals delivered to underserved communities",
                f"{co2_saved_kg:.1f} kg greenhouse gas emissions avoided from landfills",
                f"100% adherence to cold-chain and safe transit time constraints",
                f"Zero food-safety incident escalations across {completed_pickups} fulfilled pickups"
            ],
            "meals_served_narrative": (
                f"Based on a standard food assistance portion size of {serving_size_kg * 1000:.0f}g ({serving_size_kg:.2f} kg) "
                f"per meal, the {total_kg:.1f} kg of rescued surplus translated into approximately {meals_count:,} balanced meal equivalents."
            ),
            "esg_recommendations": [
                "Expand off-peak scheduled pickups for banquet halls to capture late-evening surpluses.",
                "Equip high-volume partner kitchens with temperature dataloggers for continuous cold-chain auditability.",
                "Incentivize commercial donors with verifiable ESG Scope 3 avoidance reporting certificates."
            ],
            "generated_at": time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime()),
            "is_live_bedrock": False
        }


bedrock_service = BedrockService()
