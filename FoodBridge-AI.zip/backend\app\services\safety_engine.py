import math
from datetime import datetime, timezone
from typing import Dict, List, Tuple
from app.models.donation import Donation
from app.models.recipient import Recipient
from app.schemas.decider import SafetyCheckResult
from app.core.config import settings


def haversine_distance_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Calculate the great circle distance between two points on the earth in km."""
    R = 6371.0  # Earth radius in kilometers
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = (math.sin(dlat / 2) ** 2 +
         math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlon / 2) ** 2)
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return round(R * c, 2)


class SafetyEngine:
    """
    Deterministic Safety Guardrails for FoodBridge AI.
    These hard rules run independently before any AI decision model.
    An AI model CANNOT override a failed hard safety check.
    """

    MAX_SAFE_DISTANCE_HOT_KM = 12.0
    MAX_SAFE_DISTANCE_GENERAL_KM = 30.0
    MAX_COOKED_ROOM_TEMP_HOURS = 4.5
    MIN_DEADLINE_BUFFER_MINUTES = 30.0

    @classmethod
    def evaluate_safety(
        cls,
        donation: Donation,
        recipient: Recipient,
        now: datetime = None
    ) -> SafetyCheckResult:
        if now is None:
            now = datetime.utcnow()

        reasons: List[str] = []
        checks: Dict[str, bool] = {}

        # Rule 1: Expiration & Deadline Guard
        time_to_deadline_hours = (donation.pickup_deadline - now).total_seconds() / 3600.0
        if time_to_deadline_hours <= (cls.MIN_DEADLINE_BUFFER_MINUTES / 60.0):
            checks["deadline_valid"] = False
            reasons.append(
                f"Pickup deadline has passed or is too close ({time_to_deadline_hours:.2f} hrs remaining; min {cls.MIN_DEADLINE_BUFFER_MINUTES} mins required)."
            )
        else:
            checks["deadline_valid"] = True

        # Rule 2: Food Preparation & Holding Guard
        hours_since_prep = (now - donation.preparation_time).total_seconds() / 3600.0
        if hours_since_prep < 0:
            checks["prep_time_valid"] = False
            reasons.append("Preparation time cannot be set in the future.")
        elif donation.food_category == "Cooked Meals" and donation.storage_requirement == "ROOM_TEMP" and hours_since_prep > cls.MAX_COOKED_ROOM_TEMP_HOURS:
            checks["prep_time_valid"] = False
            reasons.append(
                f"Cooked food held at room temperature exceeds food safety limit ({hours_since_prep:.1f} hrs elapsed, max safe is {cls.MAX_COOKED_ROOM_TEMP_HOURS} hrs)."
            )
        else:
            checks["prep_time_valid"] = True

        # Rule 3: Recipient Verification Guard
        if not recipient.is_verified:
            checks["recipient_verified"] = False
            reasons.append("Recipient organization is unverified. Donations can only be matched with verified NGOs/kitchens.")
        else:
            checks["recipient_verified"] = True

        # Rule 4: Capacity Guard
        available_capacity = max(0.0, recipient.daily_capacity_kg - recipient.current_capacity_used_kg)
        donation_kg = donation.quantity_value if donation.quantity_unit == "kg" else (donation.quantity_value * settings.DEFAULT_SERVING_SIZE_KG)
        if donation_kg > available_capacity:
            checks["capacity_available"] = False
            reasons.append(
                f"Donation quantity ({donation_kg:.1f} kg) exceeds recipient's available remaining capacity ({available_capacity:.1f} kg)."
            )
        else:
            checks["capacity_available"] = True

        # Rule 5: Storage Compatibility Guard
        storage_req = (donation.storage_requirement or "ROOM_TEMP").upper()
        if storage_req in ["REFRIGERATED", "FROZEN"] and not recipient.has_cold_storage:
            checks["storage_compatible"] = False
            reasons.append(
                f"Donation requires {storage_req} storage, but recipient does not possess cold storage facilities."
            )
        else:
            checks["storage_compatible"] = True

        # Rule 6: Transit & Distance Guard
        dist = haversine_distance_km(donation.latitude, donation.longitude, recipient.latitude, recipient.longitude)
        max_dist = cls.MAX_SAFE_DISTANCE_HOT_KM if storage_req == "HOT_HOLDING" else cls.MAX_SAFE_DISTANCE_GENERAL_KM
        if dist > max_dist:
            checks["distance_safe"] = False
            reasons.append(
                f"Distance ({dist:.1f} km) exceeds maximum safe delivery distance for {storage_req} items ({max_dist:.1f} km)."
            )
        else:
            checks["distance_safe"] = True

        # Rule 7: Transportation Readiness
        if dist > 3.0 and not recipient.has_transportation:
            checks["transport_available"] = False
            reasons.append(f"Distance ({dist:.1f} km) requires vehicle dispatch, but recipient lacks transportation.")
        else:
            checks["transport_available"] = True

        passed = all(checks.values())
        return SafetyCheckResult(passed=passed, reasons=reasons, checks=checks)
