from typing import List, Optional
from sqlalchemy.orm import Session
from app.db.repositories.base_repo import BaseRepository
from app.models.match_decision import MatchDecision


class MatchDecisionRepository(BaseRepository[MatchDecision]):
    def __init__(self, db: Session):
        super().__init__(MatchDecision, db)

    def get_by_donation_id(self, donation_id: str) -> List[MatchDecision]:
        return self.db.query(MatchDecision).filter(MatchDecision.donation_id == donation_id).all()

    def get_pending_human_review(self) -> List[MatchDecision]:
        return self.db.query(MatchDecision).filter(
            MatchDecision.decider_decision == "HUMAN_REVIEW",
            MatchDecision.match_status == "ESCALATED"
        ).order_by(MatchDecision.created_at.desc()).all()

    def get_by_decision(self, decision: str) -> List[MatchDecision]:
        return self.db.query(MatchDecision).filter(MatchDecision.decider_decision == decision).all()
