import random
from datetime import datetime
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.db.repositories.donation_repo import DonationRepository
from app.db.repositories.audit_repo import AuditRepository
from app.models.donation import Donation
from app.models.audit_log import AuditLog
from app.schemas.donation import DonationCreate, DonationResponse, DonationStatusUpdate

router = APIRouter()


@router.post("/", response_model=DonationResponse)
def register_donation(payload: DonationCreate, db: Session = Depends(get_db)):
    repo = DonationRepository(db)
    audit_repo = AuditRepository(db)

    # Generate a random 4-digit pickup verification code
    verification_code = f"{random.randint(1000, 9999)}"

    donation = Donation(
        donor_name=payload.donor_name,
        donor_type=payload.donor_type,
        donor_contact=payload.donor_contact,
        donor_address=payload.donor_address,
        latitude=payload.latitude,
        longitude=payload.longitude,
        food_title=payload.food_title,
        food_category=payload.food_category,
        quantity_value=payload.quantity_value,
        quantity_unit=payload.quantity_unit,
        storage_requirement=payload.storage_requirement,
        dietary_type=payload.dietary_type,
        preparation_time=payload.preparation_time,
        pickup_deadline=payload.pickup_deadline,
        handling_instructions=payload.handling_instructions,
        status="PROPOSED",
        pickup_verification_code=verification_code
    )
    created = repo.create(donation)

    audit_repo.create(AuditLog(
        event_type="DONATION_REGISTERED",
        entity_type="donation",
        entity_id=created.id,
        actor_role="DONOR",
        details=f"Registered surplus: {created.food_title} ({created.quantity_value} {created.quantity_unit})"
    ))

    return created


@router.get("/", response_model=List[DonationResponse])
def list_donations(
    status: Optional[str] = Query(None, description="Filter by status (PROPOSED, ACCEPTED, COLLECTED, etc.)"),
    db: Session = Depends(get_db)
):
    repo = DonationRepository(db)
    if status:
        return repo.get_by_status(status.upper())
    return repo.get_all(limit=200)


@router.get("/{donation_id}", response_model=DonationResponse)
def get_donation(donation_id: str, db: Session = Depends(get_db)):
    repo = DonationRepository(db)
    don = repo.get(donation_id)
    if not don:
        raise HTTPException(status_code=404, detail="Donation not found")
    return don


@router.patch("/{donation_id}/status", response_model=DonationResponse)
def update_donation_status(
    donation_id: str,
    payload: DonationStatusUpdate,
    db: Session = Depends(get_db)
):
    repo = DonationRepository(db)
    audit_repo = AuditRepository(db)
    don = repo.get(donation_id)
    if not don:
        raise HTTPException(status_code=404, detail="Donation not found")

    new_status = payload.status.upper()
    valid_statuses = ["PROPOSED", "MATCHED", "ACCEPTED", "IN_TRANSIT", "COLLECTED", "REJECTED", "EXPIRED", "CANCELLED"]
    if new_status not in valid_statuses:
        raise HTTPException(status_code=400, detail=f"Invalid status '{new_status}'. Allowed: {valid_statuses}")

    # Role & Verification Code Check for COLLECTION
    if new_status == "COLLECTED":
        if payload.verification_code:
            if payload.verification_code.strip() != (don.pickup_verification_code or "").strip():
                raise HTTPException(status_code=400, detail="Invalid pickup verification code provided by transporter.")
        don.collected_at = datetime.utcnow()

    prev_status = don.status
    don.status = new_status
    updated = repo.update(don)

    audit_repo.create(AuditLog(
        event_type="STATUS_CHANGED",
        entity_type="donation",
        entity_id=updated.id,
        actor_role="COORDINATOR",
        details=f"Status transitioned from {prev_status} to {new_status}"
    ))

    return updated
