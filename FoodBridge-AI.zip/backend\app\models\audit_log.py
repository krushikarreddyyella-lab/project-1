import uuid
from datetime import datetime
from sqlalchemy import Column, String, DateTime, Text
from app.db.session import Base


class AuditLog(Base):
    __tablename__ = "audit_logs"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    event_type = Column(String(64), nullable=False)
    entity_type = Column(String(32), nullable=False)
    entity_id = Column(String(36), nullable=False)
    actor_role = Column(String(32), nullable=False, default="SYSTEM")
    actor_id = Column(String(64), nullable=True)
    details = Column(Text, nullable=True)  # JSON payload
    created_at = Column(DateTime, default=datetime.utcnow)
