export type DonationStatus =
  | 'PROPOSED'
  | 'MATCHED'
  | 'ACCEPTED'
  | 'IN_TRANSIT'
  | 'COLLECTED'
  | 'REJECTED'
  | 'EXPIRED'
  | 'CANCELLED';

export type DeciderDecision = 'APPROVE' | 'REJECT' | 'HUMAN_REVIEW';

export interface Donation {
  id: string;
  donor_name: string;
  donor_type: string;
  donor_contact: string;
  donor_address: string;
  latitude: number;
  longitude: number;
  food_title: string;
  food_category: string;
  quantity_value: number;
  quantity_unit: string;
  storage_requirement: string;
  dietary_type: string;
  preparation_time: string;
  pickup_deadline: string;
  status: DonationStatus;
  pickup_verification_code?: string;
  handling_instructions?: string;
  created_at: string;
  updated_at: string;
  collected_at?: string;
}

export interface Recipient {
  id: string;
  name: string;
  organization_type: string;
  contact_person: string;
  contact_phone: string;
  contact_email?: string;
  address: string;
  latitude: number;
  longitude: number;
  is_verified: boolean;
  daily_capacity_kg: number;
  current_capacity_used_kg: number;
  has_cold_storage: boolean;
  has_transportation: boolean;
  accepted_categories: string;
  operating_hours_start: string;
  operating_hours_end: string;
  reliability_score: number;
  created_at: string;
}

export interface SafetyCheckResult {
  passed: boolean;
  reasons: string[];
  checks: Record<string, boolean>;
}

export interface DeciderOutput {
  decision: DeciderDecision;
  confidence: number;
  primary_factors: string[];
  rule_overrides_applied: boolean;
  model_name: string;
  latency_ms: number;
}

export interface MatchCandidate {
  id: string;
  donation_id: string;
  recipient: Recipient;
  distance_km: number;
  capacity_fit: boolean;
  storage_fit: boolean;
  safety_result: SafetyCheckResult;
  decider_output: DeciderOutput;
  bedrock_explanation?: string;
  bedrock_notification?: string;
  bedrock_latency_ms: number;
  is_live_bedrock: boolean;
  match_status: string;
  created_at: string;
}

export interface ImpactMetrics {
  total_donations: number;
  completed_pickups: number;
  pending_offers: number;
  in_transit: number;
  rejected_or_expired: number;
  total_kg_rescued: number;
  estimated_meals_served: number;
  serving_size_assumed_kg: number;
  co2_avoided_kg: number;
  collection_rate_percent: number;
  status_breakdown: Record<string, number>;
  category_breakdown: Record<string, number>;
}

export interface BedrockImpactReport {
  executive_summary: string;
  highlights: string[];
  meals_served_narrative: string;
  esg_recommendations: string[];
  generated_at: string;
  is_live_bedrock: boolean;
}

export interface HumanReviewCase {
  match_id: string;
  donation_id: string;
  recipient_id: string;
  donation_title: string;
  quantity: string;
  food_category: string;
  recipient_name: string;
  recipient_type: string;
  distance_km: number;
  decider_decision: string;
  decider_confidence: number;
  decider_rationale: string;
  bedrock_explanation?: string;
  safety_check_passed: boolean;
  created_at: string;
  match_status: string;
}

export interface AuditLogItem {
  id: string;
  event_type: string;
  entity_type: string;
  entity_id: string;
  actor_role: string;
  actor_id?: string;
  details?: string;
  created_at: string;
}

export interface BenchmarkCase {
  case_id: string;
  name: string;
  ground_truth: string;
  safety_passed: boolean;
  decider_decision: string;
  decider_confidence: number;
  decider_latency_ms: number;
  bedrock_latency_ms: number;
  is_correct: boolean;
  baseline_decision: string;
  explanation_preview: string;
}

export interface BenchmarkResults {
  test_conditions: {
    total_cases: number;
    model_tested: string;
    confidence_threshold: number;
    timestamp: string;
  };
  metrics: {
    decider_accuracy_percent: number;
    baseline_accuracy_percent: number;
    accuracy_improvement_percent: number;
    avg_decider_latency_ms: number;
    avg_bedrock_latency_ms: number;
    total_cases_evaluated: number;
  };
  cases: BenchmarkCase[];
  observations: string;
}
