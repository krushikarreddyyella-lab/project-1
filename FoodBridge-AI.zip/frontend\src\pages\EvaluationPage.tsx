import React, { useState, useEffect } from 'react';
import { 
  Cpu, 
  Play, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  Clock, 
  Sparkles, 
  BarChart, 
  ShieldCheck, 
  Zap,
  Info
} from 'lucide-react';
import { BenchmarkResults } from '../types';
import { api } from '../api/client';
import { DecisionBadge } from '../components/DecisionBadge';

export const EvaluationPage: React.FC = () => {
  const [results, setResults] = useState<BenchmarkResults | null>(null);
  const [running, setRunning] = useState(false);

  const runBenchmark = async () => {
    try {
      setRunning(true);
      const res = await api.runBenchmark();
      setResults(res);
    } catch (err) {
      console.error(err);
    } finally {
      setRunning(false);
    }
  };

  useEffect(() => {
    runBenchmark();
  }, []);

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-purple-50 text-purple-600 rounded-xl">
            <Cpu className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900">Evaluation Suite & Model Benchmarking</h1>
            <p className="text-xs text-slate-500 mt-0.5">
              Empirical assessment of Strands Decider 2B accuracy, baseline comparison, and Decider vs Bedrock latency.
            </p>
          </div>
        </div>

        <button
          onClick={runBenchmark}
          disabled={running}
          className="flex items-center gap-2 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-semibold shadow-sm transition-all disabled:opacity-50"
        >
          <Play className={`w-3.5 h-3.5 ${running ? 'animate-spin' : ''}`} />
          {running ? 'Evaluating Benchmark Suite...' : 'Re-Run Evaluation Suite'}
        </button>
      </div>

      {results && (
        <div className="space-y-6">
          {/* Metrics Overview Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">
                Decider 2B Accuracy
              </span>
              <div className="mt-2 text-3xl font-extrabold text-emerald-600">
                {results.metrics.decider_accuracy_percent}%
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                Across {results.metrics.total_cases_evaluated} ground-truth test cases
              </p>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">
                Rule Baseline Accuracy
              </span>
              <div className="mt-2 text-3xl font-extrabold text-slate-700">
                {results.metrics.baseline_accuracy_percent}%
              </div>
              <p className="text-[11px] text-emerald-600 mt-1 font-semibold">
                +{results.metrics.accuracy_improvement_percent}% accuracy gain over baseline
              </p>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between text-xs font-semibold text-slate-500 uppercase tracking-wider">
                <span>Decider 2B Latency</span>
                <Zap className="w-4 h-4 text-amber-500" />
              </div>
              <div className="mt-2 text-3xl font-extrabold text-slate-900 font-mono">
                {results.metrics.avg_decider_latency_ms} <span className="text-sm font-normal text-slate-400">ms</span>
              </div>
              <p className="text-[11px] text-slate-400 mt-1">Average policy classification time</p>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between text-xs font-semibold text-slate-500 uppercase tracking-wider">
                <span>Bedrock Latency</span>
                <Sparkles className="w-4 h-4 text-purple-500" />
              </div>
              <div className="mt-2 text-3xl font-extrabold text-slate-900 font-mono">
                {results.metrics.avg_bedrock_latency_ms} <span className="text-sm font-normal text-slate-400">ms</span>
              </div>
              <p className="text-[11px] text-slate-400 mt-1">Average generative explanation time</p>
            </div>
          </div>

          {/* Observations & Methodology Box */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-2 text-xs">
            <div className="flex items-center gap-2 text-sm font-bold text-slate-800">
              <Info className="w-4 h-4 text-purple-600" />
              Evaluation Methodology & Empirical Findings
            </div>
            <p className="text-slate-600 leading-relaxed">{results.observations}</p>
            <div className="p-3 bg-slate-50 rounded-xl text-slate-500 text-[11px] space-y-1">
              <strong>Evaluation Test Conditions:</strong>
              <div>• Evaluated {results.test_conditions.total_cases} curated scenarios including expired foods, unverified organizations, capacity saturation, and borderline deadlines.</div>
              <div>• Hard deterministic guardrails execute prior to model inference to guarantee zero safety violations.</div>
              <div>• Confidence threshold set at {Math.round(results.test_conditions.confidence_threshold * 100)}% for automatic approval.</div>
            </div>
          </div>

          {/* Detailed Test Scenario Table */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between">
              <h2 className="text-sm font-bold text-slate-900">Scenario-by-Scenario Evaluation Results</h2>
              <span className="text-xs text-slate-400">Model: {results.test_conditions.model_tested}</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 font-semibold uppercase tracking-wider text-[10px]">
                  <tr>
                    <th className="py-3 px-4">Case</th>
                    <th className="py-3 px-4">Scenario Description</th>
                    <th className="py-3 px-4">Ground Truth</th>
                    <th className="py-3 px-4">Hard Safety</th>
                    <th className="py-3 px-4">Decider 2B Decision</th>
                    <th className="py-3 px-4">Confidence</th>
                    <th className="py-3 px-4">Decider Latency</th>
                    <th className="py-3 px-4">Bedrock Latency</th>
                    <th className="py-3 px-4 text-center">Result</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {results.cases.map((c) => (
                    <tr key={c.case_id} className="hover:bg-slate-50/50">
                      <td className="py-3 px-4 font-mono font-bold text-slate-700">{c.case_id}</td>
                      <td className="py-3 px-4 max-w-xs">
                        <span className="font-semibold text-slate-800 block">{c.name}</span>
                        <span className="text-[11px] text-slate-500 truncate block mt-0.5">
                          {c.explanation_preview}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <span className="px-2 py-0.5 rounded font-mono font-semibold bg-slate-100 text-slate-700 border border-slate-200 text-[10px]">
                          {c.ground_truth}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        {c.safety_passed ? (
                          <span className="text-emerald-700 font-medium flex items-center gap-1">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> Passed
                          </span>
                        ) : (
                          <span className="text-rose-700 font-medium flex items-center gap-1">
                            <XCircle className="w-3.5 h-3.5 text-rose-600" /> Blocked
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-4">
                        <DecisionBadge decision={c.decider_decision} />
                      </td>
                      <td className="py-3 px-4 font-mono text-slate-700">
                        {Math.round(c.decider_confidence * 100)}%
                      </td>
                      <td className="py-3 px-4 font-mono text-slate-500 whitespace-nowrap">
                        {c.decider_latency_ms} ms
                      </td>
                      <td className="py-3 px-4 font-mono text-slate-500 whitespace-nowrap">
                        {c.bedrock_latency_ms} ms
                      </td>
                      <td className="py-3 px-4 text-center">
                        {c.is_correct ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                            MATCH
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800">
                            MISMATCH
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
