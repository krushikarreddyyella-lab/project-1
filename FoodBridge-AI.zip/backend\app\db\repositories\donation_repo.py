from typing import List, Optional
from datetime import datetime
from sqlalchemy.orm import Session
from app.db.repositories.base_repo import BaseRepository
from app.models.donation import Donation


class DonationRepository(BaseRepository[Donation]):
    def __init__(self, db: Session):
        super().__init__(Donation, db)

    def get_by_status(self, status: str) -> List[Donation]:
        return self.db.query(Donation).filter(Donation.status == status).order_by(Donation.created_at.desc()).all()

    def get_active_donations(self) -> List[Donation]:
        return self.db.query(Donation).filter(
            Donation.status.in_(["PROPOSED", "MATCHED", "ACCEPTED", "IN_TRANSIT"])
        ).order_by(Donation.pickup_deadline.asc()).all()

    def get_collected_donations(self) -> List[Donation]:
        return self.db.query(Donation).filter(Donation.status == "COLLECTED").all()

    def get_approaching_deadline(self, hours_threshold: float = 3.0) -> List[Donation]:
        now = datetime.utcnow()
        return self.db.query(Donation).filter(
            Donation.status.in_(["PROPOSED", "MATCHED"]),
            Donation.pickup_deadline > now
        ).order_by(Donation.pickup_deadline.asc()).all()
